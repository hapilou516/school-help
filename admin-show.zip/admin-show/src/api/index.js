import axios from "axios";
import serve from "../serve";
const request = axios.create({
  // 配置接口请求的基准路径
  baseURL: serve.address,
});
// 响应拦截器
request.interceptors.response.use(
  (response) => {
    if (response.status == 200) {
      return response.data;
    } else {
      return response;
    }
  },
  function (error) {
    return Promise.reject(error);
  }
);

export const getModel = () => {
  return request({
    method: "GET",
    url: "/getModel",
    // params选项用来配置QUERY的参数 ?query=xxxx
  });
};