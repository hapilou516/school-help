<script setup >
import {
  World,
  Model,
  ThirdPersonCamera,
  Keyboard,
  Find,
  useSpring,
  HTML,
  SkyLight
} from "lingo3d-vue"
import * as api from "./api/index.js"
import { computed, ref, onMounted, reactive } from "vue"
import serve from "./serve.js"
const data = reactive({
  products: [],
  host: serve.host,
  product: "robot"
})
onMounted(async () => {
  let result = await api.getModel()
  result = result.map((value) => {
    value = {
      ...value,
      scale: 0.04,
      looking: false,
      physics: "map",
      y: -47
    }
    if (value.modelUrl == "robot") {
      value.scale = 0.2
      value.y = -40
    }
    if (value.modelUrl == "chess") {
      value.scale = 0.01
    }
    return value
  })
  data.products = result
  data.product = result[2].modelUrl
})
// import AnimateText from 'animate-text'
const pose = ref("idle")
const person = ref()
let looking = ref(false)
// 控制视角缩放
const camY = computed(() => {
  if (looking.value) return 150
  else return 0
})
// 弹簧动画
const camYSpring = useSpring({ to: camY })
const handleKeyPress = (key) => {
  if (key === "w") {
    pose.value = "walking"
    person.value.moveForward(-5)
  }
  if (key === "Space") {
    pose.value = "space"
    person.value.moveForward(-5)
  }
}
const handleKeyUP = (key) => {
  if (key === "w") {
    pose.value = "idle"
  }
  if (key == "Enter") {
    looking.value = !looking.value
  }
}
</script>

<template>
  <World default-light="cartoon2.hdr" skybox="cartoon2.hdr">

    <Model src="Chinese Emperor's Hall.glb" :scale="10" pbr physics="map">
      <SkyLight intensity=1.5></SkyLight>
      <Model :src="`${data.host}file/model/${item.modelUrl}.glb`" :scale="item.scale" :z='-100 + index * 32' :y='item.y' :x='0' :physics="item.physics" v-for="(item,index) in data.products" :key="index" @mouse-over="item.looking= true" @mouse-out="item.looking=false">
          <transition name="set">
                  <HTML v-if="item.looking">
                  
                    <div class="desc">
                      <h1 class="title">{{ item.desc.title }}</h1>
                      <p class="content">{{ item.desc.content }}</p>
                    </div>
                

                  </HTML>
          </transition>
      </Model>

    </Model>
    <ThirdPersonCamera active mouse-control :inner-z="100" :inner-y="camYSpring">
      <Model src="Tgirl.fbx" :scale="1" ref="person" physics="character" :animations="{idle:'Stand.fbx',walking:'Running.fbx',space:'Jumping.fbx'}" :animation="pose" :metalness-factor="-1">

      </Model>
    </ThirdPersonCamera>
    <Keyboard @key-press="handleKeyPress" @key-up="handleKeyUP"></Keyboard>
  </World>
  
</template>
<style>
/* 设置模块过渡动画 */
.set-enter-from,
.set-leave-to {
  width: 0;
  height: 0;
  box-shadow: none;
}
.set-enter-active,
.set-leave-active {
  transition: all 0.4s;
}
/* 设置内容过渡 */
.set-content-enter-from,
.set-content-leave-to {
  opacity: 0;
}
.set-content-enter-active,
.set-content-leave-active {
  transition: all 0.25s;
}
.desc {
  z-index: 100000;
  background-color: rgba(255, 255, 255, 0.5);
  /* transition: all 0.5s; */
}
.desc .title {
  text-align: center;
  font-size: 30px;
  color: #0f8cdc;
}
.desc .content {
  text-indent: 2em;
  margin-top: 10px;
  font-size: 20px;
  font-weight: 500;
  color: #666;
}
</style>