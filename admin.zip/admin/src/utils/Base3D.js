import * as THREE from "three"
import host from '../config.js'
import { RGBELoader } from "three/examples/jsm/loaders/RGBELoader";
// 导入控制器，轨道控制器
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";
// 导入模型解析器
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";
class Base3d {
  constructor(selector, onFinish) {
    this.container = document.querySelector(selector)
    this.camera;
    this.scene;
    this.renderer;
    this.controls;
    this.model;
    this.panzi;
    this.animaAction;

    this.onFinish = onFinish
    this.clock = new THREE.Clock()
    this.init()
    this.initLight()
    this.animate()
    this.progressFn;
  }
  onProgress(fn) {
    // console.log(fn);
    this.progressFn = fn;
  }
  init() {
    this.initScene()
    this.initCamera()
    this.initRenderer()
    this.addMesh();
    this.initControls();
    // 监听场景变换
    window.addEventListener("resize", this.onWindowResize.bind(this))
    // window.addEventListener("mousewheel", this.onMouseWheel.bind(this));

  }
  initScene() {
    this.scene = new THREE.Scene()
    this.setEnvMap("000")
  }
  initCamera() {
    this.camera = new THREE.PerspectiveCamera(
      45,
      window.innerWidth / window.innerHeight,
      0.25,
      200
    )
    this.camera.position.set(7, 17, 18);
  }
  initRenderer() {
    this.renderer = new THREE.WebGL1Renderer({ antialias: true })
    // 设置屏幕像素比
    this.renderer.setPixelRatio(window.devicePixelRatio)
    this.renderer.setSize(1450, 633)
    // 色调映射
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping
    // 曝光度
    this.renderer.toneMappingExposure = 1.4
    this.container.appendChild(this.renderer.domElement)
  }
  setEnvMap(hdr) {
    new RGBELoader().setPath(`${host.host}file/hdr/`).load(hdr + ".hdr", (texture) => {
      // 圆柱映射
      texture.mapping = THREE.EquirectangularReflectionMapping
      this.scene.background = texture
      this.scene.environment = texture
    })
  }
  render() {
    var delta = this.clock.getDelta()
    this.mixer && this.mixer.update(delta);
    this.renderer.render(this.scene, this.camera)
  }
  animate() {
    // 设置动画帧
    this.renderer.setAnimationLoop(this.render.bind(this))
  }
  initControls() {
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);

  }
  initLight() {
    const light1 = new THREE.DirectionalLight(0xffffff, .6)
    light1.position.set(0, 0, 10)
    this.scene.add(light1)
    const light2 = new THREE.DirectionalLight(0xffffff, .6)
    light2.position.set(0, 0, -10)
    this.scene.add(light2)
    const light3 = new THREE.DirectionalLight(0xffffff, .6)
    light3.position.set(10, 0, 0)
    this.scene.add(light3)
    const light4 = new THREE.DirectionalLight(0xffffff, .6)
    light4.position.set(-10, 0, 0)
    this.scene.add(light4)
    const light5 = new THREE.DirectionalLight(0xffffff, .6)
    light5.position.set(0, 10, 0)
    this.scene.add(light5)
    const light6 = new THREE.DirectionalLight(0xffffff, 0.3)
    light6.position.set(5, 10, 0)
    this.scene.add(light6)
    const light7 = new THREE.DirectionalLight(0xffffff, 0.3)
    light7.position.set(0, 10, 5)
    this.scene.add(light7)
    const light8 = new THREE.DirectionalLight(0xffffff, 0.3)
    light8.position.set(0, 10, -5)
    this.scene.add(light8)
    const light9 = new THREE.DirectionalLight(0xffffff, 0.3)
    light9.position.set(-5, 10, 0)
    this.scene.add(light9)
  }
  setModel(modelName) {
    return new Promise((resolve, reject) => {
      const loader = new GLTFLoader().setPath(`${host.host}file/model/`)
      loader.load(
        modelName + '.glb',
        (gltf) => {
          console.log(gltf);
          this.model && this.model.removeFromParent();
          this.model = gltf.scene
          if ("panzi.glb" == modelName && !this.panzi) {
            console.log("hi");
            this.panzi = this.model
            console.log(this.panzi);
            // this.spotlight3.intensity = 1;
          }
          console.log(this.panzi);

          this.scene.add(gltf.scene);
          resolve(this.modelName + "模型加载成功")
        },
        (e) => {
          //   console.log("模型加载进度");

          this.progressFn(e);
        }
      )
    })
  }
  changeCamera(position) {
    switch (position) {
      case 0:
        this.camera.position.x = 7;
        this.camera.position.y = 17;
        this.camera.position.z = 18;
        break;
      case 1:
        this.camera.position.x = 20;
        this.camera.position.z = 20;

        break;
      case 2:
        this.camera.position.y = 30;
        this.camera.position.z = 20;
        break;
      case 3:
        this.camera.position.y = -5;
        this.camera.position.z = 10;
        break;
      default:
        break;
    }
    this.controls.update()
  }
  async addMesh() {
    let res = await this.setModel("mouse")
    this.onFinish(res)
  }
  onWindowResize() {
    this.camera.aspect = window.innerWidth / window.innerHeight
    // 更改矩阵变换视角
    this.camera.updateProjectionMatrix()
    this.renderer.setSize(window.innerWidth, window.innerHeight)
  }
  // onMouseWheel(e) {
  //   let timeScale = e.deltaY > 0 ? 1 : -1
  //   // 调整视角转动方向
  //   this.animateAction.setEffectiveTimeScale(timeScale)
  //   this.animateAction.paused = false
  //   this.animateAction.play()
  //   if (this.timeoutid) {
  //     clearTimeout(this.timeoutid);
  //   }
  //   this.timeoutid = setTimeout(() => {
  //     this.animateAction.halt(0.5);
  //   }, 300);
  // }
}
export default Base3d