import Vue from 'vue'
import App from './App.vue'
import ElementUI, { Message, MessageBox ,Notification} from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import router from './router/index.js'
import store from './stroe/index'
import './assets/less/index.less'
import http from 'axios'
import './Api/mock.js'
import config from './config.js'
import api from './Api/index'
Vue.config.productionTip = false
Vue.use(ElementUI)
http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'
Vue.prototype.$http = http
Vue.prototype.$api = api;
Vue.prototype.$config = config;
Vue.prototype.$notify= Notification;

Vue.prototype.$comfirm = MessageBox.confirm
Vue.prototype.$message = Message
router.beforeEach((to, from, next) => {
  store.commit('getToken')
  const token = store.state.user.token
  if (!token && to.name !== 'login') {
    next({ name: 'login' })
  } else if (token && to.name === 'login') {
    next({ name: 'home' })
  } else {
    next()
  }
})
new Vue({
  store,
  router,
  render: h => h(App),
  created() {
    this.$store.commit('addMenu', router)
  }
}).$mount('#app')
