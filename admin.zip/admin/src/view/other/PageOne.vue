<template>
  <div>
    <div class="loading" v-show="isLoading">
      <Loading :progress="progress"></Loading>
    </div>
    <!-- <el-tag effect="plain" size="small" id="btn" @click="tap">{{state}}</el-tag> -->
    <el-tag effect="plain" size="small" id="btn" @click="goThree('http://www.baidu.com')">跳转到第三人称</el-tag>
    <div class="product" id="product" v-show="!isLoading">
      <div v-if="show">
          <div class="desc" :class="{active:pIndex == i}" v-for="(item,i) in products" :key="i">
            <h1 class="title">{{ item.desc.title }}</h1>
            <p class="content">{{ item.desc.content }}</p>
          </div>

        <div class="prod-list">
          <div class="products">
            <div class="prod-item" v-for="(prod,pI) in products" :key="pI" @click="changeModel(prod,pI)" :class="{ active: pI == pIndex }">
              <div class="prod-title">
                {{prod.title}}
              </div>
              <div class="img">
                <img :src="prod.imgsrc" :alt="prod">
              </div>
            </div>
          </div>
        </div>
        <div class="scene-list">
          <div class="scenes">
            <div class="scene-item" v-for="(scene, index) in scenes" @click="changeHdr(scene, index)" :key="index">
              <img :class="{ active: index == sceneIndex }" :src="`${host}file/hdr/${scene}.jpg`" :alt="scene" />
            </div>
          </div>
        </div>
        <div class="Camera" @click="changeCamera">
          <el-image style="width: 50px; height: 50px" :src="require('./carmer.png')" fit="fit"></el-image>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import host from '../../config.js'
import Loading from '@/components/Loading'
import Base3D from '@/utils/Base3D'
export default {
  components: {
    Loading
  },
  data() {
    return {
      products: [],
      isLoading: true,
      scenes: [],
      pIndex: 0,
      sceneIndex: 0,
      base3d: {},
      descIndex: 0,
      progress: 0,
      descIndex: 0,
      state: '放大',
      drawer: false,
      direction: 'ltr',
      show: false,
      host: host.host,
      CameraId: 0
    }
  },
  methods: {
    LoadingFinish() {
      this.isLoading = false
    },
    goThree(url) {
      window.location.href = url
    },
    tap() {
      let element = document.getElementById('product') //需要全屏容器的id
      // 浏览器兼容

      if (element.requestFullscreen) {
        element.requestFullscreen()
      } else if (element.webkitRequestFullScreen) {
        element.webkitRequestFullScreen()
      } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen()
      } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen()
      }
    },
    changeHdr(scene, index) {
      this.sceneIndex = index
      this.base3d.setEnvMap(scene)
    },
    changeModel(prod, pI) {
      this.pIndex = pI
      this.base3d.setModel(prod.modelUrl)
    },

    changeCamera() {
      this.CameraId += 1
      let h = this.$createElement
      switch (this.CameraId) {
        case 1:
          this.$message({
            title: '切换视角',
            message: h('i', { style: 'color: #3cabff' }, '右视摄像机')
          })
          break
        case 2:
          this.$message({
            title: '切换视角',
            message: h('i', { style: 'color: #3cabff' }, '远景俯视摄像机')
          })
          break
        case 3:
          this.$message({
            title: '切换视角',
            message: h('i', { style: 'color: #3cabff' }, '仰视摄像机')
          })
          break
        case 4:
          this.$message({
            title: '切换视角',
            message: h('i', { style: 'color: #3cabff' }, '近景摄像机')
          })
          break
        default:
          break
      }
      if (this.CameraId == 4) {
        this.CameraId = 0
      }
      this.base3d.changeCamera(this.CameraId)
    }
  },
  created() {
    this.$api.getModel().then(res => {
      console.log(res)
      this.products = res
    })
    let h = this.$createElement
    this.$notify({
      title: '交互提示',
      message: h('i', { style: 'color: #3cabff' }, '按下空格进行交互，回车放大')
    })
    let that = this
    document.onkeydown = function (e) {
      //对整个页面监听
      var keyNum = window.event ? e.keyCode : e.which //获取被按下的键值
      //判断如果用户按下了回车键（keycody=13）
      if (keyNum == 13) {
        that.tap()
      }
      if (keyNum == 32) {
        that.show = !that.show
      }
    }
  },
  mounted() {
    this.$store.commit('collapseMenu')
    this.scenes = ['雪地', '000', '001', '002', '003', '004', '005', '006', '007', '008']
    this.base3d = new Base3D('#product', this.LoadingFinish)
    this.base3d.onProgress(e => {
      let progressNum = e.loaded / 8109796
      progressNum = progressNum.toFixed(2) * 10
      this.progress = progressNum
    })
  }
}
</script>

<style scoped lang="less">
#product {
  position: relative;
  margin-top: 10px;
}
#btn {
  position: absolute;
  right: 50px;
  margin-top: -30px;
}
.large {
  width: 100%;
  height: 100%;
}
.small {
  width: 1450px;
  height: 634px;
}
.body {
  width: 100px;
}
.desc {
  position: fixed;
  z-index: 100000;
  background-color: rgba(255, 255, 255, 0.5);
  width: 500px;
  top: 100px;
  left: 50%;
  margin-left: -300px;
  transition: all 0.5s;
  transform: translate(-100vw, 0);
  padding: 15px;
}
.desc.active{
  transform: translate(0, 0);
}
.desc .title {
  text-align: center;
  font-size: 36px;
  font-weight: 700;
}
.desc .content {
  text-indent: 2em;
  margin-top: 10px;
  font-size: 20px;
  font-weight: 500;
}
.prod-list {
  position: fixed;
  overflow: auto;
  width: 220px;
  height: 100vh;
  z-index: 100000;
  transition: all 0.5s;
  background-color: rgba(255, 255, 255, 0.6);
  left: 0;
  top: 0;
  h1 {
    font-size: 20px;
    font-weight: 900;
    padding: 10px 25px 0;
  }
  .products {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    .prod-item {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 190px;
      height: 140px;
      border-color: #fff;
      border-radius: 20px;
      overflow: hidden;
      margin: 10px 0;
      box-shadow: 2px 2px 5px #666;
      transition: all 0.3s;
      &.active {
        box-shadow: 2px 2px 5px #666, 0px 0px 10px rgb(123, 176, 206);
      }
      &:hover {
        transform: translate(0px, -5px);
        box-shadow: 2px 2px 5px #666, 0px 0px 10px rgb(166, 229, 238);
        // background-color: orange;
      }
      img {
        width: 190px;
        height: 140px;
        margin-bottom: 10px;
      }
      .prod-title {
        padding: 0 20px;
      }
    }
  }
}
.prod-list.hidden {
  transform: translate(-100%, 0);
}
.scene-list {
  width: 300px;
  height: 100vh;
  padding: 60px 0 0;
  position: fixed;
  z-index: 100000;
  transition: all 0.5s;
  background-color: rgba(255, 255, 255, 0.6);
  right: 0;
  top: 0;
  overflow-y: auto;
  h3 {
    font-size: 20px;
    font-weight: 900;
    padding: 0 30px;
  }
  .scenes {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }

  .scene-item {
    padding: 6px 0;

    img {
      width: 250px;
      border-radius: 10px;
      box-shadow: 2px 2px 10px #666;
      transition: all 0.3s;
      &.active {
        box-shadow: 2px 2px 5px #666, 0px 0px 10px rgb(172, 215, 221);
      }
      &:hover {
        transform: translate(0px, -5px);
        box-shadow: 2px 2px 5px #666, 0px 0px 10px rgb(107, 95, 90);
      }
    }
  }
}
.scene-list.hidden {
  transform: translate(100%, 0);
}
.Camera {
  position: fixed;
  width: 50px;
  height: 50px;
  z-index: 100000;
  transition: all 0.5s;
  background-color: rgba(255, 255, 255, 0.6);
  left: 20vw;
  bottom: 20px;
}
</style>