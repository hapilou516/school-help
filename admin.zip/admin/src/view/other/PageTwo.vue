<template>
  <div>我是page2页面</div>
</template>

<script>
export default {

}
</script>

<style>

</style>