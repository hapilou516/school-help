<template>
  <div class="mange">
    <el-dialog :title="operateType === 'detail' ? '详细信息' : '更新用户'" :visible.sync="isShow">
      <!-- 插入组件 -->
      <commom-form :formLabel="opertateFormLabel" :form="operateForm" ref="form" :inline="true" v-if="operateType === 'edit'"></commom-form>
      <commom-show :form="detailsData" :id="goodsId" :inline="true" v-if="operateType === 'detail'"></commom-show>
      <!-- 自定义插槽 -->
      <div slot="footer" class="dialog-footer">
        <el-button @click="isShow = false">取消</el-button>
        <el-button type="primary" @click="comfirm">确定</el-button>
      </div>
    </el-dialog>
    <div class="manage-header">
      <div>
        <el-dropdown @command="handleCommand">
          <span class="el-dropdown-link">
            筛选类别<i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item v-for="(item,index) in collection" :key="index" :command="index">{{item}}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <el-dropdown @command="handleStateCommand">
          <span class="el-dropdown-link">
            筛选订单状态<i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item v-for="(item,index) in states" :key="index" :command="index">{{item}}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>

      <commom-form :formLabel="formLabel" :form="searchForm" ref="form" :inline="true">
        <el-button type="primary" @click="getList(searchForm.keyword)">搜索</el-button>
      </commom-form>
    </div>
    <commom-table style="height:600px" :tableData="tableData" :tableLabel="tableLabel" :config="config" @changePage="getList()" @edit='editUser' @del="delteUser" @detail='detailOrder'>
    </commom-table>
  </div>
</template>

<script>
import CommomForm from '@/components/CommomForm.vue'
import CommomTable from '@/components/CommomTable.vue'
import CommomShow from '@/components/CommomShow.vue'
import time from '../../utils/time'
export default {
  components: {
    CommomForm,
    CommomTable,
    CommomShow
  },
  data() {
    return {
      operateType: 'add',
      isShow: false,
      goodsId: '',
      collection: ['学习', '数码', '装饰品', '衣物', '运动器材', '化妆品', '交通工具', '其他'],
      states: ['上架中', '等待发货', '交易完成', '取消中订单', '已取消订单', '下架商品', '订单纠纷'],
      opertateFormLabel: [
        {
          model: 'id',
          label: '商品编号',
          type: 'input'
        },
        {
          model: 'time',
          label: '发布时间',
          type: 'input'
        },
        {
          model: 'goods',
          label: '商品标题',
          type: 'input'
        },

        {
          model: 'collection',
          label: '分类',
          type: 'select',
          college: [
            {
              name: '学习',
              id: 0
            },
            {
              name: '数码',
              id: 1
            },
            {
              name: '装饰品',
              id: 2
            },
            {
              name: '衣物',
              id: 3
            },
            {
              name: '运动器材',
              id: 4
            },
            {
              name: '化妆品',
              id: 5
            },
            {
              name: '交通工具',
              id: 6
            },
            {
              name: '其他',
              id: 7
            }
          ]
        },
        {
          model: 'price',
          label: '价格',
          type: 'input'
        },
        {
          model: 'phone',
          label: '联系电话',
          type: 'input'
        },
        {
          model: 'state',
          label: '物流状态',
          type: 'select',
          college: [
            {
              name: '上架中',
              id: 0
            },
            {
              name: '等待发货',
              id: 1
            },
            {
              name: '交易完成',
              id: 2
            },
            {
              name: '取消中订单',
              id: 3
            },
            {
              name: '已取消订单',
              id: 4
            },
            {
              name: '下架商品',
              id: 5
            },
            {
              name: '订单纠纷',
              id: 6
            }
          ]
        }
      ],
      operateForm: {
        id: '',
        time: '',
        goods: '',
        collection: '',
        price: 0,
        phone: '',
        state: ''
      },

      detailsData: {
        // id: '',
        // time: '',
        // goods: '',
        // collection: '',
        // price: 0,
        // phone: '',
        // state: '',
        // imageURl:'',
        // thingsid:0,
        // note:''
      },
      formLabel: [
        {
          model: 'keyword',
          label: '',
          type: 'input'
        }
      ],
      searchForm: {
        keyword: ''
      },
      tableData: [],
      tableLabel: [
        {
          prop: 'id',
          label: '商品编号'
        },
        {
          prop: 'goods',
          label: '商品标题'
        },
        {
          prop: 'time',
          label: '发布时间',
          sort: true,
          width: 180
        },
        {
          prop: 'collection',
          label: '分类'
        },
        {
          prop: 'price',
          label: '价格',
          width: 100
        },
        {
          prop: 'phone',
          label: '联系电话',
          width: 150
        },
        {
          prop: 'state',
          label: '物流状态',
          width: 150
        }
      ],
      config: {
        page: 1,
        total: 20
      }
    }
  },

  methods: {
    comfirm() {
      if (this.operateType === 'edit') {
        this.$api.updateOrder(this.operateForm).then(res => {})
        this.isShow = false
        this.getList()
      } else {
        this.$http.post('/user/add', this.operateForm).then(res => {
          this.isShow = false
          this.getList()
        })
      }
    },
    editUser(row) {
      console.log(row)
      this.isShow = true
      this.operateType = 'edit'

      this.operateForm = JSON.parse(JSON.stringify(row))
    },
    detailOrder(row) {
      console.log(row.id)

      this.isShow = true
      this.operateType = 'detail'
      this.goodsId = row.id

      // console.log(this.operateType);
    },
    delteUser(row) {
      this.$comfirm('此操作将永久删除订单', '提示', {
        comfirmButtonText: '确认',
        canceButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const id = row.id
        this.$api
          .delOrder({
            id
          })
          .then(res => {
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            this.getList()
          })
      })
    },
    handleCommand(command) {
      this.$api.selectCollectionOrder({ id: command }).then(res => {
        let tableData = []

        let collection = ['学习', '数码', '装饰品', '衣物', '运动器材', '化妆品', '交通工具', '其他']
        let states = ['上架中', '等待发货','交易完成', '取消中订单', '已取消订单', '下架商品', '订单纠纷']
        res.list.forEach(item => {
          if (item.state <0) {
            item.state = 2
          }
          let data = {
            id: item._id,
            time: time.formatTime(item.time, 'Y/M/D h:m:s'),
            goods: item.info.title,
            collection: collection[Number(item.info.collegeid)],
            price: item.money,
            phone: item.pulishPhone,
            state: states[item.state]
          }
          tableData.push(data)
        })
        this.tableData = tableData
        // this.tableData = res.list.map(item => {
        //   item.sexLabel = item.sex === 0 ? '女' : '男'
        //   return item
        // })
        this.config.total = res.count
        // this.config.page += 1
        this.config.loading = false
      })
    },
    handleStateCommand(command) {
      this.$api.selectStateOrder({ id: command }).then(res => {
        let tableData = []

        let collection = ['学习', '数码', '装饰品', '衣物', '运动器材', '化妆品', '交通工具', '其他']
        let states = ['上架中', '等待发货', '交易完成', '取消中订单', '已取消订单', '下架商品', '订单纠纷']
        res.list.forEach(item => {
          if (item.state < 0) {
            item.state = 2
          }
          let data = {
            id: item._id,
            time: time.formatTime(item.time, 'Y/M/D h:m:s'),
            goods: item.info.title,
            collection: collection[Number(item.info.collegeid)],
            price: item.money,
            phone: item.pulishPhone,
            state: states[item.state]
          }
          tableData.push(data)
        })
        this.tableData = tableData
        // this.tableData = res.list.map(item => {
        //   item.sexLabel = item.sex === 0 ? '女' : '男'
        //   return item
        // })
        this.config.total = res.count
        // this.config.page += 1
        this.config.loading = false
      })
    },
    getList(name = '') {
      this.config.loading = true
      name ? (this.config.page = 1) : ''
      let page = this.config.page

      this.$api.getAllOrder({ page, pageSize: 10, name }).then(res => {
        let tableData = []

        let collection = ['学习', '数码', '装饰品', '衣物', '运动器材', '化妆品', '交通工具', '其他']
        let states = ['上架中', '等待发货', '交易完成', '取消中订单', '已取消订单', '下架商品', '订单纠纷']
        res.list.forEach(item => {
          if (item.state < 0) {
            item.state = 2
          }
          let data = {
            id: item._id,
            time: time.formatTime(item.time, 'Y/M/D h:m:s'),
            goods: item.info.title,
            collection: collection[Number(item.info.collegeid)],
            price: item.money,
            phone: item.pulishPhone,
            state: states[item.state]
          }
          tableData.push(data)
        })
        this.tableData = tableData
        // this.tableData = res.list.map(item => {
        //   item.sexLabel = item.sex === 0 ? '女' : '男'
        //   return item
        // })
        this.config.total = res.count
        // this.config.page += 1
        this.config.loading = false
      })
    }
  },
  created() {
    this.getList()
  }
}
</script>

<style lang="less" scoped>
.manage-header {
  display: flex;
  justify-content: space-between;
  max-height: 80px;
  padding: 20px 0px 0px 0px;
}
.el-dropdown {
  height: 20px;
  margin-right: 20px;
}
.el-dropdown-link {
  cursor: pointer;
  background-color: #fff;
  border: #b3d8ff 1px solid;
  color: #409eff;
  padding: 5px;
  margin-top: 10px;
  text-align: center;
  margin: 0 auto;
  line-height: 20px;
  font-size: 12px;
}
.el-icon-arrow-down {
  font-size: 12px;
}
</style>