<template>
  <div class="wrap">
    <div class="form">
      <div class="left">
        <video src="../../video/video.mp4" muted loop autoplay></video>
      </div>
      <div class="right">
        <div class="right-con">
          <el-form ref="form" :model="form" label-width="180px" status-icon :rules="rules" class="login-container">
            <h1 class="login_title">闲柠校园后台管理</h1>
            <el-form-item label="用户名" label-width="80px" prop="username" class="username">
              <el-input v-model="form.username" type="input" auto-complete="off" placeholder="请输入账号" class="text"></el-input>
            </el-form-item>
            <el-form-item label="密码" label-width="80px" prop="password" class="password">
              <el-input type="password" v-model="form.password" auto-complete="off" placeholder="请输入密码" class="text"></el-input>
            </el-form-item>
            <div class="btns">
              <el-button type="primary" @click="login" class="login_submint">登录</el-button>
              <el-button type="primary" @click="register" class="login_submint">注册</el-button>
            </div>

            <el-checkbox v-model="isMoveAnimated" style="color:#70b4e3" class="animate">是否有动画</el-checkbox>

          </el-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isMoveAnimated: false,
      form: {},
      rules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          {
            min: 3,
            message: '用户名长度不能小于3位',
            trigger: 'blur'
          }
        ],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
      }
    }
  },
  methods: {
    async login() {
      await this.$api.login(this.form).then(res => {
        const { data } = res
        if (res.status == 0) {
        const { admin } = data

          this.$store.commit('clearMenu')
          this.$store.commit('setMenu', res.data.menu)
          this.$store.commit('setToken', res.token)
          this.$store.commit('addMenu', this.$router)
          if (data.root) {
            this.$store.commit('setAdmin', '超级管理员')
          }
          if (this.isMoveAnimated) {
            this.$store.commit('setnickname', admin.nickName)
            this.$store.commit('setInfo', admin)
            this.$router.push({ name: 'animate' })
          } else {
            this.$store.commit('setInfo', admin)

            this.$router.push({ name: 'home' })
          }
        } else {
          this.$message.error(res)
        }
      })
      // const token = Mock.Random.guid()
      // this.$store.commit('setToken', token)
    },
    async register() {
      console.log(this.form.username)
      if (this.form.username.length < 3 || this.form.password.length < 6) {
        if (this.form.username.length < 3) {
          this.$message.error('用户名不能低于3位')
        } else {
          this.$message.error('密码不能低于6位')
        }
      } else {
        await this.$api.register(this.form).then(res => {
          console.log(res)
          if (res == '用户注册成功') {
            this.$message.success('注册成功，请登录')
          }
          if (res == '用户名已被占用') {
            this.$message.error('用户名已被占用')
          }
        })
      }
    }
  }
}
</script>

<style lang="less" scoped>
.wrap {
  width: 100%;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-image: linear-gradient(to left top, #d16ba5, #c777b9, #ba83ca, #aa8fd8, #9a9ae1, #8aa7ec, #79b3f4, #69bff8, #52cffe, #41dfff, #46eefa, #5ffbf1);
}

.form {
  width: 900px;
  height: 560px;
  display: flex;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 25px 45px rgba(0, 0, 0, 0.1);
}

.left {
  width: 500px;
  height: 560px;
}

.left video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.right {
  text-align: center;
  width: 400px;
  height: 560px;
  background: rgba(255, 255, 255, 0.9);
  display: flex;
  justify-content: center;
  align-items: center;
}

.right-con {
  width: 70%;
  display: flex;
  flex-direction: column;
  text-align: center;
}

h1 {
  font-size: 26px;
  color: #70b4e3;
  font-weight: 400;
  padding-bottom: 10px;
}

/deep/.el-form-item__label {
  font-size: 16px;
  font-weight: 400;
  color: #70b4e3;
  // padding: 20px 0;
}

.text {
  width: 100%;
  outline: none;
  border: none;
  border-bottom: 1px solid #70b4e3;
  color: #366ae6;
  background-color: rgba(0, 0, 0, 0);
}

.login_submint {
  width: 100%;
  height: 40px;
  border-radius: 20px;
  border: none;
  color: #fff;
  font-size: 16px;
  cursor: pointer;

  background-image: linear-gradient(120deg, #76daec 0%, #c5a8de 100%);
}

.login_submint:hover {
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}
.login-container {
  text-align: start;
}
.login_title {
  margin: 0px auto 40px auto;
  text-align: center;
  // color: #505458;
}
.btns {
  display: flex;
  height: 100px;
  text-align: center;
  padding: 20px 0px 0px 30px;
}
div .animate {
  text-align: right;
  margin-left: 200px;
}
</style>