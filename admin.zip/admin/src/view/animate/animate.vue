<template>
  <div class="container">
    <div class="item">
      <div class="part1"></div>
      <div class="part2"></div>
      <div class="part3"></div>
      <div class="part4"></div>
      <div class="part5"></div>
    </div>
    <div class="item">
      <div class="part1"></div>
      <div class="part2"></div>
      <div class="part3"></div>
      <div class="part4"></div>
      <div class="part5"></div>
    </div>
    <div class="item">
      <div class="part1">大</div>
      <div class="part2">大</div>
      <div class="part3">大</div>
      <div class="part4">大</div>
      <div class="part5">大</div>
    </div>
    <div class="item">
      <div class="part1">家</div>
      <div class="part2">家</div>
      <div class="part3">家</div>
      <div class="part4">家</div>
      <div class="part5">家</div>
    </div>
    <div class="item">
      <div class="part1">好</div>
      <div class="part2">好</div>
      <div class="part3">好</div>
      <div class="part4">好</div>
      <div class="part5">好</div>
    </div>
    <div class="item">
      <div class="part1"></div>
      <div class="part2">我</div>
      <div class="part3">我</div>
      <div class="part4">我</div>
      <div class="part5">我</div>
    </div>
    <div class="item">
      <div class="part1"></div>
      <div class="part2"></div>
      <div class="part3">叫</div>
      <div class="part4">叫</div>
      <div class="part5">叫</div>
    </div>

      <div class="item"  v-for="(item,index) in nickNameArr " :key="index">
      <div class="part1"></div>
      <div class="part2"></div>
      <div class="part3"></div>
      <div class="part4">{{item}}</div>
      <div class="part5">{{item}}</div>
    </div>
    <el-button type="primary" v-if="isButton" class="continue" @click="toMain">继续</el-button>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  data() {
    return {
      time: 7000,
      nickNameArr:[],
      isButton:false
    }
  },
  created() {
    this.spitNickNameArr()
    this.isOver()
  },
  computed: {
    // 将数据仓库的数据注入到header主件里
    ...mapState({
      nickName: state => state.user.nickName
    }),
  },
  methods: {
    isOver() {
      console.log(this.nickname);
      setTimeout(() => {
        this.isButton = true
      }, this.time)
    },
    spitNickNameArr(){
      this.nickNameArr = [...this.nickName.split('')]
      while(this.nickNameArr.length <5){
        this.nickNameArr.push(" ")
      }
      console.log(this.nickNameArr);
    },
    toMain(){
      this.$router.push({name:'Main'})
    }
  }
}
</script>

<style lang="less" scoped>
*{
  padding: 0;
  margin: 0;
}
html {
  height: 100%;
}
body {
  height: 100%;
  background-color: black;
}
.container {
  display: flex;
  width: 100%;
  height: 100%;
  font-size: 0;
}
.container .item {
  height: 100%;
  width: calc(100% / 12);
  display: inline-block;
  vertical-align: top;
  position: relative;
}

.container .item .part1,
.part2,
.part3,
.part4,
.part5 {
  font-size: 30px;
  color: rgb(255, 255, 255);
  height: 100%;
  width: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  font-style: italic;
  position: absolute;
  top: 0;
  left: 0;
}
.container .item .part1 {
  background-color: rgb(255, 202, 64);
  z-index: 1;
  animation: part 0.8s linear 0s forwards;
}
.container .item .part2 {
  background-color: rgb(77, 198, 255);
  z-index: 2;
  animation: part 0.4s linear 1.6s forwards;
}
.container .item .part3 {
  background-color: rgb(136, 216, 117);
  z-index: 3;
  animation: part 0.4s linear 2.1s forwards;
}
.container .item .part4 {
  background-color: rgb(255, 117, 76);
  z-index: 4;
  animation: part 0.4s linear 2.6s forwards;
}
.container .item .part5 {
  background-color: rgb(0, 0, 0);
  text-shadow: 0.2em 0 0.2em rgb(26, 26, 209), -0.2em 0 0.2em rgb(26, 26, 209), 0 -0.2em 0.2em rgb(26, 26, 209), 0 0.2em 0.2em rgb(26, 26, 209);
  z-index: 5;
}
.container .item:nth-child(1) .part5 {
  animation: part 0.4s linear 5s forwards;
}
.container .item:nth-child(2) .part5 {
  animation: part 0.4s linear 5.1s forwards;
}
.container .item:nth-child(3) .part5 {
  animation: part 0.4s linear 5.2s forwards;
}
.container .item:nth-child(4) .part5 {
  animation: part 0.4s linear 5.3s forwards;
}
.container .item:nth-child(5) .part5 {
  animation: part 0.4s linear 5.4s forwards;
}
.container .item:nth-child(6) .part5 {
  animation: part 0.4s linear 5.5s forwards;
}
.container .item:nth-child(7) .part5 {
  animation: part 0.4s linear 5.6s forwards;
}
.container .item:nth-child(8) .part5 {
  animation: part 0.4s linear 5.7s forwards;
}
.container .item:nth-child(9) .part5 {
  animation: part 0.4s linear 5.8s forwards;
}
.container .item:nth-child(10) .part5 {
  animation: part 0.4s linear 6s forwards;
}
.container .item:nth-child(11) .part5 {
  animation: part 0.4s linear 6.1s forwards;
}
.container .item:nth-child(12) .part5 {
  animation: part 0.4s linear 6.1s forwards;
}
@keyframes part {
  0% {
    width: 0px;
  }
  100% {
    width: 100%;
  }
}
.continue{
  position: absolute; /*绝对对位*/
  bottom: 6%; /*距上部*/
  right: 3%; 
  transform: translate(-50%,-50%); /*移动，根据X,Y轴*/
  width: 150px; /*宽*/
  height: 50px; /*高*/
  text-align: center; /*字体水平居中*/
  font-size: 30px; /*字体大小*/
  line-height: 50px; /*行高*/
  color:white;
  text-transform: uppercase; /*字体大写*/
  text-decoration: none; /*字体增加装饰：去除下划线*/
  font-family: sans-serif; /*非衬线体*/  
  box-sizing: border-box; /*盒模型大小规则*/
  background: linear-gradient(
    90deg,#03a9f4, #f441a5, #ffeb3b, 
  #03a9f4, #f441a5, #ffeb3b, #03a9f4); /*渐变背景*/
  border-radius: 60px; /*边框圆角*/
  background-size: 400%; /*背景大小*/
  z-index: 99; /*层叠定位*/
}
.continue:hover{
  animation: animate 8s linear infinite alternate; /*动画: 名称 时间 线性 循环 播放完回退播放*/
}
@keyframes animate{
  0%{
    background-position: 0%; /*修改背景定位，实现渐变色炫光*/
  }
  50%{
    background-position: 100%;
  }
  100%{
    background-position: 0%;
  }
}
.continue::before{ /*之前添加*/
  content: ''; /*内容*/
  position: absolute; /*绝对定位*/
  top:-5px; /*当设置对立的2个定位属性时，元素的大小将由对立的大小决定*/
  left: -5px;
  right: -5px;
  bottom: -5px; /*当设置对立的2个定位属性时，元素的大小将由对立的大小决定*/
  z-index: -1; 
  background: linear-gradient(
    90deg,#03a9f4, #f441a5, #ffeb3b, #03a9f4, 
  #f441a5, #ffeb3b, #03a9f4);
  border-radius: 40px;
  background-size: 400%;
  filter: blur(20px); /*过渡：模糊*/
  opacity: 0; /*透明度*/
  transition: 1s; /*过渡时间*/
}
.continue:hover::before{
  filter: blur(20px);
  opacity: 1;
  animation: animate 8s linear infinite; /*注意动画名称统一*/
}

</style>