<template>
  <div class="mange">
    <el-dialog :title="operateType === 'add' ? '新增管理员' : '更新管理员'" :visible.sync="isShow">
      <!-- 插入组件 -->
      <commom-form :formLabel="opertateFormLabel" :form="operateForm" ref="form" :inline="true"></commom-form>
      <!-- 自定义插槽 -->
      <div slot="footer" class="dialog-footer">
        <el-button @click="isShow = false">取消</el-button>
        <el-button type="primary" @click="comfirm">确定</el-button>
      </div>
    </el-dialog>
    <div class="manage-header">
      <div>
        <el-button type="primary" @click="addAdmin">+ 新增</el-button>
      </div>

      <commom-form :formLabel="formLabel" :form="searchForm" ref="form" :inline="true">
        <el-button type="primary" @click="getList(searchForm.keyword)">搜索</el-button>
      </commom-form>
    </div>
    <commom-table style="height:600px" :tableData="tableData" :tableLabel="tableLabel" :config="config" @changePage="getList()" :tableType='tableType' @edit='editUser' @del="delteUser" >
    </commom-table>
  </div>
</template>

<script>
import CommomForm from '@/components/CommomForm.vue'
import CommomTable from '@/components/CommomTable.vue'
import CommomShow from '@/components/CommomShow.vue'
import time from '../../utils/time'
export default {
  components: {
    CommomForm,
    CommomTable,
    CommomShow
  },
  data() {
    return {
      operateType: 'add',
      tableType: 'admin',
      isShow: false,
      opertateFormLabel: [
        {
          model: '_id',
          label: '管理员编号',
          type: 'input'
        },
        {
          model: 'time',
          label: '更新时间',
          type: 'input'
        },
        {
          model: 'userName',
          label: '账号',
          type: 'input'
        },
        {
          model: 'password',
          label: '密码',
          type: 'input'
        },
        {
          model: 'nickName',
          label: '昵称',
          type: 'input'
        },
        {
          model: 'root',
          label: '权限',
          type: 'select',
          college: [
            {
              name: '超级管理员',
              value: true
            },
            {
              name: '管理员',
              value: false
            }
          ]
        },
        {
          model: 'avator',
          label: '头像',
          type: 'avator'
        }
      ],
      operateForm: {
        _id: '',
        time: '',
        userName: '',
        root: '管理员',
        password: '',
        nickName: 0,
        avator: ''
      },
      formLabel: [
        {
          model: 'keyword',
          label: '',
          type: 'input'
        }
      ],
      searchForm: {
        keyword: ''
      },
      tableData: [],
      tableLabel: [
        {
          prop: '_id',
          label: '管理员编号',
          width: 220
        },
        {
          prop: 'time',
          label: '创建时间',
          sort: true,
          width: 160
        },
        {
          prop: 'userName',
          label: '账号',
          width: 120
        },
        {
          prop: 'password',
          label: '密码',
          width: 120
        },
        {
          prop: 'root',
          label: '权限',
          width: 120
        },
        {
          prop: 'nickName',
          label: '昵称',
          width: 120
        },
        {
          prop: 'avator',
          label: '头像',
          width: 120
        }
      ],
      config: {
        page: 1,
        total: 20
      }
    }
  },

  methods: {
    comfirm() {
      if (this.operateType === 'edit') {
        this.$api.updateAdmin(this.operateForm).then(res => {})
        this.isShow = false
        this.getList()
      } else {
        const admin = this.operateForm
        if (!admin.avator || !admin.nickName || !admin.password || !admin.root) {
          this.$message({
            type: 'error',
            message: '请填写完整'
          })
        } else {
          this.$api.addAdmin(this.operateForm).then(res => {
            console.log(res);
            if (res == 'success') {
              this.isShow = false
              this.$message({
                type: 'success',
                message: '添加成功'
              })
              this.getList()
            } else {
              this.$message({
                type: 'error',
                message: res
              })
            }
          })
        }
      }
    },
    addAdmin() {
      this.isShow = true
      this.operateType = 'add'
      this.operateForm = {
        _id: '',
        time: '',
        userName: '',
        root: '管理员',
        password: '',
        nickName: '',
        avator: ''
      }
    },
    editUser(row) {
      console.log(row)
      this.isShow = true
      this.operateType = 'edit'

      this.operateForm = JSON.parse(JSON.stringify(row))
    },
    delteUser(row) {
      this.$comfirm('此操作将永久删除订单', '提示', {
        comfirmButtonText: '确认',
        canceButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const id = row._id
        this.$api
          .delAdmin({
            id
          })
          .then(res => {
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            this.getList()
          })
      })
    },
    getList(name = '') {
      this.config.loading = true
      name ? (this.config.page = 1) : ''
      let page = this.config.page

      this.$api.getAdmin({ page, pageSize: 10, name }).then(res => {
        console.log(res)

        this.tableData = res.list
        this.tableData = res.list.map(item => {
          item.time = time.formatTime(item.time, 'Y/M/D h:m:s')
          item.root = item.root === true ? '超级管理员' : '管理员'
          return item
        })
        this.config.total = res.count
        // this.config.page += 1
        this.config.loading = false
      })
    }
  },
  created() {
    this.getList()
  }
}
</script>

<style lang="less" scoped>
.manage-header {
  display: flex;
  justify-content: space-between;
  max-height: 80px;
  padding: 20px 0px 0px 0px;
}
.el-dropdown {
  height: 20px;
  margin-right: 20px;
}
.el-dropdown-link {
  cursor: pointer;
  background-color: #fff;
  border: #b3d8ff 1px solid;
  color: #409eff;
  padding: 5px;
  margin-top: 10px;
  text-align: center;
  margin: 0 auto;
  line-height: 20px;
  font-size: 12px;
}
.el-icon-arrow-down {
  font-size: 12px;
}
</style>