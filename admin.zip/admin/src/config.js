const address = 'https://taoan.top/admin';
const host = 'https://taoan.top/'
export default {
  address,    //地址
  host
}
