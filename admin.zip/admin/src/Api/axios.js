import axios from "axios"
import config from "@/config/config"
// 根据配置文件的模式选择适应的接口地址
const baseUrl = process.env.NODE_ENV === 'development' ? config.baseUrl.dev : config.baseUrl.pro
class HttpRequest {
  constructor(baseUrl){
    this.baseUrl = baseUrl
  }
  // 设置配置入口
  getInsideConfig(){
    const config = {
      baseUrl:this.baseUrl,
      header:{}
    }
    return config
  }
  // 加入拦截器函数
  interceptors(instance){
    instance.interceptors.request.use(function (config) {
      // 在发送请求之前做些什么
      return config;
    }, function (error) {
      // 对请求错误做些什么
      return Promise.reject(error);
    });
  
  // 添加响应拦截器
  instance.interceptors.response.use(function (response) {
    console.log(response);
      // 2xx 范围内的状态码都会触发该函数。
      // 对响应数据做点什么
      return response;
    }, function (error) {
      // 超出 2xx 范围的状态码都会触发该函数。
      // 对响应错误做点什么
      console.log(error);
      return Promise.reject(error);
    });
  }
  request(options){
    const instance = axios.create()
    options = {
      ...this.getInsideConfig(),...options
    }
    this.interceptors(instance)
    return instance(options)
  }
}
export default new HttpRequest(baseUrl)