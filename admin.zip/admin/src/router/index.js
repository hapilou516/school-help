import Main from '../view/Main.vue'
import home from '../view/home/index.vue'
import user from '../view/user/index.vue'
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

const routes = [
  {
    path: '/', name: 'Main', component: Main,
    redirect: '/home',
    children: [
      {
        path: '/home',
        name: 'home',
        component: home
      },
      {
        path: '/user',
        name: 'user',
        component: user
      },
      {
        path: '/mall',
        name: 'mall',
        component: () => import('../view/mall/index.vue')
      },
      {
        path: '/admin',
        name: 'admin',
        component: () => import('../view/admin/index.vue')
      },
      {
        path: '/page1',
        name: 'page1',
        component: () => import('../view/other/PageOne.vue')
      },
      {
        path: '/page2',
        name: 'page2',
        component: () => import('../view/other/PageTwo.vue')
      },
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('../view/Login/beatifuLogin.vue')
  },
  {
    path: '/animate',
    name: 'animate',
    component: () => import('../view/animate/animate.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
