import axios from "axios"
export default{
  baseUrl:{
    dev:'/api/',
    pro:''
  }
}
