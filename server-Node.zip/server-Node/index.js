const express = require("express")
const Cors = require('CORS')
const expressJwt = require("express-jwt")
const app = express()
const { Order, Collection, Rooms, User, ChatRoom, Admin } = require("./db")
const request = require("request")
const multer = require("multer")
const admin = require("./admin.js")
const { date, object } = require("joi")
const crypto = require("crypto")
const { del } = require("request")
// express 获取post请求转码
app.all('*', (req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', "*");
  res.setHeader('Access-Control-Allow-Headers', "*");
  next()
})
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
// 是否允许客户端访问本地静态资源
app.use(express.static(__dirname))
// 跨域处理

app.use(Cors())
app.use(express.urlencoded({ extended: false }))
/* 

调用管理员接口

*/
app.use('/admin', admin)
/* 
  测试端 
*/


// 测试接口
app.get("/api/test", async (req, res) => {
  res.send("success")
})

/* 
  登录接口
*/

// 登录
app.get("/login", async (req, res) => {
  const { code } = req.query
  request({
    url: `https://api.weixin.qq.com/sns/jscode2session?appid=wx52b156d9541d098c&secret=b19d3691e02beef823bd50389688bc10&js_code=${code}&grant_type=authorization_code`
  }, (err, response, data) => {

    res.send(data)
  })
})

/* 

消息推送

*/
// 订单模板消息
// h3PjfUYf-wE6tSvgTBRUc7w6gCEo4JU4RsbyjvhWKV0
function send(token) {
  console.log(token);

}
app.get("/token", async (req, res) => {
  request({
    url: `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx52b156d9541d098c&secret=b19d3691e02beef823bd50389688bc10`
  }, (err, response, data) => {
    console.log(data);
    res.send(data)
  })
})
app.get("/token/sendTemplate", async (req, res) => {
  console.log("dafa");
  const { token, openid, name, address, title, note } = req.query
  msgUrl = "https://api.weixin.qq.com/cgi-bin/message/subscribe/send"
  msgUrl = msgUrl + "?access_token=" + token
  let object = {
    "touser": openid,
    "template_id": "h3PjfUYf-wE6tSvgTBRUc7w6gCEo4JU4RsbyjvhWKV0",
    "page": "pages/myPush/myPush",
    "miniprogram_state": "formal",
    "lang": "zh_CN",
    "data": {
      "thing4": {
        "value": name
      },
      "thing5": {
        "value": address
      },
      "thing7": {
        "value": title
      },
      "thing11": {
        "value": note
      }
    }
  }
  request({
    url: msgUrl,
    json: object,
    method: "POST"
  }, (err, response, data) => {
    // const token =  data.access_token

    console.log(data);

    res.send(data)
  })
})
// 注册消息模板
app.get("/tokenCheck", async (req, res) => {
  console.log(req.query);
  let signature = req.query.signature,
    timestamp = req.query.timestamp,
    nonce = req.query.nonce,
    echostr = req.query.echostr;
  let a = crypto.createHash('sha1').update([pushToken, timestamp, nonce].sort().join('')).digest('hex');  // 这里的pushToken就是在上面的那里配置的Token   
  if (a == signature) {
    // 如果验证成功则原封不动的返回
    res.send(echostr);
  } else {
    res.send({
      status: 400,
      data: "check msg error"
    })
  }
})

/* 
  上传文件、图片
*/

// 配置传送文件
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // 配置存储路径
    cb(null, './file/image')
  },
  filename: (req, file, cb) => {
    // 匹配jpg的正则
    let type = file.originalname.replace(/.+\./, '.')
    if (!!req.body.name) {
      cb(null, req.body.name + type)
    }
    cb(null, Date.now() + type)
  }
})
const upload = multer({ storage: storage })


// 上传文件的接口
// 最多上传10个文件
app.post("/uploadImg", upload.array("file", 10), (req, res) => {

  res.send(req.files)
})


/* 


用户接口


*/
app.get("/user/check", async (req, res) => {
  try {
    const { _id } = req.query
    console.log(_id);
    const result = await User.find({
      openid: _id
    })
    res.send(result)
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})
app.get("/user/getPower", async (req, res) => {
  try {
    const { _id } = req.query
    const result = await User.find({
      openid: _id
    })
    res.send(result[0].root)
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})
app.post("/user/add", async (req, res) => {
  try {
    console.log(req.body);
    await User.create(req.body)
    res.send("success")
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})
app.get("/user/remove", async (req, res) => {
  try {
    const { openid } = req.query
    await User.findOneAndUpdate({ openid }, {
      isLogin: false
    })
    res.send("success")
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})
app.post("/user/update", async (req, res) => {
  try {
    const { openid, userInfo, name, userIDImg, time, userID } = req.body
    const result = await User.findOneAndUpdate({ userID: openid }, {
      userInfo, name, userIDImg, time, userID
    })
    console.log(result);
    res.send("success")
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})
app.get("/user/find", async (req, res) => {
  try {
    const { openid } = req.query
    const result = await User.find({ openid })
    res.send(result)
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})
/* 

订单接口

*/
/* 商品浏览页 */
// 发布订单
app.post("/addOrder", async (req, res) => {
  try {
    console.log(req.body);
    await Order.create(req.body)
    res.send("success")
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})
app.post("/updateOrder", async (req, res) => {
  try {
    const {
      id,
      info,
      money,
      address,
      deliveryid,
      auctionInfo
    } = req.body
    console.log(req.body);
    const result = await Order.findByIdAndUpdate(id, req.body)
    res.send("success")
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})


// 
app.post("/updateAuctionOrder", async (req, res) => {
  try {
    const {
      id,
      info,
      money,
      address,
      deliveryid,
      auctionInfo,
    } = req.body
    let state = 0
    const result = await Order.findByIdAndUpdate(id, {
      money: money,
      'info.title': info.title,
      'info.detailInfo.describe': info.detailInfo.describe,
      'info.detailInfo.pic': info.detailInfo.pic,
      'info.collegeid': info.collegeid,
      'info.thingsid': info.thingsid,
      address: address,
      deliveryid: deliveryid,
      'info.notes': info.notes,
      auctionInfo: auctionInfo,
      state: 0
    })
    console.log(result);
    res.send("success")
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})

// // 获取全部订单
// app.get("/getAllOrder", async (req, res) => {
//   const result = await Order.find({
//     state: 0
//   })
//   res.send(result)
// })
// 获取闲置商品订单
// ####
app.get("/getSellerAllOrder", async (req, res) => {
  const result = await Order.aggregate(
    [{
      $match: {
        state: 0
      }
    }]
  )
  res.send(result)
})
// 条件查询获取分类、新旧程度
app.get("/getSellerAllOrder/collectionAndOld", async (req, res) => {
  if (req.query.collectionId == -1 && req.query.collectionsId == -1) {
    let result = await Order.find({ state: 0 })
    res.send(result)
    return
  }
  if (req.query.collectionId == -1) {
    let result = await Order.find({ "info.thingsid": req.query.collectionsId, state: 0 })
    res.send(result)
    return
  }
  if (req.query.collectionsId == -1) {
    let result = await Order.find({ "info.collegeid": req.query.collectionId, state: 0 })
    res.send(result)
    return

  }
  const result = await Order.find({ "info.collegeid": req.query.collectionId, "info.thingsid": req.query.collectionsId, state: 0 })
  res.send(result)

})
app.get("/getSellerAllOrder/search", async (req, res) => {

  var keyword = req.query.keyword // 获取查询的字段

  var _filter = {
    $or: [  // 多字段同时匹配
      { "info.title": { $regex: keyword } },

    ],
    state: 0
  }
  const result = await Order.find(_filter)
  res.send(result)
})

/* 

  每件商品的详情页查询

*/
app.get("/getDetailGood/IdSelect", async (req, res) => {
  const { id } = req.query
  console.log(id);
  const result = await Order.findById(id)
  res.send(result)
})
// 
/* 

买家买入商品

*/
app.get("/checkGood", async (req, res) => {
  try {
    const { id } = req.query
    const result = await Order.findById(id, {
      "state": 1
    })
    res.send(result)
  } catch (error) {
    res.send("fail", error)
  }
})
app.post("/buyGood", async (req, res) => {
  try {
    const {
      id,
      receiveOpenId,
      address,
      phone,
      receiveInfo,
      buyTime } = req.body
    const result = await Order.findByIdAndUpdate(id, {
      receiveOpenId: receiveOpenId,
      state: 1,
      receiveAddress: address,
      receivePhone: phone,
      receiveInfo: receiveInfo,
      buyTime: buyTime,
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})


/* 

获取我的订单
买家接口
*/
// 全部订单
app.get("/getMyBuyOrder/All", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        receiveOpenId: id,
        buyExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取交易中订单
app.get("/getMyBuyOrder/process", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        receiveOpenId: id,
        state: 1,
        buyExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取取消订单
app.get("/getMyBuyOrder/cancel", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        receiveOpenId: id,
        state: { $in: [3, 4] },
        buyExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取完成订单
app.get("/getMyBuyOrder/finish", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        receiveOpenId: id,
        state: 2,
        buyExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})

// 买家更新组
// 删除订单
app.get("/setMyBuyOrder/dropOrder", async (req, res) => {
  try {
    const {
      id, time } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      buyExist: 0,
      time: time,

    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})
// 评分
app.get("/setMyBuyOrder/rate", async (req, res) => {
  try {
    const {
      id, rate } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      rate
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})
// 更改地址
app.get("/setMyBuyOrder/address", async (req, res) => {
  try {
    const {
      id, address, phone, openid } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      receiveAddress: address,
      receivePhone: phone,
      receiveOpenId: openid
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})
// 立即付款
app.get("/setMyBuyOrder/confirmPrice", async (req, res) => {
  try {
    const {
      id, } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      buyTime: new Date().getTime(),
      state: 1
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})
// 取消订单
app.get("/setMyBuyOrder/cancel", async (req, res) => {
  try {
    const {
      id } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      state: 3,
      buyExist: 1
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})
// 确认订单
app.get("/setMyBuyOrder/finish", async (req, res) => {
  try {
    const {
      id } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      state: 2,
      buyExist: 1
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})




/* 
  卖家接口\我的商品
*/

// 全部订单
app.get("/getMyPublishOrder/All", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        publishID: id,
        sellerExist: 1
      },
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取上架中订单
app.get("/getMyPublishOrder/process", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        publishID: id,
        state: 0,
        sellerExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取待发货
app.get("/getMyPublishOrder/push", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        publishID: id,
        state: 1,
        sellerExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取取消订单
app.get("/getMyPublishOrder/cancel", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        publishID: id,
        state: { $in: [3, 4] },
        sellerExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取完成订单
app.get("/getMyPublishOrder/finish", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        publishID: id,
        state: 2,
        sellerExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})


// 卖家更新组
// 取消订单
app.get("/setMyBuyOrder/cancel", async (req, res) => {
  try {
    const {
      id } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      state: 3,
      sellerExist: 1
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})
// 删除订单
app.get("/setMypublishOrder/dropOrder", async (req, res) => {
  try {
    const {
      id, time } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      sellerExist: 0,
      time: time,

    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})


// 下架订单
app.get("/setMypublishOrder/out", async (req, res) => {
  try {
    const {
      id, time } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      state: 5,
      time: time
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})

app.get("/setMypublishOrder/renew", async (req, res) => {
  try {
    const {
      id, time } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      state: 0,
      time: time
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})


app.get("/setMypublishOrder/cancel", async (req, res) => {
  try {
    const {
      id } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      state: 4,
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})
// 对取消商品重新上架
app.get("/setMypublishOrder/refresh", async (req, res) => {
  try {
    const {
      id } = req.query
    let res = await Order.findByIdAndUpdate(id, {
      sellerExist: 1
    })
    let result = {
      ...res
    }
    result = result._doc
    delete result._id
    result.state = 0
    console.log(result._id);
    // result._id = new ObjectId()
    // console.log(result._id);
    result.receiveInfo = {}
    result.receiveOpenId = ''
    result.receivePhone = ''
    // let {_id, ...rest} = result
    console.log("771");
    console.log(result);
    let res1 = await Order.create(result)
    res.send("success")
  } catch (error) {
    res.send("fail", 401)
  }
})
app.get("/setMypublishOrder/outCancel", async (req, res) => {
  try {
    const {
      id } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      state: 6,
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})
// 改价操作
app.get("/setMypublishOrder/changePrice", async (req, res) => {
  try {
    const {
      id, money } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      money
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})
/* 

通知列表

*/
// 获取上架商品数量
app.get("/notice/process", async (req, res) => {
  const { id } = req.query
  const result = await Order.countDocuments(
    {
      publishID: id,
      state: 0
    }
  )
  res.send({
    count: result
  })
})
app.get("/notice/push", async (req, res) => {
  const { id } = req.query
  const result = await Order.countDocuments(
    {
      publishID: id,
      state: 1
    }
  )
  res.send({
    count: result
  })
})
app.get("/notice/buyProcess", async (req, res) => {
  const { id } = req.query
  const result = await Order.countDocuments(
    {
      receiveOpenId: id,
      state: 1
    }
  )
  res.send({
    count: result
  })
})


/* 

评论功能实现

*/
app.post("/comments/add", async (req, res) => {
  const { _id, openid, name, content, time, photo } = req.body
  let item = {
    openid,
    name,
    content,
    time,
    photo
  }
  const result = await Order.findByIdAndUpdate(_id,
    {
      $addToSet: { comments: item }
    })

  res.send(result)
})


/* 拍卖功能*/
app.post("/auction/add", async (req, res) => {
  const { _id, openid, name, price, time, photo } = req.body
  let item = {
    openid,
    name,
    price,
    time,
    photo
  }
  const result = await Order.findByIdAndUpdate(_id,
    {
      $addToSet: { 'auctionInfo.priceList': item }
    })
  await Order.findByIdAndUpdate(_id,
    {
      'auctionInfo.startPrice': price
    })
  res.send(result)
})
// 根据openid获取参与的拍卖订单
app.get("/auction/getOrder", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        goodsType: "竞价拍卖",
        state: { $in: [0, 7, 2] }
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  let priceList = []
  let goodsList = []
  let flag = false

  result.forEach(async (item) => {
    priceList = item.auctionInfo.priceList
    priceList.forEach((j) => {
      if (j.openid == id) {
        flag = true
      }
    })
    if (flag) {
      goodsList.push(item)
    }
  })
  res.send(goodsList)
})
async function checkAuctionGoods() {
  let nowtime = new Date().getTime()
  console.log(nowtime);
  const result = await Order.find({
    goodsType: "竞价拍卖",
    state: 0,
  })
  let ids = []

  result.forEach(async (item) => {
    console.log(item.auctionInfo.endTimeTamp - nowtime);
    if (item.auctionInfo.endTimeTamp - nowtime <= 0) {
      let length = item.auctionInfo.priceList.length
      if (length == 0) {
        await Order.findByIdAndUpdate(item._id, {
          state: 8
        })
      }
      else {
        await Order.findByIdAndUpdate(item._id, {
          state: 7,
          receiveOpenId: item.auctionInfo.priceList[length - 1].openid
        })
      }
    }
  })
}
setInterval(checkAuctionGoods, 6000)
/* 

收藏功能

*/


app.post("/collection/create", async (req, res) => {
  try {
    const { userID } = req.body
    const result = await Collection.find({ "userID": userID })
    if (result.length == 0) {
      await Collection.create(req.body)
    }
    res.send("success")
  } catch (error) {
    res.send("fail")
  }
})
app.post("/collection/delete", async (req, res) => {
  try {
    const { userID } = req.body
    const result = await Collection.find({ "userID": userID })
    if (result.length > 0) {
      const rs = await Collection.deleteOne({ "userID": userID })
      console.log(rs);
    }
    res.send("success")
  } catch (error) {
    res.send("fail")
  }
})
app.get("/collection/check", async (req, res) => {
  try {
    const { GoodsID, userID } = req.query
    const result = await Collection.find({ goods: { $elemMatch: { _id: GoodsID } } }, { userID: userID })
    if (result.length == 0) {
      res.send("no")
    }
    else {
      res.send("yes")

    }

  } catch (error) {
    console.log(error);
  }
})
app.post("/collection/join", async (req, res) => {
  try {
    const { GoodsInfo, userID } = req.body
    const { _id } = GoodsInfo
    let result = await Collection.find({
      userID: userID,
      goods: { $elemMatch: { _id: _id } }
    })
    if (result.length == 0) {
      result = await Collection.findOneAndUpdate({ userID: userID }, {
        $addToSet: { goods: GoodsInfo }
      })
    }
    // db.test.find({arr:{$elemMatch:{$eq:"456"}}})

    res.send("success")
  } catch (error) {
    console.log(error);
  }
})

app.post("/collection/drop", async (req, res) => {
  try {
    const { GoodsInfo, userID } = req.body
    const { _id } = GoodsInfo
    const result = await Collection.findOneAndUpdate({ userID: userID }, {
      $pull: { goods: { _id: _id } }
    })
    // console.log(result);
    res.send("success")
  } catch (error) {
    console.log(error);
  }
})
// 根据id查找用户信息
app.post("/collection/getAll", async (req, res) => {
  try {
    const { userID } = req.body
    const result = await Collection.find({ userID: userID }, { goods: 1 })
    res.send(result)
  } catch (error) {
    console.log(error);
  }
})




/* 

个性化推荐

*/

// 检测用户是否第一次登入


app.get("/recommend/check", async (req, res) => {
  try {
    const { userID } = req.query
    const result = await Collection.find({ userID: userID }, { isLike: 1 })
    res.send(result)

  } catch (error) {
    console.log(error);
  }
})

// 编辑完成
app.post("/recommend/edit", async (req, res) => {
  try {
    const { userID, isLike, likes } = req.body
    const result = await Collection.findOneAndUpdate({ userID: userID }
      , { likes: likes, isLike: isLike }
    )
    res.send(result)

  } catch (error) {
    console.log(error);
  }
})
// 获取猜你喜欢列表
app.get("/recommend/getAll", async (req, res) => {
  try {
    const { userID } = req.query
    const result = await Collection.find({ userID: userID }
    )
    res.send(result)

  } catch (error) {
    console.log(error);
  }
})



/* 


首页推荐

*/
app.get("/recommend/liksSelect", async (req, res) => {
  try {
    const { userID } = req.query
    const result = await Collection.find({ userID: userID }
    )
    let likeArray = result[0].likes
    let collectionArray = []
    likeArray.forEach((item) => {
      if (item.isSelected == true) {
        collectionArray.push(item.id + "")
      }
    })
    var _filter = {
      $or: [  // 多字段同时匹配
        { "info.collegeid": collectionArray },

      ],
      name: "商品闲置",
      state: 0
    }
    let response = await Order.find(_filter)
    res.send(response)

  } catch (error) {
    console.log(error);
  }
})




/* 

私聊功能

*/
app.get("/room/check", async (req, res) => {
  try {
    const { buyId, sallerId } = req.query
    const result = await Rooms.find({
      buyId, sallerId
    })
    console.log(result);
    res.send(result)
  } catch (error) {
    console.log(error);
  }
})


app.get("/room/updateDeleted", async (req, res) => {
  try {
    const { _id } = req.query
    const result = await Rooms.findByIdAndUpdate(_id, {
      deleted: 1
    })
    // console.log(result);
    res.send(result)
  } catch (error) {
    console.log(error);
  }
})
app.post("/room/add", async (req, res) => {
  try {
    const result = await Rooms.create(req.body)
    // console.log(result);
    res.send(result)
  } catch (error) {
    console.log(error);
  }
})
app.get("/room/setUser", async (req, res) => {
  try {
    const { openId } = req.query
    var _filter = {
      $or: [  // 多字段同时匹配
        { "buyId": openId },
        { "sallerId": openId }
      ],
    }
    let result = await Rooms.find(_filter)
    let chatList = []
    async function fn() {
      for (let item of result) {
        if (item.sallerId != openId) {
          let sallerId = item.sallerId
          let userInfo = await User.find({ openid: sallerId })
          // console.log("dsfaf");

          userInfo = userInfo[0]
          chatList.push(userInfo)
          // console.log("dafdafadf");
          // console.log(chatList);
        }
        else {
          let buyId = item.buyId
          let userInfo = await User.find({ openid: buyId })
          userInfo = userInfo[0]

          chatList.push(userInfo)
        }
      }
      console.log(chatList);
      res.send(chatList)

    }
    fn()
    // setTimeout(() => {
    //   res.send(chatList)
    // }, 1000)

    // console.log(chatList);
  } catch (error) {
    console.log(error);
  }
})




app.get("/room/checkByid", async (req, res) => {
  try {
    const { openId } = req.query
    var _filter = {
      $or: [  // 多字段同时匹配
        { "buyId": openId },
        { "sallerId": openId }
      ],
    }
    let result = await Rooms.find(_filter)
    // setTimeout(() => {
    //   res.send(chatList)
    // }, 1000)

    // console.log(chatList);
    res.send(result)
  } catch (error) {
    console.log(error);
  }
})
/* 

聊天队列

*/


app.post("/chatRoom/get", async (req, res) => {
  try {
    const { groupId } = req.body
    const result = await ChatRoom.aggregate(
      [{
        $match: {
          groupId: groupId
        }
      },
      {
        $sort:
        {
          "sendTimeTS": -1
        }
      }]
    )
    res.send(result)
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})

app.post("/chatRoom/add", async (req, res) => {
  try {
    const { doc } = req.body
    console.log(doc);
    const result = await ChatRoom.create(doc)
    // console.log(result);
    res.send("success")
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})


app.get("/chatRoom/getOne", async (req, res) => {
  try {
    const { groupId } = req.query
    console.log(groupId);
    const result = await ChatRoom.aggregate(
      [{
        $match: {
          groupId: groupId
        }
      },
      {
        $sort:
        {
          "sendTimeTS": -1
        }
      },
      {
        $limit: 1
      },
      ]
    )
    res.send(result)
  } catch (error) {
    console.log(error);
    res.send("fail")
  }
})


// 接单接口/* 我的发布 */
/* 
  客户接口\我的发布 
*/

// 全部订单
app.get("/getMySendTaskOrder/All", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "发布任务",
        publishID: id,
        sellerExist: 1
      },
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取上架中订单
app.get("/getMySendTaskOrder/process", async (req, res) => {
  const { id } = req.query
  console.log(id);
  const result = await Order.aggregate(
    [{
      $match: {
        name: "发布任务",
        publishID: id,
        state: 0,
        sellerExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取待发货
app.get("/getMySendTaskOrder/push", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "发布任务",
        publishID: id,
        state: 1,
        sellerExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取取消订单
app.get("/getMySendTaskOrder/price", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "发布任务",
        publishID: id,
        state: 2,
        sellerExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取完成订单
app.get("/getMySendTaskOrder/finish", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "发布任务",
        publishID: id,
        state: 3,
        sellerExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 立即付款
app.get("/setMySendTaskOrder/confirmPrice", async (req, res) => {
  try {
    const {
      id, } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      buyTime: new Date().getTime(),
      state: 3
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})





/* 

获取我的订单
接单接口
*/
// 全部订单
app.get("/getMyTaskOrder/All", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "发布任务",
        receiveOpenId: id,
        buyExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取交易中订单
app.get("/getMyTaskOrder/process", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "发布任务",
        receiveOpenId: id,
        state: 1,
        buyExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取结款订单
app.get("/getMyTaskOrder/cancel", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "发布任务",
        receiveOpenId: id,
        state: 2,
        buyExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})
// 获取完成订单
app.get("/getMyTaskOrder/finish", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        name: "发布任务",
        receiveOpenId: id,
        state: 3,
        buyExist: 1
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})


// 取消订单
app.get("/setMyTaskOrder/cancel", async (req, res) => {
  try {
    const {
      id } = req.query
    const result = await Order.findByIdAndUpdate(id, {
      state: 0,
      buyExist: 1
    })
    res.send("success")
  } catch (error) {
    res.send("fail", error)
  }
})

app.get("/deliver/getOrder", async (req, res) => {
  const { id } = req.query
  const result = await Order.aggregate(
    [{
      $match: {
        goodsType: "快递代拿",
        state: { $in: [1, 2, 3] },
        receiveOpenId: id
      }
    },
    {
      $sort:
      {
        "time": -1
      }
    }]
  )
  res.send(result)
})









app.listen(3000, () => {
  console.log("服务运行在 3000端口");
})