const express = require("express");
const { Admin, Order, User, Collection } = require("./db");
const jwt = require('jsonwebtoken')
const config = require("./config.js")
router = express.Router();
const request = require("request")
const multer = require("multer");
const { append } = require("express/lib/response");
/* 

权限用户登录注册接口

*/
function formatTime(time) {
  let date = new Date(time); // 初始化日期
  let year = date.getFullYear(); //获取年份
  let month = date.getMonth() + 1; // 获取月份
  let day = date.getDate(); // 获取具体日
  return year + '-' + month + '-' + day
}

router.post('/register', async (req, res) => {


  const { username, password } = req.body
  const result = await Admin.find({ userName: username })
  let root = false
  if (result.length > 0) {
    return res.send('用户名已被占用')
  }
  if (username == 'taoan' && password == '123456') {
    root = true
  }
  await Admin.create({
    userName: username,
    password: password,
    root: root,
    time: new Date()
  })
  return res.send("用户注册成功")

})
router.post('/login', async (req, res) => {
  const { username, password } = req.body
  const result = await Admin.find({ userName: username })
  if (result.length != 1) {
    return res.send('暂未注册，请先注册')
  }
  const comPassWord = result[0].password
  if (password != comPassWord) {
    return res.send('密码错误')
  }
  if (result[0].root == true) {
    var menu = [
      {
        path: '/home',
        name: 'home',
        label: '首页',
        icon: 's-home',
        url: 'home/index'
      },
      {
        path: '/mall',
        name: 'mall',
        label: '商品管理',
        icon: 'video-play',
        url: 'mall/index'
      },
      {
        path: '/user',
        name: 'user',
        label: '用户管理',
        icon: 'user',
        url: 'user/index'
      },
      {
        path: '/admin',
        name: 'admin',
        label: '管理员管理',
        icon: 's-tools',
        url: 'admin/index'
      },
      {
        label: '其他',
        icon: 'location',
        children: [
          {
            path: '/page1',
            name: 'page1',
            label: '页面1',
            icon: 'setting',
            url: 'other/PageOne.vue'
          },
          {
            path: '/page2',
            name: 'page2',
            label: '页面2',
            icon: 'setting',
            url: 'other/PageTwo.vue'
          }
        ]
      }]
  }
  else {
    var menu = [
      {
        path: '/home',
        name: 'home',
        label: '首页',
        icon: 's-home',
        url: 'home/index'
      },
      {
        path: '/mall',
        name: 'mall',
        label: '商品管理',
        icon: 'video-play',
        url: 'mall/index'
      },
      {
        path: '/user',
        name: 'user',
        label: '用户管理',
        icon: 'user',
        url: 'user/index'
      }
    ]
  }
  const user = { ...result[0], password: '', user_pic: '' }
  // 生成token字符串
  const tokenStr = jwt.sign(user, 'I am winner', { expiresIn: '10h' })
  console.log(result[0]);
  return res.send({
    status: 0,
    message: '登录成功',
    token: "Bearer " + tokenStr,
    data: {
      menu: menu,
      admin: result[0]
    }
  })
})


/* 
  上传文件、图片
*/

// 配置传送文件
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // 配置存储路径
    cb(null, './file/image')
  },
  filename: (req, file, cb) => {
    // 匹配jpg的正则
    let type = file.originalname.replace(/.+\./, '.')
    if (!!req.body.name) {
      cb(null, req.body.name + type)
    }
    cb(null, Date.now() + type)
  }
})
const upload = multer({ storage: storage })


// 上传文件的接口
// 最多上传10个文件
router.post("/uploadImg", upload.array("file", 10), (req, res) => {
  res.send(req.files)
})


/* 

首页接口

*/
router.get("/getFinishOrder", async (req, res) => {
  const result = await Order.aggregate(
    [{
      $match: {
        name: "商品闲置",
        state: 2,
      }
    },
    {
      $sort:
      {
        "buyTime": -1
      }
    }]
  )
  let response = []
  result.forEach((item, index) => {
    let Object = {
      name: item.info.title,
      time: item.buyTime,
      thing: item.info.thingsid,
      price: item.money,
      rate: item.rate
    }
    response.push(Object)
  })
  res.send(response)
})

router.get("/getAdminById", async (req, res) => {

  const { userName } = req.query
  console.log(req.query);
  const result = await Admin.find({ userName })
  return res.send(result)
})

router.get("/updateAdminById", async (req, res) => {

  const { userName } = req.query
  console.log(req.query);
  const result = await Admin.find({ userName })
  return res.send(result)
})
/* 

获取数组 今日上架订单 今日收藏订单 今日完成订单 本月上架订单 本月收藏订单 本月完成订单

*/
router.get("/getCardCount", async (req, res) => {
  // 数组 今日上架订单 今日新增用户 今日完成订单 本月上架订单 本月新增用户 本月完成订单
  // 日初
  let response = []
  let result = await Order.countDocuments(
    { "time": { $gte: new Date(new Date().toLocaleDateString()).getTime() }, state: 0 }
  )
  response.push(result)
  result = await User.countDocuments(
    { "createTime": { $gte: new Date(new Date().toLocaleDateString()).getTime() } },
  )
  response.push(result)
  result = await Order.countDocuments(
    { "buyTime": { $gte: new Date(new Date().toLocaleDateString()).getTime() }, state: 2 }
  )
  response.push(result)
  // 月初
  let data = new Date();
  data.setDate(1);
  data.setHours(0);
  data.setSeconds(0);
  data.setMinutes(0);
  const monthDate = data.getTime()
  result = await Order.countDocuments(
    { "time": { $gte: monthDate }, state: 0 }

  )
  response.push(result)
  result = await User.countDocuments(
    { "createTime": { $gte: monthDate } },
  )
  response.push(result)
  result = await Order.countDocuments(
    { "buyTime": { $gte: monthDate }, state: 2 }
  )
  response.push(result)
  res.send(response)
})
/* 
饼图
*/

router.get("/getPie", async (req, res) => {
  let collection = ['学习', '数码', '装饰品', '衣物', '运动器材', '化妆品', '交通工具', '其他']
  let list = []
  let length = collection.length
  async function fngetPie() {

    for (let index = 0; index < collection.length; index++) {
      let count = await Order.countDocuments({
        "name": "商品闲置", "info.collegeid": String(index)
      })
      let Object = {
        name: collection[index],
        value: count
      }
      list.push(Object)

    }
    res.send(list)
  }
  fngetPie()
})
/* 

折线图

*/

router.get("/getLine", async (req, res) => {
  let states = ['上架中', '等待发货', '交易完成', '取消中订单', '已取消订单', '下架商品', '订单纠纷']
  let xdata = []
  function getTime(index) {
    let toData = new Date(new Date().toLocaleDateString()).getTime()
    let pastdaysStart = toData - index * 3600 * 24 * 1000
    return pastdaysStart
  }
  async function fngetLine() {
    let Array = []
    let time
    for (let j = 0; j < 6; j++) {
      let data = []
      for (let index = 7; index > 0; index--) {
        time = getTime(index)

        let result = await Order.countDocuments({
          "name": "商品闲置", "state": j, "time": { $gte: time, $lte: time + 86400000 }
        })

        data.push(result)
      }

      let Object = {
        name: states[j],
        data: data,
        type: 'line'
      }
      Array.push(Object)
    }
    for (let time = 7; time > 0; time--) {
      xdata.push(formatTime(getTime(time)))

    }
    res.send({
      xdata,
      Array
    })
  }
  fngetLine()
})
/* 

柱状图

*/
router.get("/getBar", async (req, res) => {
  // let states = ['上架中', '等待发货', '交易完成', '取消中订单', '已取消订单', '下架商品', '订单纠纷']
  let xdata = []
  function getTime(index) {
    let toData = new Date(new Date().toLocaleDateString()).getTime()
    let pastdaysStart = toData - index * 3600 * 24 * 1000
    return pastdaysStart
  }
  async function fngetBar() {
    let Array = []
    let time

    for (let index = 7; index > 0; index--) {
      time = getTime(index)
      xdata.push(formatTime(time).substring(5))
      let user = await User.countDocuments({
        "time": { $gte: time, $lte: time + 86400000 }
      })
      let order = await Order.countDocuments({
        "name": "商品闲置", "state": { $in: [1, 2] }, "time": { $gte: time, $lte: time + 86400000 }
      })
      let object = {
        user: user,
        order: order,
      }
      Array.push(object)

    }
    res.send({
      xdata,
      Array
    })
  }
  fngetBar()
})
/* 

订单管理

*/
router.get("/getAllOrder", async (req, res) => {
  const { page, pageSize, name } = req.query
  const count = await Order.countDocuments()

  if (name == "") {
    const result = await Order.find().skip((page - 1) * pageSize).limit(pageSize).sort({ time: -1 })
    return res.send({
      count: count,
      list: result
    })
  }
  else {
    let _filter = {
      $or: [  // 多字段同时匹配
        { "info.title": { $regex: name } },
      ],
      name: "商品闲置",
    }
    const result = await Order.find(_filter)
    return res.send({
      count: count,
      list: result
    })
  }

})
router.get("/selectCollectionOrder", async (req, res) => {
  const { id } = req.query
  const count = await Order.countDocuments({ "name": "商品闲置", "info.collegeid": id })
  let result = await Order.find({ "name": "商品闲置", "info.collegeid": id })
  return res.send({
    count: count,
    list: result
  })
})
router.get("/selectStateOrder", async (req, res) => {
  const { id } = req.query
  const count = await Order.countDocuments({ "name": "商品闲置", "state": id })
  let result = await Order.find({ "name": "商品闲置", "state": id })
  return res.send({
    count: count,
    list: result
  })
})
router.post("/updateOrder", async (req, res) => {
  let { id, goods, collection, price, phone, state } = req.body
  let collections = ['学习', '数码', '装饰品', '衣物', '运动器材', '化妆品', '交通工具', '其他']
  let states = ['上架中', '等待发货', '交易完成', '取消中订单', '已取消订单', '下架商品', '订单纠纷']
  state = states.findIndex(value => value == state)
  collectionId = collections.findIndex(value => value == collection)
  const result = await Order.findByIdAndUpdate(id, {
    state: state,
    money: price,
    pulishPhone: phone,
    $set: {
      "info.title": goods,
      "info.detailInfo.good": goods,
      "info.collegeid": String(collectionId),
    }
  })
  res.send("success")
})
router.get("/delOrder", async (req, res) => {
  const { id } = req.query

  let result = await Order.deleteOne({ _id: id })
  res.send("success")
})
router.get("/getById", async (req, res) => {
  const { id } = req.query

  let result = await Order.findOne({ _id: id })
  res.send(result)
})


/* 

管理员权限

*/
router.get("/getAdmin", async (req, res) => {
  const { page, pageSize, name } = req.query
  const count = await Admin.countDocuments()
  if (name == "") {
    const result = await Admin.find().skip((page - 1) * pageSize).limit(pageSize).sort({ time: -1 })
    return res.send({
      count: count,
      list: result
    })
  }
  else {
    let _filter = {
      $or: [  // 多字段同时匹配
        { "nickName": { $regex: name } },
        { "userName": { $regex: name } },
      ],
    }
    const result = await Admin.find(_filter)
    return res.send({
      count: count,
      list: result
    })
  }

})
router.post("/updateAdmin", async (req, res) => {
  console.log(req);
  let { _id } = req.body
  let data = req.body
  data.time = new Date()
  if (data.root == 'false' || data.root == 'true') {
    data.root = Boolean(data.root)
  }
  else {
    data.root = (data.root === "超级管理员" ? true : false)
  }
  delete data._id
  const result = await Admin.findByIdAndUpdate(_id, data)
  res.send(data)
})
router.get("/delAdmin", async (req, res) => {
  const { id } = req.query

  let result = await Admin.deleteOne({ _id: id })
  res.send("success")
})
router.post("/addAdmin", async (req, res) => {
  let data = req.body
  data.time = new Date()
  data.root = (data.root === "超级管理员" ? true : false)
  delete data._id
  const find = await Admin.find({ userName: data.userName })
  if (find.length > 0) {
    return res.send('用户名已被占用')
  }
  else {
    let result = await Admin.insertMany(data)
    res.send("success")
  }
})

/* 

用户管理

*/
router.get("/getUser", async (req, res) => {
  const { page, pageSize, name } = req.query
  const count = await User.countDocuments()
  if (name == "") {
    const result = await User.find().skip((page - 1) * pageSize).limit(pageSize).sort({ time: -1 })
    return res.send({
      count: count,
      list: result
    })
  }
  else {
    let _filter = {
      $or: [  // 多字段同时匹配
        { "name": { $regex: name } },
        { "openid": { $regex: name } },
      ],
    }
    const result = await User.find(_filter)
    return res.send({
      count: count,
      list: result
    })
  }

})
router.post("/updateUser", async (req, res) => {
  let { _id, name, root, avator, time } = req.body
  time = new Date()
  const result = await User.findByIdAndUpdate(_id, {
    name,
    root,
    userIDImg: avator,
    time,
    $set: {
      "userInfo.nickName": name,
      "userInfo.avatarUrl": avator,
    }
  })
  res.send('success')
})
router.get("/delUser", async (req, res) => {
  const { id } = req.query

  let result = await User.deleteOne({ _id: id })
  res.send("success")
})
router.get("/selectUser", async (req, res) => {
  const { id } = req.query
  const count = await User.countDocuments({ "root": id })
  let result = await User.find({ "root": id })
  return res.send({
    count: count,
    list: result
  })
})


/* 

管理员3d展示

*/
router.get("/getModel", async (req, res) => {
  const result = await Order.find({ modelUrl: { $ne: "" } }).distinct("modelUrl")
  let list = []
  async function fngetModel() {

    for (let index = 0; index < result.length; index++) {
      let str = result[index]
      let data = await Order.findOne({
        "name": "商品闲置", modelUrl: str
      })
      let object  = {
        imgsrc:data.info.detailInfo.pic[0],
        desc:{
          title:data.info.title,
          content:data.info.detailInfo.describe
        },
        modelUrl:data.modelUrl
      }
      list.push(object)
    }
    res.send(list)

  }
  fngetModel()
})

module.exports = router