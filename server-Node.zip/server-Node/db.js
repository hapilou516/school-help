const { listen } = require("express/lib/application");
const mongooose = require("mongoose")
mongooose.connect("mongodb://localhost:27017/helpSchool").then(() => {
  console.log("数据库连接成功");
}).catch((err) => {
  console.log("数据库连接失败" + err);
})


/* 

用户表

*/

const userSchema = new mongooose.Schema({
  openid: {
    type: String
  },
  name: {
    type: String
  },
  userID: {
    type: String
  },
  userIDImg: {
    type: String
  },
  userInfo: {
    type: Object
  },
  root: {
    type: String,
    default: "普通用户"
  },
  time: {
    type: Number
  },
  createTime: {
    type: Number,
    default: new Date().getTime()
  },
  isLogin: {
    type: Boolean,
    default: true
  }
})


/* 

订单表

*/

const orderSchema = new mongooose.Schema({
  name: String,
  time: Number,
  money: Number,
  state: Number,
  address: String,
  info: Object,
  userInfo: Object,
  pulishPhone: Number,
  publishID: String,
  receiveAddress: {
    type: String,
    default: ""
  },
  receiveOpenId: {
    type: String,
    default: ""
  },
  receiveInfo: Object,
  receivePhone: {
    type: String,
    default: ""
  },
  buyTime: Number,
  buyExist: {
    type: Number,
    default: 1
  },
  sellerExist: {
    type: Number,
    default: 1
  },
  rate: {
    type: Number,
    default: 0
  },
  comments: Array,
  modelUrl: {
    type: String,
    default: ''
  },
  goodsType:{
    type:String,
    default:''
  },
  auctionInfo: {
    type: Object,
    default: {}
  },
  deliveryid:{
    type:Number,
    default:0
  },
})


/* 

收藏表

*/

const collectionSchema = new mongooose.Schema({
  name: String,
  time: Number,
  userID: String,
  isLike: {
    type: Number,
    default: 0
  },
  goods: Array,
  likes: Array,
})



/* 

房间表

*/
const roomsSchema = new mongooose.Schema({
  deleted: Number,
  buyId: String,
  sallerId: String
})


/* 

聊天表

*/
const chatRoomSchema = new mongooose.Schema({
  openId: String,
  nickName: String,
  groupId: String,
  avatar: String,
  msgType: String,
  sendTime: Date,
  sendTimeTS: String,
  imgFileID: String,
  textContent: {
    default: "",
    type: String
  }
})

/* 

后台管理接口
Admin表

*/

const adminSchema = new mongooose.Schema({
  userName: String,
  nickName: {
    default: "新用户",
    type: String
  },
  password: String,
  avator: {
    default: "http://127.0.0.1:3000/file/image/1666787925983.jpg",
    type: String
  },
  root: {
    default: false,
    type: Boolean
  },
  time: {
    type: Number
  },
})





// 订单表
// 声明表格式
// 创建用户表
const User = mongooose.model("user", userSchema)
const Order = mongooose.model("Order", orderSchema)
// 创建收藏表
const Collection = mongooose.model("collection", collectionSchema)
// 创建房间表
const Rooms = mongooose.model("rooms", roomsSchema)
// 创建聊天表
const ChatRoom = mongooose.model("chatRoom", chatRoomSchema)
// 创建管理员权限表
const Admin = mongooose.model("admin", adminSchema)
// Admin.create({
//   userName:'taoan',
//   nickName: "桃良长安",
//   password: "123456",
//   avator:"1111111",
// })
// 导出
module.exports = {
  Order,
  Collection,
  Rooms,
  User,
  ChatRoom,
  Admin
}