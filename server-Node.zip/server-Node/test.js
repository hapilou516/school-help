let str = 'wx:123569333333';
function hide_tel(str) {
  const regex1 = /\d/
  const regex2 = /\d|[\u4e00-\u9fa5]|\w/
  const regex_tel = /13[0-9]|14[5|7]|15[0-9]|18[0-9]/
  const regex_sj = /[(?)wx]|[(?)weixin]|[(?)qq]|[\u5fae\u4fe1]/
  let str_all = [];
  let str_addr = [];
  let str_num = "";
  for (let i = 0; i < str.length; i++) {
    str_all.push(str.charAt(i))
    if (str.charAt(i).match(regex1)) {
      str_addr.push(i)
      str_num += str.charAt(i)
    }
  }
  // 判别电话号码
  if (str_num.match(regex_tel)) {
    if (str_addr.length > 7) {
      for (let i = 0; i < Math.ceil(str_addr.length / 2); i++) {
        let num = str_addr[Math.ceil(str_addr.length / 4) + i]
        str_all[num] = "*";
      }
    }
  } else {//判别社交帐号
    str_addr = [];
    str_num = "";
    for (let n = 0; n < str.length; n++) {
      if (str.charAt(n).match(regex2)) {
        str_addr.push(n)
        str_num += str.charAt(n)
      }
    }
    console.log(str_num);
    if (str_num.match(regex_sj)) {
      for (let i = 0; i < str_all.length; i++) {
        if (str_all[i].match(regex1)) {
          str_all[i] = "*"
        }
      }
      str = str_all.join('');
    } else {
      console.log("no get");
    }
  }
  str = str_all.join('')
  return str
}

console.log('str:' + hide_tel(str));