# 校园帮项目架构
## 一、技术栈
### 1、UI设计
- ui设计采用墨刀设计，总计30多个页面、阿里图标库图标下载。
- 首页、发布页、闲置服务页、竞价拍卖页、详情页、商品确认购买页、3d模型展示页、搜索页、商品发布页
- 消息页、聊天页、通知页、一对一聊天页
- 我的页面、我的发布页、我的购买页、我的收藏、猜你喜欢、我的钱包、关于我们、联系客服、个人信息页、地址页、添加地址页
### 2、前端
- 前台使用微信原生开发语言、使用vantUI、wu-app等组件进行设计、引入threeJS编辑3d模型展示页
- 调用小程序getUserInfo接口获取用户数据,request获取后端数据、StorageSync接口，将经常访问的数据保存在缓存中
- 交互设计使用showToast提示用户,封装常用的时间格式化、屏蔽手机号函数，封装了常用聊天页面等组件
- 后台权限主要使用Vue2框架、elementUI组件库、vite构建工具、vuex进行页面间数据读取
- 后台细节方面:二次封装echarts进行可视化、封装threeJs进行模型的加载、切换、视角切换、背景hdr图的切换、lingo3d引擎进行第三人称展示
- 封装了常用的表单、表格等常用组件
### 3、后端
- 使用springboot开发
- 依赖:alibaba.fastjson2进行json数据转换、commons-fileupload进行文件上传、httpcomponents进行数据接受、lombok工具进行注解
- 文件结构:controller接口层,dao数据库操作层、model数据库映射类、serve封装了常用服务、工具类
- control层:管理、基础、聊天、集合、订单、房间、用户接口
- dao层相比control层多加了通用泛型类进行数据库的查找、返回count数据
- serve层：跨域处理、文件传输、http请求、返回jwttoken、文件配置
### 4、数据库
- mongodb设计
- 表分布:订单表、用户表、聊天表、房间表、管理员表
#### 订单表:
- id:id(订单ID)(每张表自动生成的)
- name:String(服务类型)
- money:number
- time:String(订单生成时间)
- state:number//0在售；1买家已付款，但卖家未发货；2买家确认收获，交易完成；3、买家取消订单，商家未确认取消；4、买家取消订单，商家确认取消;5、商家下架商品;6、订单异常,7、买家待付款;8、无人竞拍,流拍重新上架
- buyExist:0
- sellerExist:0
- info:object(订单详情信息)
- userinfo:object(用户信息)
- phone:number(订单发布者电话)
- commit:list(评价:类似于发布价格过高、完成评价)
- receiverPerson:openid(接单者id)
- receiveAddress:String(接单者地址)
- receivePhone:number(接单者电话)
- modelUrl:String(模型地址)
- goodsType:Strig(商品类别)
- pulishID:openid(发布者的id)
- rate:number(评分:最高为5)
- auctionInfo:Object(拍卖信息,选填)
#### 用户表:
- name
- time:Long(更新时间)
- userID
- userIDImg
- userInfo:obejct(用户信息)
- root:String(用户权限)
- createtime:Long(创建时间)
#### 权限表
- userName
- time
- nickName
- password
- avator
- root:boolean(false)
#### 房间表
- deleted(删除标记)
- buyId(买家openid)
- sallerId(卖家openid)
#### 聊天表
- openId
- nickName
- groupId:房间id
- avatar:头像
- msgtype:(聊天类别:text、image)
- sendTime:(发送时间)
- sendTimeTs
- textContet:(文本信息)
- imgUrl:(图片信息)
### 运维
- 购买了阿里服务器
- 使用了nginx采用反向代理将http接口升级了https，PM2部署接口，
- 小程序上线体验版。
## 二、实现思路
### 小程序端
- 首页flex布局，布局上搜索栏、轮播图、给四个主要功能图标加入跳转、猜你喜欢，使用卡片瀑布流布局
- 首页初次加载页面向后台请求数据,主要都是返回openid,进行订单的查找
- 发布商品使用wub-app设计
- 商品发布页，input表单设计，发布进行校验，添加订单
- 商品浏览页,筛选信息,分类使用dropdown-menu菜单,事件监听,查找数据库设计
- 聊天功能,加入定时器,实时更新接受信息
- threeJs进行商品3d模型渲染
### 后端
- 主要是对表进行基础的增删改查
- 对于特殊需求，进行mongodb的聚合操作：sort、limit、addToset、match操作
- 对于表结构里的object,也要重写实体类
- 对于跨域处理、文件传输、http请求、返回jwttoken、文件配置进行处理
### 数据库
- 在接口访问完成以后，使用mongodbcompass可视化工具进行预览数据的变化
## 三、遇到的困难
- 前端上线服务时，遇到跨域问题
- 小程序的接口必须为https,需要使用nginx进行反向代理映射接口,使得将http接口升级为https。
- 后端实体类对应嵌套数据表的时候@NoArgsConstructor注解进行深度映射
## 四、特色功能实现思路
- threeJs封装了base3DJs类,导入了渲染器、灯光组、视角轨道控制
- 向外暴露出场景、模型、摄像机切换方法、加载进度回调方法
- 使用maxios进行绑定骨骼动画、lingo3d引擎自带物体体积碰撞

  











