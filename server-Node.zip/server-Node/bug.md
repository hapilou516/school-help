# 聊天姓名头像都是我
# 我的主页昵称限制


# node转java
# 竞价
# 订单分流
# 手机号屏蔽

# 拍卖需求分忻
## 字段
- startPrice
- stepPrice
- startTime
- endTime
- guarantee（保证金）
- priceList
- [avator,price,time]



# me
- 上线体验版
- 后端页面切换跳转
- 技术文档
- 前端静态页面
# 伟
- 介绍文档
# 星
- 介绍视频
