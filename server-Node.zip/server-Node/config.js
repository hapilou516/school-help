
module.exports = function () { 
  return { 
    jwtSecretKey:'I am winner',
    hours:'10h'
  }; 
};