# 校园跑腿接口文档



## 服务端发送事件：

| 事件名           | 参数                           | 功能                                                         |
| ---------------- | ------------------------------ | ------------------------------------------------------------ |
| login| 参数1：code码<br>回调isExist | 返回5分钟的凭证                               |
| addNewReceiver            | 字符串：openid、name、userID、userIDImg、userInfo、state、time               | 用户添加接单信息    |
| uploadImg            |   文件                             | 上传文件到服务器并返回数据到页面                    |
| getOrderReceive       |              | 获取未审核的接单情况 |
| updateOrderReceive        |      _id,state,examinePerson                          | 更改审核状态，并加入审核人员openID                        |
| findAllReceive      | 字符串：openid                 | 返回当前用户的接单申请  |
| addOrder         | 对象：object                     | 添加帮助订单         |
| getAllOrder      | 无                    | 获取当前的所有订单          |
| getReceiveRoot         | openid             | 获取是否为接派员的权限          |
| getMyOrder      | openid                    | 获取我的订单         |
| getHelpTotalNum      | 字符串：帮助的人                 | 查看是否为当前用户帮助的已完成的订单|
| getHelpTotalMoney         | string:receivePerson                     | 使用聚合操作累加求出我帮助的订单金额总和          |
| toUpOrder      | 订单号，receivePerson                     | 根据订单更改订单状态          |
| toFinishOrder      | id                 | 完成订单为接派员的接单数＋1|


| getRewardOrder      | 无                     | 持将数据里所有待帮助的筛选出来         |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |
| update_line      | 对象：line                     | 持续的更新当前的线条；服务端广播 updating_line 事件          |

## 客户端接收事件：

| 事件名          | 参数                                             | 功能                                                         |
| --------------- | ------------------------------------------------ | ------------------------------------------------------------ |
| connect         |                                                  | 与服务器的连接已建立                                         |
| disconnect      |                                                  | 与服务器的连接已断开                                         |
| room_info       | 对象：{ nicknames, holder, lines }               | 获取游戏房间的当前信息                                       |
| user_enter      | 字符串：nickname                                 | 有玩家进入了房间                                             |
| user_leave      | 字符串：nickname                                 | 有玩家离开了房间                                             |
| already_started | 字符串：holder                                   | 当几个玩家同时抢主持人时，<br/>提示游戏已经开始，即房间中已经有游戏主持人了 |
| game_started    | 字符串：holder                                   | 游戏开始，即某玩家称为主持人                                 |
| game_stoped     |                                                  | 主持人终止了游戏                                             |
| game_answered   | 对象：{ alreadyDone, success, nickname, answer } | 玩家猜答案后的反馈信息                                       |
| starting_line   | 对象：line                                       | 主持人开始绘制一条新的线条                                   |
| updating_line   | 对象：line                                       | 主持人正在持续绘制当前线条                                   |

