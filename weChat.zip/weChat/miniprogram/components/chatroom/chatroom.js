var time = require('../../utils/util.js');
const {http} = getApp()
let timeFuction 
const FATAL_REBUILD_TOLERANCE = 10
const SETDATA_SCROLL_TO_BOTTOM = {
  scrollTop: 100000,
  scrollWithAnimation: true,
}

Component({
  properties: {
    envId: String,
    collection: String,
    groupId: String,
    groupName: String,
    userInfo: Object,
    onGetUserInfo: {
      type: Function,
    },
    getOpenID: {
      type: Function,
    },
  },

  data: {
    chats: [],
    textInputValue: '',
    openId: '',
    scrollTop: 110,
    scrollToMessage: '',
    hasKeyboard: false,
    inter:null
  },

  methods: {
    onGetUserInfo(e) {
      this.properties.onGetUserInfo(e)
    },

    getOpenID() {
      return wx.getStorageSync("openid")
    },

    async initRoom() {
      this.try(async () => {
        await this.initOpenID()

        const {
          envId,
          collection
        } = this.properties
        // const db = this.db = wx.cloud.database({
        //   env: envId,
        // })
        // const _ = db.command
        wx.showLoading({
            title: '加载中',
          })
          wx.request({
            url: `${http}/chatRoom/get`,
            method:"post",
            data:{
                groupId:this.data.groupId
            },
            success: (res) => {
             console.log(res);
             const {data} =res
             this.setData({
                    chats: data.reverse(),
                    scrollTop: 10000,
             })
             
             this.initWatch()
   
              wx.hideLoading();
            },
            fail: (res) => {
              wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
              })
              wx.hideLoading();
            }
          })



      }, '初始化失败')
    },
    async initOpenID() {
      return this.try(async () => {
        const openId = await this.getOpenID()

        this.setData({
          openId,
        })
      }, '初始化 openId 失败')
    },
    async getDate(){
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/chatRoom/get`,
        method:"post",
        data:{
            groupId:this.data.groupId
        },
        success: (res) => {
        console.log(res);
        const {data} =res
        this.setData({
                chats: data.reverse(),
                scrollTop: 10000,
        })
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
    },
    async initWatch(criteria) {
        console.log(criteria);
      // 每隔五秒获取消息
      this.try(() => {
        const {
          collection
        } = this.properties

        console.warn(`开始监听`, criteria)
//    ###
        wx.request({
          url: `${http}/chatRoom/get`,
          method:"post",
          data:{
              groupId:this.data.groupId
          },
          success: (res) => {
          console.log(res);
          const {data} =res
          if(data.length !=this.data.chats.length){
            this.setData({
                chats: data.reverse(),
                scrollTop:100000
          })
          }

         
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      }, '初始化监听失败')
    },
    startInter : function(){
      var that = this;
      console.log(that.data.inter);
     if(that.data.inter){
      that.clearInterval(that.data.inter)
     }
      that.data.inter= setInterval(
          function () {
              that.initWatch()
              console.log('setInterval 每过500毫秒执行一次任务')
          }, 1000);    
    },
    endInter: function(){
      var that = this;
      clearInterval(that.data.inter)
      that.setData({
        inter:null
      })
    },
    onRealtimeMessageSnapshot(snapshot) {
      console.warn(`收到消息`, snapshot)
      console.log(snapshot);
      if (snapshot.type === 'init') {
        this.setData({
          chats: [
            ...this.data.chats,
            ...[...snapshot.docs].sort((x, y) => x.sendTimeTS - y.sendTimeTS),
          ],
        })
        this.scrollToBottom()
        this.inited = true
      } else {
        let hasNewMessage = false
        let hasOthersMessage = false
        const chats = [...this.data.chats]
        for (const docChange of snapshot.docChanges) {
          switch (docChange.queueType) {
            case 'enqueue': {
              hasOthersMessage = docChange.doc._openid !== this.data.openId
              const ind = chats.findIndex(chat => chat._id === docChange.doc._id)
              if (ind > -1) {
                if (chats[ind].msgType === 'image' && chats[ind].tempFilePath) {
                  chats.splice(ind, 1, {
                    ...docChange.doc,
                    tempFilePath: chats[ind].tempFilePath,
                  })
                } else chats.splice(ind, 1, docChange.doc)
              } else {
                hasNewMessage = true
                chats.push(docChange.doc)
              }
              break
            }
          }
        }
        this.setData({
          chats: chats.sort((x, y) => x.sendTimeTS - y.sendTimeTS),
        })
        if (hasOthersMessage || hasNewMessage) {
          this.scrollToBottom()
        }
      }
    },
     hide_tel(str,res) {
      const regex1 = /\d/
      const regex2 = /\d|[\u4e00-\u9fa5]|\w/
      const regex_tel = /13[0-9]|14[5|7]|15[0-9]|18[0-9]/
      const regex_sj = /[(?)wx]|[(?)weixin]|[(?)qq]|[\u5fae\u4fe1]/
      let str_all = [];
      let str_addr = [];
      let str_num = "";
      for (let i = 0; i < str.length; i++) {
        str_all.push(str.charAt(i))
        if (str.charAt(i).match(regex1)) {
          str_addr.push(i)
          str_num += str.charAt(i)
        }
      }
      // 判别电话号码
      if (str_num.match(regex_tel)) {
        if (str_addr.length > 7) {
          for (let i = 0; i < Math.ceil(str_addr.length / 2); i++) {
            let num = str_addr[Math.ceil(str_addr.length / 4) + i]
            str_all[num] = "*";
          }
        }
      } else {//判别社交帐号
        str_addr = [];
        str_num = "";
        for (let n = 0; n < str.length; n++) {
          if (str.charAt(n).match(regex2)) {
            str_addr.push(n)
            str_num += str.charAt(n)
          }
        }
        console.log(str_num);
        if (str_num.match(regex_sj)) {
          for (let i = 0; i < str_all.length; i++) {
            if (str_all[i].match(regex1)) {
              str_all[i] = "*"
            }
          }
          str = str_all.join('');
        } else {
          console.log("no get");
        }
      }
      str = str_all.join('')
      return str
    },
    async onConfirmSendText(e) {
      this.try(async () => {
        if (!e.detail.value) {
          return
        }
        const {
          collection
        } = this.properties
        // 发送消息
        let talk = this.hide_tel(e.detail.value)    
        const doc = {
          // _id: `${Math.random()}_${Date.now()}`,
          openId:this.data.openId,
          groupId: this.data.groupId,
          avatar: this.data.userInfo.avatarUrl,
          nickName: this.data.userInfo.nickName,
          msgType: 'text',
          textContent: talk,
          sendTime: new Date(),
          sendTimeTS: time.formatTime(new Date(),'Y/M/D h:m:s'), // fallback
        }
        console.log(doc.sendTimeTS);
        this.setData({
          textInputValue: '',
          chats: [
            ...this.data.chats,
            {
              ...doc,
              _openid: this.data.openId,
              writeStatus: 'pending',
            },
          ],
        })
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${http}/chatRoom/add`,
          method:"post",
          data:{
            doc
          },
          success: (res) => {
          //   const {data} =res
          //  console.log(data);
          //  this.setData({
          //         chats: data.reverse(),
          //         scrollTop: 10000,
          //  })
          console.log(res);
          //  this.getDate()
           
            wx.hideLoading();
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
        this.scrollToBottom(true)


        this.setData({
          chats: this.data.chats.map(chat => {
            if (chat._id === doc._id) {
              return {
                ...chat,
                writeStatus: 'written',
              }
            } else return chat
          }),
        })


      }, '发送文字失败')

    },

    async onChooseImage(e) {
      const that = this
      wx.chooseImage({
        count: 1,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'],
        success: (res) => {
          console.log(res);
          const random = Math.floor(Math.random() * 1000);
          wx.uploadFile({
              url: `${http}/uploadImg`, 
              filePath:  res.tempFilePaths[0],
              name: `file`,
              formData:{
                name:`${that.data.userInfo.nickName}-${random}`
            },
              success (res){
                let  {path} = JSON.parse(res.data)[0]
                path = path.replace(/\\/g,"/")
                let imgSrc = `${http}/${path}`
                console.log(imgSrc);
                const doc = {
                  openId:that.data.openId,
                  groupId: that.data.groupId,
                  avatar: that.data.userInfo.avatarUrl,
                  nickName: that.data.userInfo.nickName,
                  msgType: 'image',
                  sendTime: new Date(),
                  sendTimeTS: time.formatTime(new Date(),'Y/M/D h:m:s'), // fallback
                  imgFileID: imgSrc,
                }
                that.setData({
                  chats: [
                    ...that.data.chats,
                    {
                      ...doc,
                      openid: that.data.openId,
                      tempFilePath:imgSrc,
                    },
                  ]
                })
                // that.scrollToBottom(true)
                
                wx.request({
                  url: `${http}/chatRoom/add`,
                  method:"post",
                  data:{
                    doc
                  },
                  success: (res) => {
                  //   const {data} =res
                  //  console.log(data);
                   that.setData({
                          scrollTop: 20000,
                   })
                  console.log(res);
                  //  this.getDate()
                   
                  },
                  fail: (res) => {
                    wx.showToast({
                      icon: 'none',
                      title: '服务器异常~~~',
                    })
                    wx.hideLoading();
                  }
                })
              }
            })
        }
      })
    },
    onMessageImageTap(e) {
      wx.previewImage({
        urls: [e.target.dataset.fileid],
      })
    },

    scrollToBottom(force) {
      if (force) {
        console.log('force scroll to bottom')
        this.setData(SETDATA_SCROLL_TO_BOTTOM)
        return
      }

      this.createSelectorQuery().select('.body').boundingClientRect(bodyRect => {
        this.createSelectorQuery().select(`.body`).scrollOffset(scroll => {
          if (scroll.scrollTop + bodyRect.height * 3 > scroll.scrollHeight) {
            console.log('should scroll to bottom')
            this.setData(SETDATA_SCROLL_TO_BOTTOM)
          }
        }).exec()
      }).exec()
    },

    async onScrollToUpper() {
    },

    async try (fn, title) {
      try {
        await fn()
      } catch (e) {
        this.showError(title, e)
      }
    },

    showError(title, content, confirmText, confirmCallback) {
      console.error(title, content)
      wx.showModal({
        title,
        content: content.toString(),
        showCancel: confirmText ? true : false,
        confirmText,
        success: res => {
          res.confirm && confirmCallback()
        },
      })
    },
  },

  ready() {
    global.chatroom = this
  
    this.initRoom()
    this.fatalRebuildCount = 0
    this.startInter()
  },
  detached(){
    this.endInter()
    
  },

})