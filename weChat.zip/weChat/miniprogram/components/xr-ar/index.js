// components/xr-start/index.ts
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        modelUrl:String
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {
        // handleAssetsProgress: function ({detail}) {
        //   console.log('assets progress', detail.value);
        // },
        // handleAssetsLoaded: function ({detail}) {
        //   console.log('assets loaded', detail.value);
        // },
        handleTouchModel: function ({detail}) {
            const {target} = detail.value;
            const id = target.id;
            
            wx.showToast({title: `点击了模型： ${id}`});
          },
        handleAssetsLoaded: function({detail}) {
            wx.showToast({title: '点击屏幕放置'});
            let that = this
            console.log(this.scene);
            this.scene.event.add('touchstart', () => {
                // wx.showToast({title: `点击了模型： ${that.data.modelUrl}`});
              this.scene.ar.placeHere('setitem', true);
            });
          },
        handleReady:function({detail}){
            var that = this;
            this.scene = detail.value
            // if(this.data.modelUrl =="https://taoan.top/file/model/robot.glb"){
            //     that.setData({
            //         modelUrl:"https://mmbizwxaminiprogram-1258344707.cos.ap-guangzhou.myqcloud.com/xr-frame/demo/miku.glb"
            //     })
            // }            // let modelUrl;
            // this.miku = {el: this.scene.getElementById('miku').getComponent("src").setData(modeUrl)};
            // this.miku.getComponent("src").setData(modeUrl)
            // src="https://taoan.top/file/model/cube.glb"
            // this.scene.assets.loadAsset({
            //     type: 'gltf', assetId: 'miku', src: "https://taoan.top/file/model/cube.glb"
            //   })
            // if(this.data.modelUrl == "https://taoan.top/file/model/robot.glb"){
            // //     that.setData({
            // //     modelUrl:"https://mmbizwxaminiprogram-1258344707.cos.ap-guangzhou.myqcloud.com/xr-frame/demo/miku.glb"
            // //    })
            // }
            
        }
      }
})
