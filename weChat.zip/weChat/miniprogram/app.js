const config = require("config.js");

App({
      openid: '',
      userinfo:'',
      roomlist:[],
      canReflect:true,
            // 云端地址
      http:"https://taoan.top",
      // 本地地址
    //   http:"http://127.0.0.1:3000",
      onLaunch: function() {
            if (!wx.cloud) {
                  console.error('请使用 2.2.3 或以上的基础库以使用云能力')
            } else {
                  wx.cloud.init({
                       env: JSON.parse(config.data).env,
                        traceUser: true,
                  })
            }
           this.systeminfo=wx.getSystemInfoSync();
        
      },
      checkUserInfo(){
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${this.http}/user/check`,
          data:{
            _id:wx.getStorageSync("openid"),
          },
          success: (res) => {
            if (!wx.getStorageSync('userInfo')) {
              wx.showToast({
                icon:"none",
                title: '还未登录，请授权登录',
              })
              setTimeout(()=>{
                wx.switchTab({
                  url: '/pages/my/my',
                 })
              },1000)
            }
            if(res.data.length == 0){

              wx.showToast({
                icon:"none",
                title: '还未登录，请授权登录',
              })
              setTimeout(()=>{
                wx.switchTab({
                  url: '/pages/my/my',
                 })
              },1000)
            }
           
            wx.hideLoading();
            return true
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
})