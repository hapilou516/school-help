export declare function canIUseModel(): boolean;
