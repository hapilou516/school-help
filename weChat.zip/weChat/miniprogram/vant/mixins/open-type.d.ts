export declare const openType: string;
