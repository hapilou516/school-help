// pages/guess/guess.js
const {http} = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    promotionTypeList:[],
  },
  getlist(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/recommend/getAll`,
      data:{
        userID:wx.getStorageSync('openid'),
      },
      success: (res) => {
        const {data} = res
        console.log(data[0]);
        console.log(res);
        this.setData({
          promotionTypeList:data[0].likes
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  selectedPromotionType: function (val) {
    const { id } = val.target.dataset //获取页面中通过data-id="{{item.id}}"传过来的值
    //遍历data中定义的promotionTypeList数组，找到当前点击的那项 val.id遍历项的id    id是传参过来的id
    let obj = this.data.promotionTypeList.find(val => val.id == id) 
    obj.isSelected = !obj.isSelected //找到后取反  本来是选中的变成不选中，本来不选中的选中
    if(id == 8){
      this.data.promotionTypeList.forEach(val=>{
        val.isSelected = !this.data.allSelect

      })
      this.setData({
        allSelect:!this.data.allSelect
      })
    }
    this.setData({
      promotionTypeList: this.data.promotionTypeList  //把数据重新渲染到promotionTypeList中，即渲染到页面上
    })
  },
  finishSelect(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/recommend/edit`,
      method:"post",
      data:{
        userID:wx.getStorageSync('openid'),
        isLike:1,
        likes:this.data.promotionTypeList
      },
      success: (res) => {
       wx.navigateBack({
         delta: 1,
       })
        
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  
  onLoad(options) {
    this.getlist()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})