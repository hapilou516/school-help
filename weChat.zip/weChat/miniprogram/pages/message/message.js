// pages/message/message.js
const app = getApp()
var time = require('../../utils/util.js');

const {http} = app
Page({

    /**
     * 页面的初始数据
     */
    data: {
      showSystemInfo: false,
      openId:"",
      systemMessage: [],
      chatList: [],
      isLoading: false,
      noMore: false,
      firstLoad:false,
      noticeList:[],
      showNotice:false
    },
    chooceSystemInfo: async function(e) {
      this.setData({
        showSystemInfo: true
      })
      // await this.loadMessage(1)
    },
    choocePersonalInfo: async function(e) {
      this.setData({
        showSystemInfo: false
      })
      // await this.loadMessage(1)
    },
    loadingChatUser(){
 
      wx.request({
        url: `${http}/room/setUser`,
        data:{
          openId:this.data.openId
        },
        success: (res) => {
            let {data} =res
            console.log(data);
            this.setData({
                chatUser:data
            })
            console.log(data);

            this.pushData()
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
    },
    pushData(){
          wx.request({
            url: `${http}/room/checkByid`,
            data:{
              openId:this.data.openId
            },
            success: (res) => {
                let {data} =res
                console.log(data);
                let {chatUser} =this.data
                data.forEach((item,index) => {
                  chatUser[index].groupId = item._id
                  if (item.buyId == this.data.openId) {
                    chatUser[index].label = "商家"
                  }
                  else{
                    chatUser[index].label = "买家"
                  }
                  let textContent
                  this.getLastChat(item._id).then(res=>{
                      console.log(res[0]);
                      if(res!==undefined ){
                        textContent = this.helStr(res[0].textContent)
                        if (chatUser[index].sendTimeTS!=undefined && chatUser[index].sendTimeTS != res[0].sendTimeTS) {

                            chatUser[index].NoRead = true
                            chatUser[index].sendTimeTS = res[0].sendTimeTS
                          
                            if (res[0].textContent!=="") {
                              chatUser[index].content = textContent
                            } else {
                           chatUser[index].content = "【图片】"                  
                            }     
                            console.log("第一个if执行");
                            this.setData({
                                chatUser
                            })
                        }
                        if (!this.data.firstLoad) {
                            chatUser[index].sendTimeTS = res[0].sendTimeTS
                            if (res[0].textContent!=="") {
                              chatUser[index].content = textContent
                            } else {
                           chatUser[index].content = "【图片】"                  
                            }     
                            console.log("第二个if执行");

                            this.setData({
                                chatUser,
                            })
                        }
                        // chatUser[index].NoRead =false
                      
                      }

                })
                    console.log(chatUser[index]["groupId"] );
                });
                // this.setData({
                //     firstLoad:true
                // })
    
            },
            fail: (res) => {
              wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
              })
              wx.hideLoading();
            }
          })
    },
    goRoom(e){
      let {id} =  e.currentTarget.dataset
      wx.navigateTo({
        url: '../details/room/room?id=' +id,
  })
    },
    startInter : function(){
      var that = this;
      console.log(that.data.inter);
      that.data.inter= setInterval(
          function () {
              that.pushData()
              console.log('setInterval 每过500毫秒执行一次任务')
          }, 5000);    
    },
    endInter: function(){
      var that = this;
      clearInterval(that.data.inter)
      that.setData({
        inter:null
      })
    },
    helStr(Str){
      if (Str.length>15) {
        Str = Str.substr(0,15) + "..."
      }
      return Str
    },
    getLastChat(groupId) {
        return new Promise((resolve, reject) => {
          wx.request({
            url: `${http}/chatRoom/getOne`,
            method: 'get',
            data:{
                groupId:groupId
            },
            success: res => {
                const {data} =res   
                // console.log(data.textContent);     
                resolve(data) 
            }
          })
        })
      }
      ,
    /**
     * 生命周期函数--监听页面加载
     */
    async checkUserInfo(openId){
        wx.showLoading({
            title: '加载中',
          })
       const  result = await wx.request({
            url: `${http}/user/find`,
            method:"get",
            data:{
                openid:openId
            },
            success: (res) => {
              console.log(res.data[0]);
              // 商品卡片进行解构
              this.setData({
                logged: true,
                avatarUrl: res.data[0].userInfo.avatarUrl,
                userInfo: res.data[0].userInfo
              })
              wx.hideLoading();
    
            },
            fail: (res) => {
              wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
              })
              wx.hideLoading();
            }
          })
          return result
    },
    goOrder(e){
        let {value} =  e.currentTarget.dataset

        if (value<2) {
            wx.navigateTo({
                url: '../myPush/myPush?value=' +value,
          })

        }
        if (value == 2) {
            console.log("dad");
            wx.navigateTo({
                url: '../myBuy/myBuy?value=' +value,
          })
        }

    },
    // 通知函数
    firstNoticeProcess(){
        // 获取卖家订单
        wx.request({
            url: `${http}/notice/process`,
            data:{
              id:this.data.openId
            },
            success: (res) => {
                let {data} =res
                let notice = new Object()
                notice = {
                    img:"/img/notice-1.png",
                    type:"物流详情",
                    content:` 你有${data.count}件商品正在上架`,
                    time:time.formatTime(new Date(),'Y/M/D h:m:s'),
                    show:data.count
                }

                this.setData({
                    noticeList: this.data.noticeList.concat(notice)              
                })
                if (data.count > 0) {
                  this.setData({
                    showNotice:true

                  })
                }
            },
            fail: (res) => {
              wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
              })
              wx.hideLoading();
            }
          })
        wx.request({
        url: `${http}/notice/push`,
        data:{
            id:this.data.openId
        },
        success: (res) => {
            let {data} =res
            let notice = new Object()
            notice = {
                img:"/img/sendGoods.png",
                type:"商品发货",
                content:` 你有${data.count}件商品待发货`,
                time:time.formatTime(new Date(),'Y/M/D h:m:s'),
                show:data.count
            }

            this.setData({
                noticeList: this.data.noticeList.concat(notice)
            
            })
            if (data.count > 0) {
              this.setData({
                showNotice:true

              })
            }
        },
        fail: (res) => {
            wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
            })
            wx.hideLoading();
        }
        })
        wx.request({
            url: `${http}/notice/buyProcess`,
            data:{
                id:this.data.openId
            },
            success: (res) => {
                let {data} =res
                let notice = new Object()
                notice = {
                    img:"/img/receive.png",
                    type:"签收信息",
                    content:` 你有${data.count}件商品待签收`,
                    time:time.formatTime(new Date(),'Y/M/D h:m:s'),
                    show:data.count
                }
    
                this.setData({
                    noticeList: this.data.noticeList.concat(notice)
                
                })
                if (data.count > 0) {
                  this.setData({
                    showNotice:true

                  })
                }
            },
            fail: (res) => {
                wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
                })
                wx.hideLoading();
            }
            })
    },

    onLoad() {
      app.checkUserInfo()
      this.setData({
        openId:wx.getStorageSync('openid')
      })
      this.firstNoticeProcess()

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
      app.checkUserInfo()
      this.loadingChatUser()

    //   this.startInter()
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {
      console.log("页面隐藏");
      this.setData({
        firstLoad:false
      })
      this.endInter()
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
      
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})