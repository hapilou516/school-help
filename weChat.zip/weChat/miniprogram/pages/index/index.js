const app = getApp()
const db = wx.cloud.database();
const config = require("../../config.js");
const _ = db.command;
const http = app.http
Page({
      data: {
            userinfo: '',
            college: JSON.parse(config.data).college,
            collegeCur: -2,
            nomore: false,
            list: [],
            recommendShow:false,
            openid: "",
            buttons: [
                  {
                        label: '订单',
                        icon: '../../img/fabButtom/order.png',
                        hideShadow: true,
                        className:"fabColor"
                  },
                  {
                        label: '闲置',
                        icon: '../../img/fabButtom/rent.png',
                        hideShadow: true
                  },
                  {
                    label: '发任务',
                    icon: '../../img/fabButtom/sendTask.png',
                    hideShadow: true,
              },
            ],
            scrollTop: -1,
            minscreenHeight: 0,

            indexlist:[
                'https://taoan.top/file/banner/1.png',
                'https://taoan.top/file/banner/2.jpg',
                'https://taoan.top/file/banner/3.png',
                'https://taoan.top/file/banner/4.png',
                'https://taoan.top/file/banner/5.png',
              ],
              current:0,
              index:0,
              promotionTypeList: [
                {
                      name: '学习',
                      id: 0,
                      isSelected:false,
                },
                {
                      name: '数码',
                      id: 1,
                      isSelected:false,
                },
                {
                      name: '装饰品',
                      id: 2,
                      isSelected:false,
                },
                {
                      name: '衣物',
                      id: 3,
                      isSelected:false,
                },
                {
                      name: '运动器材',
                      id: 4,
                      isSelected:false,
                },
                {
                      name: '化妆品',
                      id: 5,
                      isSelected:false,
                },
                {
                      name: '交通工具',
                      id: 6,
                      isSelected:false,
                },
                {
                  name: '其他',
                  id: 7,
                  isSelected:false,
                },
                {
                  name: '全选',
                  id: 8,
                  isSelected:false,
                }
          ],
              allSelect:false
          
      },
      onClick(e) {
            switch (e.detail.index) {
                  case 0:
                        wx.navigateTo({
                              url: '../myBuy/myBuy',
                        })
                        break;
                  case 1:
                    this.getPower()
                    
                        break;
                    case 2:
                        wx.navigateTo({
                            url: '../sendTotalTask/sendTotalTask',
                      })
                        break;
            }
      },
       getPower(){
        wx.request({
          url: `${http}/user/getPower`,
          data:{
            _id:wx.getStorageSync('openid')
          },
          success: (res) => {
            if (res.data =="封禁用户") {
              wx.showToast({
                icon: 'none',
                title: '你的账号已被封禁，不能发布商品',
              })
            }
            else{
              wx.navigateTo({
                url: '../publish/publish',
               })
            }
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
      setOpenID(){
        const openid = wx.getStorageSync('openid')
        const that = this
        if(!openid){
            wx.login({
                success (res) {
                  if (res.code) {
                    //发起网络请求
                    wx.request({
                      url: `${http}/login`,
                      data: {
                        code: res.code
                      },
                      success:(res)=>{
                        const {openid} =res.data
                        wx.setStorageSync('openid', openid)
                        that.setData({
                          openid
                        })
                      }
                    })
                  } else {
                    console.log('登录失败！' + res.errMsg)
                  }
                  
                }
              })
        }
        this.setData({
          openid
        })
      },
      selectedPromotionType: function (val) {
        const { id } = val.target.dataset //获取页面中通过data-id="{{item.id}}"传过来的值
        //遍历data中定义的promotionTypeList数组，找到当前点击的那项 val.id遍历项的id    id是传参过来的id
        let obj = this.data.promotionTypeList.find(val => val.id == id) 
        obj.isSelected = !obj.isSelected //找到后取反  本来是选中的变成不选中，本来不选中的选中
        if(id == 8){
          this.data.promotionTypeList.forEach(val=>{
            val.isSelected = !this.data.allSelect
    
          })
          this.setData({
            allSelect:!this.data.allSelect
          })
        }
        this.setData({
          promotionTypeList: this.data.promotionTypeList  //把数据重新渲染到promotionTypeList中，即渲染到页面上
        })
      },
      finishSelect(){
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${http}/recommend/edit`,
          method:"post",
          data:{
            userID:wx.getStorageSync('openid'),
            isLike:1,
            likes:this.data.promotionTypeList
          },
          success: (res) => {
            
            this.setData({
              recommendShow:false
            })
            wx.hideLoading();
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
      likeSelect(){
        let that = this
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${http}/recommend/liksSelect`,
          method:"get",
          data:{
            userID:wx.getStorageSync('openid')
          },
          success: (res) => {
            const {data} =res
            if(data.length == 0){
              this.getAlllist()
            }
            else{
             
              this.setData({
                list: that.shuffle(data)
              })
            }
            
            // this.setData({
            //   recommendShow:false
            // })
            wx.hideLoading();
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
      onLoad() {
            this.setOpenID()
            this.initCollection()
            this.checkRecommend()
            this.likeSelect()

            // this.checkUserInfo()
      },
      // 查询并创建收藏表
      initCollection(){
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${http}/collection/create`,
          method:"post",
          data:{
            userID:this.data.openid,
            time:new Date().getTime(),
            name:"商品闲置",
            goods:[],
            likes:[]
          },
          success: (res) => {
            wx.hideLoading();
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
      checkUserInfo(){
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${http}/user/check`,
          data:{
            _id:wx.getStorageSync("openid"),
          },
          success: (res) => {
            if(res.data.length == 0){
              wx.showToast({
                icon:"none",
                title: '还未登录，请授权登录',
              })
              setTimeout(()=>{
                wx.switchTab({
                  url: '/pages/my/my',
                 })
              },2000)
            }
            
            wx.hideLoading();
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
      checkRecommend(){
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${http}/recommend/check`,
          data:{
            userID:wx.getStorageSync('openid'),
          },
          success: (res) => {
            console.log(res);
            const {data} = res
            let state = data[0].isLike
              this.setData({
                recommendShow:!state
              })
              if(!this.data.recommendShow){
                this.checkUserInfo()
              }
            wx.hideLoading();
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
      //跳转搜索
      search() {
            wx.navigateTo({
                  url: '/pages/seller/seller',
            })
      },
      detail(e){
        console.log("aadfad");
        wx.navigateTo({
          url: '/pages/details/details?id=' + e.currentTarget.dataset.id,
        })
      },
      // 闲置获取数据
      // getList(e) {
      //       // wx.showLoading({
      //       //       title: '加载中',
      //       // })
      //       let that = this;
      //       if (that.data.collegeCur == -2) {
      //             var collegeid = _.neq(-2); //除-2之外所有
      //       } else {
      //             var collegeid = that.data.collegeCur + '' //小程序搜索必须对应格式
      //       }
      //       db.collection('publish').where({
      //             status: 0,
      //             dura: _.gt(new Date().getTime()),
      //             collegeid: collegeid
      //       }).orderBy('creat', 'desc').limit(20).get({ //数据一次性不建议获取太多，减少时耗
      //             success: function (res) {
      //                   wx.stopPullDownRefresh(); //暂停刷新动作
      //                   wx.hideLoading();
      //                   if (res.data.length == 0) {
      //                         that.setData({
      //                               nomore: true,
      //                               list: [],
      //                         })
      //                         return false;
      //                   }
      //                   if (res.data.length < 20) {
      //                         that.setData({
      //                               nomore: true,
      //                               page: 0,
      //                               list: res.data,
      //                         })
      //                   } else {
      //                         that.setData({
      //                               page: 0,
      //                               list: res.data,
      //                               nomore: false,
      //                         })
      //                   }
      //             }
      //       })
      // },
      // 获取更多
      more() {
            let that = this;
            if (that.data.nomore || that.data.list.length < 20) {
                  return false
            }
            let page = that.data.page + 1;
            if (that.data.collegeCur == -2) {
                  var collegeid = _.gt(-2); //除-2之外所有
            } else {
                  var collegeid = that.data.collegeCur + '' //小程序搜索必须对应格式
            }
            db.collection('publish').where({
                  status: 0,
                  dura: _.gt(new Date().getTime()),
                  collegeid: collegeid
            }).orderBy('creat', 'desc').skip(page * 20).limit(20).get({
                  success: function (res) {
                        if (res.data.length == 0) {
                              that.setData({
                                    nomore: true
                              })
                              return false;
                        }
                        if (res.data.length < 20) {
                              that.setData({
                                    nomore: true
                              })
                        }
                        that.setData({
                              page: page,
                              list: that.data.list.concat(res.data)
                        })
                  },
                  fail() {
                        wx.hideLoading();
                        wx.showToast({
                              title: '没有更多了',
                              icon: 'none'
                        })
                  }
            })
      },
      // 触底
      onReachBottom() {
            this.more();
      },
      //下拉刷新
      onPullDownRefresh() {
            this.likeSelect();
            wx.stopPullDownRefresh({
              success: (res) => {},
            })
      },
      //跳转详情


      onShow() {
            this.likeSelect()
      },
      // 导航栏路由携带数据跳转
      go(e) {
        const {id} = e.currentTarget.dataset
        console.log(id);
        if (id==1) {
          wx.navigateTo({
            url: '../seller/seller?name=' + "deliver"  
      })
        }
        else if (id==2) {
              wx.navigateTo({
                url: '../seller/seller?name=' + "seller" 
          })
        }
        else  if (id==3) {
            wx.navigateTo({
              url: '../seller/seller?name=' + "task"  
        })
        }
        else if (id==5) {
          wx.navigateTo({
            url: '../seller/seller?name=' + "auction"  
         })
       }
        else{
          wx.showToast({
            icon:"none",
            title: '等待后续完善',
          })
        }
      },

      //为了数据安全可靠，每次进入获取一次用户信息
      // getuserdetail() {
      //       let that = this
      //       if (!app.openid) {
      //             wx.cloud.callFunction({
      //                   name: 'regist', // 对应云函数名
      //                   data: {
      //                         $url: "getid", //云函数路由参数
      //                   },
      //                   success: re => {
      //                         db.collection('user').where({
      //                               _openid: re.result
      //                         }).get({
      //                               success: function (res) {
      //                                     if (res.data.length !== 0) {
      //                                           that.setData({
      //                                                 userinfo: res.data[0]
      //                                           })
      //                                           app.openid = re.result;
      //                                           app.userinfo = res.data[0];
      //                                           console.log(app)
      //                                     }
      //                                     console.log(res)
      //                               }
      //                         })
      //                   }
      //             })
      //       }
      // },
      // 归顶
      toTop() {
            wx.pageScrollTo({
                  scrollTop: -1,
                  duration: 300
            })
      },
      getHeight(n) {
            var _this = this;
            wx.getSystemInfo({
                  success: function (res) {
                        _this.data.minscreenHeight = res.windowHeight * n
                  }
            })
      },
      getAlllist(){
        wx.showLoading({
            title: '加载中',
          })
          wx.request({
            url: `${http}/getSellerAllOrder`,
            success: (res) => {
              console.log(res);
              const {
                data
              } = res;
              // 商品卡片进行解构
              this.setData({
                list: data,
              })
              wx.hideLoading();
            },
            fail: (res) => {
              wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
              })
              wx.hideLoading();
            }
          })
    },
      onPageScroll(e) { // 获取滚动条当前位置
            this.setData({
                  scrollTop: e.scrollTop
            })
      },
      onLaunch() {
            this.getHeight(1)
      },
      // 路由
      goto(e) {
            this.selectComponent('#message').hide()
            wx.navigateTo({
                  url: e.currentTarget.dataset.goto,
            })
      },
    shuffle(arr) {
        let i = arr.length;
        while (i) {
            let j = Math.floor(Math.random() * i--);
            [arr[j], arr[i]] = [arr[i], arr[j]];
        }
        return arr;
    }
})