// pages/collection/collection.js
const {http} = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    CollectionList:[],
    oldAndNew:["全新","9成新","8成新","7成新","6成新"],
  },
  getAlldata(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/collection/getAll`,
      method:"post",
      data:{
        userID:wx.getStorageSync('openid'),
      },
      success: (res) => {
        const {data} = res
        console.log(data[0].goods);
        this.setData({
          CollectionList:data[0].goods
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  delete(e){
    let GoodsInfo = e.currentTarget.dataset.item;
    console.log(GoodsInfo);
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/collection/drop`,
      method:"post",
      data:{
        userID:wx.getStorageSync('openid'),
        GoodsInfo
      },
      success: (res) => {
        const {data} =res
        if(data== "success"){
            this.getAlldata()  
        }
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  godetail(e){
    wx.navigateTo({
      url: '/pages/details/details?id=' + e.currentTarget.dataset.id,
    })
  },
  // onClose(event) {
  //   const { position, instance } = event.detail;
  //   switch (position) {
  //     case 'left':
  //     case 'cell':
  //       instance.close();
  //       break;
  //     case 'right':
  //       Dialog.confirm({
  //         message: '确定删除吗？'
  //       }).then(() => {
  //         instance.close();
  //       });
  //       break;
  //   }
  // },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getAlldata()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.getAlldata()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})