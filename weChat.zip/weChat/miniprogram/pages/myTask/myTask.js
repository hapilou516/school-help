// pages/myBuy/myBuy.js
const {http} = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    active: 0,
    id:"",
    show: false,
    rateId:'',
    value: 3,
    auctionList:[],
    addres:""
  },
  onConfirm(event) {
    this.setRate()
  },
  onClose() {
    this.setData({ close: false });
  },
  onCloseAddress() {
    this.setData({ addressShow: false });
  },
  selectAddress(e) {
    wx.setStorageSync('urlNow','publish')
    wx.navigateTo({
      url: '../address/address',
    })
},
  onConfirmAddress(){
      let {addressId,address,phone} = this.data
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/setMyBuyOrder/address`,
        data:{
          id:addressId,
          address,
          phone,
          openid:wx.getStorageSync('openid')
        },
        success: (res) => {
          this.onLoad()
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
  },
  onChange(event) {
    if(event.detail.index ==1){
        this.getAuction()
     }
    if(event.detail.index ==2){
       this.getMyProcessBuyOrder()
    }
    if(event.detail.index ==3){
      this.getMyCancelBuyOrder()
   }
   if(event.detail.index ==4){
    this.getMyFinishBuyOrder()
 }
  },
  onRateChange(event) {
    this.setData({
      value: event.detail
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      id:wx.getStorageSync('openid')
    })
    if (options) {
        this.setData({
           active :Number(options.value) - 1
        })
   }
    this.getMyBuyOrder()
    this.getMyProcessBuyOrder()
    this.getMyCancelBuyOrder()
    this.getMyFinishBuyOrder()
    this.getAuction()
    const address = wx.getStorageSync("addressNow")
    if(address){
      const {building,houseNumber,phone}  = address
      this.setData({address:`${building}-${houseNumber}`,phone})
  }
  },
  delChange(e) {
    let that = this;
    let delivery = that.data.delivery;
    let id = e.detail.value;
    for (let i = 0; i < delivery.length; i++) {
          delivery[i].check = false
    }
    delivery[id].check = true;
    if (id == 1) {
          that.setData({
                delivery: delivery,
                chooseDelivery: 1
          })
    } else {
          that.setData({
                delivery: delivery,
                chooseDelivery: 0
          })
    }
},
  godetail(e){
    let {id} = e.currentTarget.dataset
    console.log("商品详情页");
    wx.navigateTo({
      url: '../details/details?id=' + id,
    })
  },
  // 按钮触发组
  start(e){
    let id = e.currentTarget.dataset.id;
    this.setData({
      rateId:id,
      show:true
    })
  },
  // 立即付款
  confirmPrice(e){
    let id = e.currentTarget.dataset.id;
    if (this.data.addres == "") {
      wx.showToast({
        icon: 'none',
        title: '请先填写地址',
      })
    }
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/setMyBuyOrder/confirmPrice`,
      data:{
        id:id,
      },
      success: (res) => {
        this.onLoad()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  // 评分订单
  setRate() {
    let {rateId,value} = this.data
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/setMyBuyOrder/rate`,
      data:{
        id:rateId,
        rate:value
      },
      success: (res) => {
        this.onLoad()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  writeAddress(e){
    let id = e.currentTarget.dataset.id;
    this.setData({
      addressId:id,
      addressShow:true
    })
  },

  // 删除订单
  dropOrder(e) {
    let id = e.currentTarget.dataset.id;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/setMyBuyOrder/dropOrder`,
      data:{
        id:id
      },
      success: (res) => {
        this.onLoad()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  }, 
  cancelOrder(e) {
    console.log("as");
    let id = e.currentTarget.dataset.id;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/setMyTaskOrder/cancel`,
      data:{
        id:id
      },
      success: (res) => {
        this.onLoad()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  }, 
  finishOrder(e) {
    let id = e.currentTarget.dataset.id;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/setMyBuyOrder/finish`,
      data:{
        id:id
      },
      success: (res) => {
        this.onLoad()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  }, 
  getAuction(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/deliver/getOrder`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          auctionList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  getMyBuyOrder(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getMyTaskOrder/All`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          allList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  custS(){
    var buyId = wx.getStorageSync('openid')
    var sallerId = "oF8HP5YvXxxbxbcBXYemDo8XMIlI"
    if (true) {
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/room/check`,
        data:{
          buyId, sallerId 
        },
        success: (res) => {
          console.log(res);
          if (res.data.length > 0) {
            this.setData({
                  roomID: res.data[0]._id
            })
            wx.request({
              url: `${http}/room/updateDeleted`,
              data:{
                _id: res.data[0]._id
              },
              success:(response)=>{
                wx.navigateTo({
                  url: '../details/room/room?id=' + this.data.roomID,
            })
              }
            })
            
      } else {
            wx.request({
              url: `${http}/room/add`,
              method:"post",
              data:{
                buyId,
                sallerId,
                deleted: 0
              },
              
              success:(res)=>{
                const {data} =res
                this.setData({
                  roomID: res._id
            })
                wx.navigateTo({
                  url: '../details/room/room?id=' + data._id,
            })
            }                        
          })
          
      }
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
    } else {
          wx.showToast({
                title: '无法和自己建立聊天',
                icon: 'none',
                duration: 1500
          })
    } 
  },
  messageSeller(e){
    let item = e.currentTarget.dataset.id
    console.log(item);
    var buyId = wx.getStorageSync('openid');
    var sallerId = item.publishID
    if (buyId != sallerId) {
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/room/check`,
        data:{
          buyId, sallerId 
        },
        success: (res) => {
          console.log(res);
          if (res.data.length > 0) {
            this.setData({
                  roomID: res.data[0]._id
            })
            wx.request({
              url: `${http}/room/updateDeleted`,
              data:{
                _id: res.data[0]._id
              },
              success:(response)=>{
                wx.navigateTo({
                  url: '../details/room/room?id=' + this.data.roomID,
            })
              }
            })
            
      } else {
            wx.request({
              url: `${http}/room/add`,
              method:"post",
              data:{
                buyId,
                sallerId,
                deleted: 0
              },
              
              success:(res)=>{
                const {data} =res
                this.setData({
                  roomID: res._id
            })
                wx.navigateTo({
                  url: '../details/room/room?id=' + data._id,
            })
            }                        
          })
          
      }
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
    } else {
          wx.showToast({
                title: '无法和自己建立聊天',
                icon: 'none',
                duration: 1500
          })
    }
  },
  getMyProcessBuyOrder(){
      console.log("切换代拿订单");
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getMyTaskOrder/process`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          processList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  countTime(str){
    var date = new Date();

            var now = date.getTime();

            //设置截止时间

            var endDate = new Date(str);

            var end = endDate.getTime();

            //获取截止时间和当前时间的时间差

            var leftTime = end-now;

            //定义变量 d,h,m,s分别保存天数，小时，分钟，秒

            var d,h,m,s;

            //判断剩余天数，时，分，秒

            if (leftTime>=0) {

                d = Math.floor(leftTime/1000/60/60/24);

                h = Math.floor(leftTime/1000/60/60%24);

                m = Math.floor(leftTime/1000/60%60);

                s = Math.floor(leftTime/1000%60);                   

            }
            return d+"天"+h+"时"+m+"分"
  },
  getMyCancelBuyOrder(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getMyTaskOrder/cancel`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          cancelList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  getMyFinishBuyOrder(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getMyTaskOrder/finish`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          finishList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    if (wx.getStorageSync('urlNow') ==  "confirmOrder") {
      let pages = getCurrentPages().length - 1;
        console.log('需要销毁的页面：'+pages);
        wx.setStorageSync('urlNow', "")
        wx.navigateBack({
          delta: pages
        })
        

    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.getMyBuyOrder()
     wx.stopPullDownRefresh({
       success: (res) => {},
     })
 },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})