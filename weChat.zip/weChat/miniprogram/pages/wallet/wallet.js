// pages/wallet/wallet.js
const app = getApp()
const {http} = app
Page({

  /**
   * 页面的初始数据
   */
  data: {
    chargeShow:false,
    extractMoneyShow:false,
    money:0,
    openid:"",
    payAarry:["微信支付","支付宝支付","银联支付"],
    cids:-1,
    ciddds:0,
    pay:[{name:"微信支付",id:0},{name:"支付宝支付",id:1},{name:"银联支付",id:2}],
    inputMoney:0
  },
  showCharge(){
    this.setData({
      chargeShow:true
    })
  },
  onCloseChargeShow(){
    this.setData({
      chargeShow:false
    })
  },
  showExtractMoney(){
    this.setData({
      extractMoneyShow:true
    })
  },
  onCloseExtractMoneyShow(){
    this.setData({
      extractMoneyShow:false
    })
  },
  getMoeny(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/user/find`,
      data:{
        openid:this.data.openid,
      },
      success: (res) => {
        if (res.data > 0) {
           this.setData({
             money:res.data[0].wallet
           })
        }
        
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  chopay(e) {
    let that = this;
    console.log(e.detail.value);
    that.setData({
          cids: e.detail.value
    })
  },
  priceChange(e) {
    this.setData({
      price:e.detail.value
    })
    
  },
  confirmPrice(e){

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.setData({
      openid:wx.getStorageSync('openid')
    })
    this.getMoeny() 
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})