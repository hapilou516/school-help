Page({
  onLoad() {
      var models = [
          {url:"https://onekit.cn/examples/ar/1/glass.glb",scale:30,position:{x:2,y:2,z:0}},
          {url:"https://onekit.cn/examples/ar/2/glass.glb",scale:20,position:{x:0,y:0,z:0}},
          {url:"https://onekit.cn/examples/ar/3/glass.glb",scale:30,position:{x:-2,y:-2,z:0}}
      ]
      var bg = "https://onekit.cn/examples/ar/bg.gif"
      var hdr = `https://onekit.cn/examples/ar/sky_box.hdr`
      this.setData({
          hdr,
          bg,
          models
      })
  }
})