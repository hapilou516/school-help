const app = getApp();
const {http} = app
Page({

      /**
       * 页面的初始数据
       */
      data: {
            showShare: false,
            hasUserInfo:false,
            username: '',
            openid: '',
            roomlist: [],
            ids: '',
            messageNum: 0,
            showShare: false,
            userInfo:{},
            options: [
                  { name: '微信', icon: 'wechat', openType: 'share' },
                  { name: '建议反馈', icon: 'link', openType: 'feedback' }
            ],
      },
      getUserInfo(){
        wx.getUserProfile({
            desc: '获取用户信息',
            success: (res) => {
                const random = Math.floor(Math.random() * 1000);
                console.log(res.userInfo.avatarUrl);
                this.setData({
                    userInfo: res.userInfo,
                    hasUserInfo: true
                })
                wx.setStorageSync('userInfo', res.userInfo);
                this.checkUserInfo()
            }
        })
      },
      checkUserInfo(){
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${http}/user/check`,
          data:{
            _id:this.data.openid,
          },
          success: (res) => {
            if(res.data.length == 0){
              const data = this.data
              console.log(data);
              wx.request({
                url: `${http}/user/add`,
                method:"POST",
                data:{
                  openid:data.openid,
                  name:data.userInfo.nickName,
                  userID:data.openid,
                  userIDImg:data.userInfo.avatarUrl,
                  userInfo:data.userInfo,
                  time:new Date().getTime()
                },
                success: (res) => {
                  console.log(res);
                  wx.setStorage("openid",data.openid)
                  wx.hideLoading();
                },
                fail: (res) => {
                  wx.showToast({
                    icon: 'none',
                    title: '服务器异常~~~',
                  })
                  wx.hideLoading();
                }
              })
            }
            
            wx.hideLoading();
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
      onShow() {
           //  给头像昵称赋值
           let userInfo = wx.getStorageSync('userInfo');
           this.setData({
               hasUserInfo: !!userInfo,
               userInfo: userInfo,
               openid:wx.getStorageSync('openid')
           }) 
      },
      updateUserInfo(){
        if (this.data.hasUserInfo) {
            wx.navigateTo({
                url: '../updateInfo/updateInfo',
            })
        }
      },
      onLoad: function (options) {
           //  给头像昵称赋值
           let userInfo = wx.getStorageSync('userInfo');
           this.setData({
               hasUserInfo: !!userInfo,
               userInfo: userInfo,
               openid:wx.getStorageSync('openid')
           }) 

      },
      goBuy(){
        wx.navigateTo({
          url: '../myBuy/myBuy',
        })
      },
      goo() {
            console.log(app.roomlist);
            if (!app.openid) {
                  this.selectComponent('#message').show()
                  return false
            } else {
                  wx.navigateTo({
                        url: '../message/message',
                  })
            }

      },
      go(e) {
            // if (e.currentTarget.dataset.status == '1') {
            //       if (!app.openid) {
            //             this.selectComponent('#message').show()
            //             return false
            //       }
            // }
            wx.navigateTo({
                  url: e.currentTarget.dataset.go
            })
      },
      //展示分享弹窗
      showShare() {
            this.setData({
                  showShare: true
            });
      },
      //关闭弹窗
      closePop() {
            this.setData({
                  showShare: false,
            });
      },
      onShareAppMessage() {
            return {
                  title: `欢迎加入闲柠校园`,
                  path: `/pages/index/index`,
                  imageUrl: 'https://636c-cloud1-2gdd2s9o9f6b260f-1310396970.tcb.qcloud.la/file.jpg?sign=962fbbc5ac3fabd846da740550b60abe&t=1662983995'
            }
      },
    //  联系客服
    message(){

        var buyId = wx.getStorageSync('openid')
        var sallerId = "oF8HP5YvXxxbxbcBXYemDo8XMIlI"
        if (true) {
          wx.showLoading({
            title: '加载中',
          })
          wx.request({
            url: `${http}/room/check`,
            data:{
              buyId, sallerId 
            },
            success: (res) => {
              console.log(res);
              if (res.data.length > 0) {
                this.setData({
                      roomID: res.data[0]._id
                })
                wx.request({
                  url: `${http}/room/updateDeleted`,
                  data:{
                    _id: res.data[0]._id
                  },
                  success:(response)=>{
                    wx.navigateTo({
                      url: '../details/room/room?id=' + this.data.roomID,
                })
                  }
                })
                
          } else {
                wx.request({
                  url: `${http}/room/add`,
                  method:"post",
                  data:{
                    buyId,
                    sallerId,
                    deleted: 0
                  },
                  
                  success:(res)=>{
                    const {data} =res
                    this.setData({
                      roomID: res._id
                })
                    wx.navigateTo({
                      url: '../details/room/room?id=' + data._id,
                })
                }                        
              })
              
          }
              wx.hideLoading();
            },
            fail: (res) => {
              wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
              })
              wx.hideLoading();
            }
          })
        } else {
              wx.showToast({
                    title: '无法和自己建立聊天',
                    icon: 'none',
                    duration: 1500
              })
        } 
      },
      //获取授权的点击事件
      //退出登录



      onClick(event) {
            this.setData({ showShare: true });
      },

      onClose() {
            this.setData({ showShare: false });
      },

      onSelect(event) {
            this.onClose();
      },
      goto(e) {
            this.selectComponent('#message').hide()
            wx.navigateTo({
                  url: e.currentTarget.dataset.goto,
            })
      },
})