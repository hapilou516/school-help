// pages/about/about.js
const {http} = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
      imgs1: [{
        url: `https://thirdwx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEIOBu8qHxpVMZkoYTNdU7WIgiazV4uGTzQV317oXPicktBzOEmJicNrx4wVFYk7497agUkDBA4lzic5Ow/132`,
        name: '桃良长安',
        id: "0"
      },
      {
        url: `${http}/file/image/1665829506228.jpg`,
        name: '偉',
        id: "1"
      },
      {
        url: `${http}/file/image/1665828921044.jpg`,
        name: ' 尘榭',
        id: "2"
      },
      ],
      des: '随着社会经济快速发展，大学生消费方式正在改变，线上消费逐渐成为一种主流趋势，但目前来看，市场上缺乏一种真正针大学生群体的消费平台，让用户与用户间服务。对此，我们团队构建了一种以“用户服务用户”为宗旨的针对大学生群体的校园生态平台。本平台将为用户提供接单和出单的服务，用户可以为用户提供快递代拿，闲置物品出租、任务服务、教学服务，并打造用户交流社区，共同构建一个便捷化、一体化、个性化的和谐校园。'
    },
  
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      // // 在页面中定义插屏广告
      // let interstitialAd = null
  
      // // 在页面onLoad回调事件中创建插屏广告实例
      // if (wx.createInterstitialAd) {
      //   interstitialAd = wx.createInterstitialAd({
      //     adUnitId: 'adunit-dfbad1c323913ca2'
      //   })
      //   interstitialAd.onLoad(() => {})
      //   interstitialAd.onError((err) => {})
      //   interstitialAd.onClose(() => {})
      // }
  
      // // 在适合的场景显示插屏广告
      // if (interstitialAd) {
      //   interstitialAd.show().catch((err) => {
      //     console.error(err)
      //   })
      // }
    },
  
    //图片点击事件
    img: function (event) {
      let arr = [];
      arr.push('https://636c-cloud1-2gdd2s9o9f6b260f-1310396970.tcb.qcloud.la/mm_reward_qrcode_1649908305610.png?sign=ea0b6d1102353474c54ff89eb426ba95&t=1649910488')
      wx.previewImage({
        current: 'current', // 当前显示图片的http链接
        urls: arr // 需要预览的图片http链接列表
      })
    },
    onReady: function () {
  
    },
    //复制
    copy(e) {
      wx.setClipboardData({
        data: e.currentTarget.dataset.copy,
        success: res => {
          wx.showToast({
            title: '复制' + e.currentTarget.dataset.name + '成功',
            icon: 'success',
            duration: 1000,
          })
        }
      })
    },
    onBack(){
      wx.navigateBack({
        delta: 0,
      })
    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
  
    }
  })