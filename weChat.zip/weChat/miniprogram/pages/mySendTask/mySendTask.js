// pages/myPublish/myPublish.js
const {http} = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    active: 0,
    id:"",
    show:false,
    priceId:"",
    price:0,
    rateshow:false
  },
// tab栏切换
  onChange(event) {
    if(event.detail.index ==1){
       this.getMyProcessPublishOrder()
    }
    if(event.detail.index ==2){
      this.getMyPushPublishOrder()
   }
   if(event.detail.index ==3){
    this.getMyCancelPublishOrder()
 }
 if(event.detail.index ==4){
    this.getMyFinishPublishOrder()
 }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      id:wx.getStorageSync('openid')
    })
    if (options) {
         this.setData({
            active :Number(options.value) + 1
         })
    }
    this.getMyPublishOrder()
    this.getMyProcessPublishOrder()
    this.getMyPushPublishOrder()
    this.getMyCancelPublishOrder()
    this.getMyFinishPublishOrder()
  },
  message(e){
    let {item} = e.currentTarget.dataset
    console.log(item);
    var buyId = item.receiveOpenId;
    var sallerId = item.publishID
    if (true) {
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/room/check`,
        data:{
          buyId, sallerId 
        },
        success: (res) => {
          console.log(res);
          if (res.data.length > 0) {
            this.setData({
                  roomID: res.data[0]._id
            })
            wx.request({
              url: `${http}/room/updateDeleted`,
              data:{
                _id: res.data[0]._id
              },
              success:(response)=>{
                wx.navigateTo({
                  url: '../details/room/room?id=' + this.data.roomID,
            })
              }
            })
            
      } else {
            wx.request({
              url: `${http}/room/add`,
              method:"post",
              data:{
                buyId,
                sallerId,
                deleted: 0
              },
              
              success:(res)=>{
                const {data} =res
                this.setData({
                  roomID: res._id
            })
                wx.navigateTo({
                  url: '../details/room/room?id=' + data._id,
            })
            }                        
          })
          
      }
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
    } else {
          wx.showToast({
                title: '无法和自己建立聊天',
                icon: 'none',
                duration: 1500
          })
    }
  },
  // 处理组
  outGoods(e){
    let id = e.currentTarget.dataset.id;
    let time = new Date().getTime()
    wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/setMypublishOrder/out`,
        data:{
          id:id,
          time
        },
        success: (res) => {
          this.onLoad()
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
  },
  reNewGoods(e){
    let id = e.currentTarget.dataset.id;
    let time = new Date().getTime()
    wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/setMypublishOrder/renew`,
        data:{
          id:id,
          time
        },
        success: (res) => {
          this.onLoad()
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
  },
  reNewCancelGoods(e){
    let id = e.currentTarget.dataset.id;
    let time = new Date().getTime()
    wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/setMypublishOrder/refresh`,
        data:{
          id:id,
          time
        },
        success: (res) => {
          this.onLoad()
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
  },
  cancelOrder(e) {
    console.log("as");
    let id = e.currentTarget.dataset.id;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/setMypublishOrder/cancel`,
      data:{
        id:id
      },
      success: (res) => {
        this.onLoad()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  }, 
  outCancelOrder(e) {
    let id = e.currentTarget.dataset.id;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/setMypublishOrder/outCancel`,
      data:{
        id:id
      },
      success: (res) => {
        this.onLoad()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  }, 
  // 删除订单
  dropOrder(e) {
    let id = e.currentTarget.dataset.id;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/setMypublishOrder/dropOrder`,
      data:{
        id:id
      },
      success: (res) => {
        this.onLoad()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  }, 
  // 获取组
  getMyPublishOrder(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getMySendTaskOrder/All`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          allList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  getMyProcessPublishOrder(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getMySendTaskOrder/process`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          processList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
    // 立即付款
    confirmPrice(e){
        let id = e.currentTarget.dataset.id;
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${http}/setMySendTaskOrder/confirmPrice`,
          data:{
            id:id,
          },
          success: (res) => {
            this.onLoad()
            wx.hideLoading();
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
  getMyPushPublishOrder(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getMySendTaskOrder/push`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
            pushList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  onClose() {
    this.setData({ close: false });
  },
  onConfirm(event) {
    this.setRate()
  },
  setRate() {
    let {rateId,value} = this.data
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/setMyBuyOrder/rate`,
      data:{
        id:rateId,
        rate:value
      },
      success: (res) => {
        this.onLoad()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  onRateChange(event) {
    this.setData({
      value: event.detail
    });
  },
  startRate(e){
    let id = e.currentTarget.dataset.id;
    this.setData({
      rateId:id,
      rateShow:true
    })
  },
  getMyCancelPublishOrder(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getMySendTaskOrder/price`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          cancelList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  getMyFinishPublishOrder(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getMySendTaskOrder/finish`,
      data:{
        id:this.data.id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          finishList: data,
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  godetail(e){
    console.log(e);
    let {id} = e.currentTarget.dataset
    console.log("商品详情页");
    wx.navigateTo({
      url: '../details/details?id=' + id,
    })
},
  custS(){
    var buyId = wx.getStorageSync('openid')
    var sallerId = "oF8HP5YvXxxbxbcBXYemDo8XMIlI"
    if (true) {
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/room/check`,
        data:{
          buyId, sallerId 
        },
        success: (res) => {
          console.log(res);
          if (res.data.length > 0) {
            this.setData({
                  roomID: res.data[0]._id
            })
            wx.request({
              url: `${http}/room/updateDeleted`,
              data:{
                _id: res.data[0]._id
              },
              success:(response)=>{
                wx.navigateTo({
                  url: '../details/room/room?id=' + this.data.roomID,
            })
              }
            })
            
      } else {
            wx.request({
              url: `${http}/room/add`,
              method:"post",
              data:{
                buyId,
                sallerId,
                deleted: 0
              },
              
              success:(res)=>{
                const {data} =res
                this.setData({
                  roomID: res._id
            })
                wx.navigateTo({
                  url: '../details/room/room?id=' + data._id,
            })
            }                        
          })
          
      }
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
    } else {
          wx.showToast({
                title: '无法和自己建立聊天',
                icon: 'none',
                duration: 1500
          })
    } 
  },
// 改价

    changePrice(e){
        let {id} = e.currentTarget.dataset
        wx.request({
          url: `${http}/getDetailGood/IdSelect`,
          data:{
            id:id,
          },
          success: (res) => {
            console.log(res);

            this.setData({
              price:res.data.money
            })
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
        console.log(id);
        this.setData({
            show:true,
            priceId:id      
        })
    },
    priceChange(e) {
        this.setData({
          price:e.detail.value
        })
  },
  onConfirm(){
    let {priceId,price} =this.data
    console.log();
    wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/setMypublishOrder/changePrice`,
        data:{
          id:priceId,
          money:price
        },
        success: (res) => {
          this.onLoad()
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
  },
  onCloseRate() {
    this.setData({ rateShow: false });
  },
  onCloseRate(event) {
    this.setRate()
  },
  AucitionChange(e){
    let id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/autionPublish/autionPublish?id=' + id,
  })},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
   this.getMyPublishOrder()
    wx.stopPullDownRefresh({
      success: (res) => {},
    })
},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})