
// pages/addAddress/addAddress.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        defalutAddress: true,
        building:'',
        BuildingArray:[["宿舍楼","教学楼"],["一号楼","二号楼","三号楼","四号楼","五号楼","六号楼","七号楼","八号楼","九号楼"]],          
        learnBuildings:[ {name:"求真楼",id:0},{name:"求知楼",id:1},{name:"求实楼",id:2},{name:"求是楼",id:3}],
        dormitoryBuildings:                    
            [{
                name:"一号楼",
                id:0,
            },
            {
                name:"二号楼",
                id:1,
            },
            {
                name:"三号楼",
                id:2,
            },
            {
                name:"四号楼",
                id:3,
            },
            {
                name:"五号楼",
                id:4,
            },
            {
                name:"六号楼",
                id:5,
            },
            {
                name:"七号楼",
                id:6,
            },
            {
                name:"八号楼",
                id:7,
            },
            {
                name:"九号楼",
                id:8,
            }],
        Buildings:[
            [{name:"宿舍楼",id:0},{name:"教学楼",id:1}],
            [        
            {
                name:"一号楼",
                id:0,
            },
            {
                name:"二号楼",
                id:1,
            },
            {
                name:"三号楼",
                id:2,
            },
            {
                name:"四号楼",
                id:3,
            },
            {
                name:"五号楼",
                id:4,
            },
            {
                name:"六号楼",
                id:5,
            },
            {
                name:"七号楼",
                id:6,
            },
            {
                name:"八号楼",
                id:7,
            },
            {
                name:"九号楼",
                id:8,
            },]
        ],
        multiIndex: [0, 0],
        houseNumber: '',
        name: '',
        phone: '',
        isEdit: false,
        editNow: false,
        editIndex: 0,
    },
    bindMultiPickerColumnChange(e){

        let Buildings = this.data.Buildings
        let BuildingArray =this.data.BuildingArray
        switch (e.detail.value) {
            case 0:
                Buildings[1] = this.data.dormitoryBuildings
                BuildingArray[1] = ["一号楼","二号楼","三号楼","四号楼","五号楼","六号楼","七号楼","八号楼","九号楼"]
                break;
            case 1:
                Buildings[1] = this.data.learnBuildings
                BuildingArray[1] = ["求真楼","求知楼","求实楼","求是楼"]
                break;
            
            default:
                break;
        }

        this.setData({
            Buildings,
            BuildingArray
        })
    },
    selectBuilding(e){
        console.log('picker发送选择改变，携带值为', e.detail.value)
        let multiIndex = e.detail.value
        let  BuildingArray = this.data.BuildingArray
        let building = `${BuildingArray[0][multiIndex[0]]}-${BuildingArray[1][multiIndex[1]]}`
        console.log(building);
        this.setData({
            multiIndex,
            building
          })
    },
    checkTelephone(telephone) {
        var reg=/^[1][3,4,5,7,8][0-9]{9}$/;
        if (!reg.test(telephone)) {
            return false;
        } else {
            return true;
        }
    },
    saveAddress() {
        const {
            building,
            houseNumber,
            name,
            phone,
            defalutAddress,
            isEdit,
            editNow,
            index,
        } = this.data;
        if (!building || !houseNumber || !name || !phone) {
            wx.showToast({
              icon:"none",
              title: '请补全信息',
            })
            return false
        }
        const checkPhone = this.checkTelephone(phone)
        if (!checkPhone) {
            wx.showToast({
                icon:"none",
                title: '请输入正确手机号',
              })
              return false
        }
        let address = wx.getStorageSync('address');
                if (!isEdit && defalutAddress && address) {
                    for (let i = 0; i < address.length; i++) {
                        if (address[i].defalutAddress) {
                            wx.showToast({
                                icon: 'none',
                                title: '已存在默认地址!',
                            })
                            return;
                        }
                    }
        }
        const form = {
            building,
            houseNumber,
            name,
            phone,
            defalutAddress,
        };
        if (!address) {
            address = [form];
        } else {
            if (editNow) {
                address[Number(index)] = form;
            } else {
                address.push(form);
            }
        }
        wx.setStorageSync('address', address);
        wx.navigateBack({
            delta: 1
        })
    },
  
    handleChangeSwitch(e) {
        this.setData({
            defalutAddress: e.detail.value
        })
    },
  
    getPhone(e) {
        this.setData({
            phone: e.detail.value
        })
    },
  
    getName(e) {
        this.setData({
            name: e.detail.value
        })
    },
  
    getHouseNumber(e) {
        this.setData({
            houseNumber: e.detail.value
        })
    },
  
    selectBuild() {

    },
  
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const {
            building, address, index
        } = options;
        if (address) {
            const { building: builds, houseNumber, name, phone, defalutAddress } = JSON.parse(address);
            if (defalutAddress) {
                this.setData({
                    isEdit: true
                })
            }
            this.setData({
                building: builds,
                houseNumber,
                name,
                phone,
                defalutAddress,
                index,
                editNow: true,
            })
        } else {
            this.setData({
                building,
            })
        }
    
    },
  
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
  
    }
  })
  