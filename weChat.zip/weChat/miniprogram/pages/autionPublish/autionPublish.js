
const app = getApp();
const http = app.http
const { data } = require("../../config.js");
const config = require("../../config.js");
const utils = require("../../utils/util.js")
const MAX_IMG_NUM = 8;
Page({
      data: {
            type:'add',
            endTimeTamp:0,
            checked: false,
            isExist: '',
            selectPhoto: true,
            systeminfo: app.systeminfo,
            params: {
                  imgUrl: new Array(),
            },
            userImgarr:[],
            tempFilePaths: [],
            endDate:"",
            endTime:"",
            easyTime:"",
            entime: {
                  enter: 600,
                  leave: 300
            }, //进入褪出动画时长
     
            college: JSON.parse(config.data).college.splice(0),
            colleges: [
                  {
                        name: '全新',
                        id: 0
                  },
                  {
                        name: '9成新',
                        id: 1
                  },
                  {
                        name: '8成新',
                        id: 2
                  },
                  {
                        name: '7成新',
                        id: 3
                  },
                  {
                        name: '6成新',
                        id: 4
                  },
            ],
            steps: [{
                  text: '步骤一',
                  desc: '补充物品信息'
            },
            {
                  text: '步骤二',
                  desc: '发布成功',
            },
            ],
            power:'',
            modelUrl:'',
            startPrice:0,
            stepPrice:1,
            guaranteePrice:1
      },
      //恢复初始态
      initial() {
            let that = this;
            that.setData({
                  dura: 30,
                  place: '',
                  nowDate:utils.formatTimeTwo(new Date().getTime(),"Y-M-D h:m:s"),
                  nowEndDate:utils.formatTimeTwo(new Date().getTime() + 2592000000,"Y-M-D h:m:s"),
                  nowStartTime:"00:00",
                  address:"",
                  chooseDelivery: 0,
                  cids: '-1', //类别选择的默认值
                  cidds: '-1',//新旧程度选择默认值
                  show_b: true,
                  show_c: false,
                  active: 0,
                  chooseCollege: false,
                  note_counts: 0,
                  desc_counts: 0,
                  notes: '',
                  describe: '',
                  good: '',
                  kindid: 0,
                  showorhide: true,
                  tempFilePaths: [],
                  params: {
                        imgUrl: new Array(),
                  },
                  imgUrl: [],
                  delivery: [{
                        name: '帮送',
                        id: 0,
                        check: true,
                  }, {
                        name: '自提',
                        id: 1,
                        check: false
                  }],
                  selectPhoto: true
            })
      },
      initialPower() {
        let that = this;
        that.setData({
              dura: 30,
              price: 1000,
              chooseDelivery: 1,
              cids: '1', //类别选择的默认值
              cidds: '2',//新旧程度选择默认值
              show_b: true,
              show_c: false,
              active: 0,
              chooseCollege: false,
              note_counts: 0,
              desc_counts: 0,
              notes: '快来拍卖吧',
              describe: '长焦标准相机,支持广角',
              good: '佳能相机',
              kindid: 0,
              showorhide: true,
              tempFilePaths: [],
              userImgarr:["https://taoan.top/file/image/1669200336917.webp"],
              params: {
                    imgUrl: new Array(),
              },
              modelUrl:"robot",
              imgUrl: [],
              delivery: [{
                    name: '帮送',
                    id: 0,
                    check: true,
              }, {
                    name: '自提',
                    id: 1,
                    check: false
              }],
              selectPhoto: true,
              endDate:"2023-03-05",
              endTime:"06:00",
              startPrice:1000,
              stepPrice:40,
              guaranteePrice:50,
              endTimeTamp:1669500000
        })
        if (this.data.type == "update") {
          console.log("da");
          that.initUpdate()
        }
  },
      onLoad(option) {
            this.initial();
            const address = wx.getStorageSync("addressNow")
            console.log(address);
            if(address){
                const {building,houseNumber,phone}  = address
                this.setData({address:`${building}-${houseNumber}`,phone})
            }
            this.getPower()
            if (option.id) {
              let id = option.id
              console.log(option.id);
              this.setData({
                type:"update",
                goodId:id
              })
              
            }
      },
      onShow() {
        const address = wx.getStorageSync("addressNow")
        console.log(address);
        if(address){
            const {building,houseNumber,phone}  = address
            this.setData({address:`${building}-${houseNumber}`,phone})
        }
      },
      //价格输入改变
      startPriceChange(e) {
            this.setData({
              startPrice:e.detail.value,
              guaranteePrice:e.detail.value < 100?1:Math.floor(e.detail.value/100)
            })

      },
      stepPriceChange(e) {
        if (e.detail.value < Math.floor(this.data.startPrice /100)) {
          wx.showToast({
            icon:"none",
            title: '加价幅度太低'
          })
        }
        this.setData({
          stepPrice:e.detail.value
        })
  },
      modelChange(e) {
        this.setData({
          modelUrl:e.detail.value
        })
      },
      //取货方式改变
      delChange(e) {
        let that = this;
        let delivery = that.data.delivery;
        let id = e.detail.value;
        for (let i = 0; i < delivery.length; i++) {
              delivery[i].check = false
        }
        delivery[id].check = true;
        if (id == 1) {
              that.setData({
                    delivery: delivery,
                    chooseDelivery: 1
              })
        } else {
              that.setData({
                    delivery: delivery,
                    chooseDelivery: 0
              })
          }
        },
      //地址输入
      selectAddress(e) {
            wx.setStorageSync('urlNow','publish')
            wx.navigateTo({
              url: '../address/address',
            })
      },
      //物品输入
      goodInput(e) {
            this.data.good = e.detail.value
      },
      //类别选择
      kindChange(e) {
            let that = this;
            let kind = that.data.kind;
            let id = e.detail.value;
            for (let i = 0; i < kind.length; i++) {
                  kind[i].check = false
            }
            kind[id].check = true;
            if (id == 1) {
                  that.setData({
                        kind: kind,
                        chooseCollege: true,
                        kindid: id
                  })
            } else {
                  that.setData({
                        kind: kind,
                        cids: '-1',
                        chooseCollege: false,
                        kindid: id
                  })
            }
      },
      //选择类别
      choCollege(e) {
            let that = this;
            that.setData({
                  cids: e.detail.value
            })
      },
      // 选择新旧程度
      choColleges(e) {
            let that = this;
            that.setData({
                  cidds: e.detail.value
            })
      },
      // 选择开始日期
      choDate(e){
        console.log(this.data.nowDate.substring(0,10));
        this.setData({
          endDate: e.detail.value,
         })
         if (e.detail.value==this.data.nowDate.substring(0,10)) {
          this.setData({
            nowStartTime:this.data.nowDate.substring(10,16)
           })
         }
         else{
          this.setData({
            nowStartTime:"00:00"
           })
         }
         
      },
      // 选择结束时间
      choTime(e){
        if (this.data.endDate === '') {
          wx.showToast({
            icon: 'none',
            title: '请先选择日期',
          })
        }
        if (this.data.endDate == this.data.nowDate.substring(0,10) &&  Number(e.detail.value.substring(0,2)) - Number(this.data.nowStartTime.substring(0,3)) <1) {
          wx.showToast({
            icon: 'none',
            title: '间隔时间过短',
          })
        }
        else{
          this.setData({
            endTime: e.detail.value
           })
        }
      },
      //输入备注
      noteInput(e) {
            let that = this;
            that.setData({
                  note_counts: e.detail.cursor,
                  notes: e.detail.value,
            })
      },
      //输入描述
      describeInput(e) {
            let that = this;
            that.setData({
                  desc_counts: e.detail.cursor,
                  describe: e.detail.value,
            })
      },
      getPower(){
        wx.request({
          url: `${http}/user/getPower`,
          data:{
            _id:wx.getStorageSync('openid')
          },
          success: (res) => {
            this.setData({
              power:res.data
            })
            if (res.data=="特权用户") {
              this.initialPower()
            }else{
              this.initUpdate()
            }
            
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
      //正式发布
      publish() {   //再次检验一次
            let that = this;
            // 鉴权
            if (that.data.good == '') {
                  wx.showToast({
                        title: '请输入商品名称',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.address == '') {
              wx.showToast({
                    title: '请输入地址名称',
                    icon: 'none',
              });
              return false;
           }
           if (this.data.stepPrice< Math.floor(this.data.startPrice /100)) {
            wx.showToast({
                  title: '加价幅度太低',
                  icon: 'none',
            });
            return false;
         }
            if (that.data.cidds == '-1') {
                  wx.showToast({
                        title: '请选择新旧程度',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.cids == '-1') {
                  wx.showToast({
                        title: '请选择类别',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.describe == '') {
                  wx.showToast({
                        title: '请输入商品的详细描述',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.userImgarr.length == 0) {
                  wx.showToast({
                        title: '请选择图片',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.notes == '') {
                  wx.showToast({
                        title: '请输入相关的备注信息（如取货时间）',
                        icon: 'none',
                  });
                  return false;
            }
            if (!that.data.endDate||!that.data.endTime||!that.data.startPrice||!that.data.stepPrice||!that.data.startPrice){
              wx.showToast({
                title: '请完整输入信息',
                icon: 'none',
          });
              return false
            }
            if(!wx.getStorageSync('userInfo')){
              wx.showModal({
                title: '您还未登录，请先登录',
                content: '是否跳转到我的页面',
                success: function (res) {
                  if (res.confirm) {//这里是点击了确定以后
                    wx.switchTab({
                      url: '/pages/my/my',
                     })
                  } else {//这里是点击了取消以后
                    wx.switchTab({
                      url: '/pages/idnex/index',
                     })
                  }
                }
              })
               return false; 
            }
            wx.showModal({
                  title: '温馨提示',
                  content: '经检测您填写的信息无误，是否马上发布？',
                  success(res) {
                  
                      let endTimeTamp = that.data.endDate+ " " + that.data.endTime
                      endTimeTamp =  utils.dateStrChangeTimeTamp(endTimeTamp)
                      that.setData({
                        endTimeTamp
                      })
                    
                          
                    if (res.confirm) {
                      let data= {
                        // 模块的名字
                        name: '商品闲置',
                        // 当前时间
                        time: new Date().getTime(),
                        // 订单金额
                        money:Number(that.data.startPrice),
                        // 订单状态
                        state: 0,
                        // 收件地址
                        address: that.data.address,
                        // 用户手机号
                        pulishPhone: that.data.phone,
                        publishID:wx.getStorageSync('openid'),
                        deliveryid: that.data.chooseDelivery, //0帮1自
                        // 订单信息
                       info: {
                          //  标题
                          title: that.data.good,
                          collegeid: that.data.cids,
                          thingsid: that.data.cidds,
                          // 备注
                          notes: that.data.notes,
                          detailInfo:{
                              // 商品的描述图片
                              pic:that.data.userImgarr,
                              // 商品的详细描述
                              good:that.data.good,
                              describe: that.data.describe                                    
                          },
                          status: 0, //0在售；1买家已付款，但卖家未发货；2买家确认收获，交易完成；3、交易作废，退还买家钱款
                        },
                        // 用户信息
                        userInfo:wx.getStorageSync('userInfo'),
                        modelUrl:that.data.modelUrl,
                        goodsType:"竞价拍卖",
                        auctionInfo:{
                          startPrice:that.data.startPrice,
                          stepPrice:that.data.stepPrice,
                          endDate:that.data.endDate,
                          endTime:that.data.endTime,
                          guarantee:Number(that.data.guaranteePrice),
                          priceList:[],
                          endTimeTamp:that.data.endTimeTamp,
                          easyTime:that.data.endDate.substring(5,11)+ "日 " +that.data.endTime.substring(0,2) + "时"                           
                        }
                      }
                      console.log(that.data.type);
                      if (that.data.type =="add") {
                            wx.request({
                                url: `${http}/addOrder`,
                                data:data,
                                method:"post",
                                success: (res) => {
                                    console.log(res);
                                  if(res.data === 'success'){
                                    wx.redirectTo({
                                      url: '../seller/seller?name=' + "auction"  
                                   })
                                    wx.showToast({
                                      title: '发布成功',
                                    })
                                  }else{
                                    wx.showToast({
                                      title: '发布失败',
                                    })
                                  }
                          
                                }
                              })
                        }
                        else{
                          let data1= {
                            id:that.data.goodId,
                            ...data
                          }
                          wx.request({
                          
                            url: `${http}/updateAuctionOrder`,
                            data:data1,
                            method:"post",
                            success: (res) => {
                                console.log(res);
                              if(res.data === 'success'){
                                wx.redirectTo({
                                  url: '../seller/seller?name=' + "auction"  
                               })
                                wx.showToast({
                                  title: '发布成功',
                                })
                              }else{
                                wx.showToast({
                                  title: '发布失败',
                                })
                              }
                      
                            }
                          })
                        }
                      }
                  }
            })
      },
      chooseImage: function () {
            const that = this;
            // 还能再选几张图片,初始值设置最大的数量-当前的图片的长度
            let max = MAX_IMG_NUM - this.data.tempFilePaths.length;
            // 选择图片
            wx.chooseImage({
                  count: max, // count表示最多可以选择的图片张数
                  sizeType: ['compressed'],
                  sourceType: ['album', 'camera'],
                  success: (res) => {
                        const tempFiles = res.tempFiles;
                        const filePath = res.tempFilePaths;
                        //将选择的图片上传
                        const random = Math.floor(Math.random() * 1000);
                        const {userImgarr} = this.data 
                        filePath.forEach((path) => {
                            setTimeout(() =>  wx.uploadFile({
                                url: `${http}/uploadImg`, 
                                filePath: path,
                                name: 'file',
                                success (res){
                                  let  {path} = JSON.parse(res.data)[0]
                                  path = path.replace(/\\/g,"/")
                                  let  filePath= `${http}/${path}`
                                  userImgarr.push(filePath)
                                  console.log(userImgarr);
                                  that.setData({
                                    userImgarr: userImgarr
                                }, () => {
                                      console.log(that.data.tempFilePaths)
                                })
                                  wx.hideLoading()
                                }
                              }), random); //加不同的延迟，避免多图上传时文件名相同
                      });
                        // const {
                        //       tempFilePaths
                        // } = that.data;
 
                        // 还能再选几张图片
                        max = MAX_IMG_NUM - this.data.tempFilePaths.length
                        this.setData({
                              selectPhoto: max <= 0 ? false : true // 当超过8张时,加号隐藏
                        })
                  },
                  fail: e => {
                        console.error(e)
                  }
            })
      },
      // 删除当前图片
      deletePic(e) {
            let index = e.currentTarget.dataset.index
            let imgUrl = this.data.params.imgUrl
            const {
                userImgarr
            } = this.data;
            userImgarr.splice(index, 1);
            imgUrl.splice(index, 1)
            this.setData({
                  ['params.imgUrl']: imgUrl,
                  userImgarr,
            })
            // 当添加的图片达到设置最大的数量时,添加按钮隐藏,不让新添加图片
            if (this.data.tempFilePaths.length == MAX_IMG_NUM - 1) {
                  this.setData({
                        selectPhoto: true,
                  })
            }
      },
      detail() {
            let that = this;
            wx.navigateTo({
                  url: '/pages/detail/detail?scene=' + that.data.detail_id,
            })
      },
      initUpdate(){
        let that = this
        wx.request({
          url: `${http}/getDetailGood/IdSelect`,
          data:{
            id:this.data.goodId
          },
          success: (res) => {
            console.log(res);
           
            const {
              data
            } = res;     
            console.log(data); 
            that.setData({
                  dura: 30,
                  price: data.money,
                  chooseDelivery: 1,
                  cids: data.info.collegeid, //类别选择的默认值
                  cidds: data.info.thingsid,//新旧程度选择默认值
                  show_b: true,
                  show_c: false,
                  active: 0,
                  chooseCollege: false,
                  note_counts: 0,
                  desc_counts: 0,
                  notes: data.info.notes,
                  describe: data.info.detailInfo.describe,
                  good: data.info.title,
                  kindid: 0,
                  showorhide: true,
                  tempFilePaths: [],
                  userImgarr:data.info.detailInfo.pic,
                  params: {
                        imgUrl: new Array(),
                  },
                  imgUrl: [],
                  delivery: [{
                        name: '帮送',
                        id: 0,
                        check: !data.deliveryid,
                  }, {
                        name: '自提',
                        id: 1,
                        check: !!data.deliveryid
                  }],
                  selectPhoto: true,
                  endDate:data.auctionInfo.endDate,
                  endTime:data.auctionInfo.endTime,
                  startPrice:data.auctionInfo.startPrice,
                  stepPrice:data.auctionInfo.stepPrice,
                  guaranteePrice:data.auctionInfo.guarantee,
                  endTimeTamp:data.auctionInfo.endTimeTamp
            })
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
          }
        })
      },
})