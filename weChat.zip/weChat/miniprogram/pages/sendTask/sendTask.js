
const app = getApp();
const http = app.http
const config = require("../../config.js");
const MAX_IMG_NUM = 8;
Page({
      data: {
            //   页面类型      
            goodId:"",
            type:"add",
            checked: false,
            isExist: '',
            selectPhoto: true,
            systeminfo: app.systeminfo,
            params: {
                  imgUrl: new Array(),
            },
            businessArray: [{name:'韵达快递'}, {name:'圆通快递'}, {name:'中通快递'}, {name:'申通快递'},{name:'百世快递'}, {name:'顺丰快递'}],
            baseMoney:3,
            addMoney:0,
            money:3,
            userImgarr:[],
            tempFilePaths: [],
            entime: {
                  enter: 600,
                  leave: 300
            }, //进入褪出动画时长
            college: JSON.parse(config.data).college.splice(0),
            chooseDelivery:0,
            typeList: [{
                name: '小件',
                tips: '小件: 手机巴掌大小的快件, 价格3元',
                money: 3,
              },
              {
                name: '中件',
                tips: '中件: 鞋服盒子大小的快件, 价格5元',
                money: 5,
              },
              {
                name: '大件',
                tips: '大件: 重量超过5公斤的快件, 价格8元',
                money: 8,
              }
            ],
            power:'',
            modelUrl:'',
            price:3,
            code:""
      },
      //恢复初始态
      initial() {
            let that = this;
            that.setData({
                  dura: 30,
                  price: 3,
                  place: '',
                  address:"",
                  chooseDelivery: 0,
                  cids: '-1', //快递大小的默认值
                  cidds: '-1',//快递商家选择默认值
                  show_b: true,
                  show_c: false,
                  active: 0,
                  chooseCollege: false,
                  note_counts: 0,
                  desc_counts: 0,
                  notes: '',
                  describe: '',
                  good: '',
                  kindid: 0,
                  showorhide: true,
                  tempFilePaths: [],
                  params: {
                        imgUrl: new Array(),
                  },
                  imgUrl: [],
                  delivery: [{
                        name: '帮送',
                        id: 0,
                        check: true,
                  }, {
                        name: '自提',
                        id: 1,
                        check: false
                  }],
                  selectPhoto: true
            })
      },
      onLoad(option) {
            this.initial();
            const address = wx.getStorageSync("addressNow")
            console.log(address);
            if(address){
                const {building,houseNumber,phone}  = address
                this.setData({address:`${building}-${houseNumber}`,phone})
            }
            this.getPower()
            if (option.id) {
              let id = option.id
              console.log(option.id);
              this.setData({
                type:"update",
                goodId:id
              })
              this.initUpdate()
              
            }
      },
      initUpdate(){
        let that = this
        wx.request({
          url: `${http}/getDetailGood/IdSelect`,
          data:{
            id:this.data.goodId
          },
          success: (res) => {
            console.log(res);
           
            const {
              data
            } = res;     
            console.log(data); 
            that.setData({
                  dura: 30,
                  price: data.money,
                  chooseDelivery: 1,
                  cids: data.info.collegeid, //快递大小的默认值
                  cidds: data.info.thingsid,//快递商家选择默认值
                  show_b: true,
                  show_c: false,
                  active: 0,
                  chooseCollege: false,
                  note_counts: 0,
                  desc_counts: 0,
                  notes: data.info.notes,
                  describe: data.info.detailInfo.describe,
                  good: data.info.title,
                  kindid: 0,
                  showorhide: true,
                  tempFilePaths: [],
                  userImgarr:data.info.detailInfo.pic,
                  params: {
                        imgUrl: new Array(),
                  },
                  imgUrl: [],
                  delivery: [{
                        name: '帮送',
                        id: 0,
                        check: !data.deliveryid,
                  }, {
                        name: '自提',
                        id: 1,
                        check: !!data.deliveryid
                  }],
                  selectPhoto: true,
                  code:data.auctionInfo.code,
                  addMoney:data.auctionInfo.addMoney,
                  baseMoney:data.money - data.auctionInfo.addMoney
            })
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
          }
        })
      },
      onShow() {
        const address = wx.getStorageSync("addressNow")
        console.log(address);
        if(address){
            const {building,houseNumber,phone}  = address
            this.setData({address:`${building}-${houseNumber}`,phone})
        }
      },
      //价格输入改变
      priceChange(e) {
            let price;
            let addMoney;
            addMoney = Number(e.detail.value)
            price = addMoney + this.data.baseMoney  
            this.setData({
              price,
              addMoney
            })
      },
      codeChange(e) {
        let code = e.detail.value
        this.setData({
            code
        })
  },
      modelChange(e) {
        this.setData({
          modelUrl:e.detail.value
        })
      },
      //取货方式改变
      delChange(e) {
        let that = this;
        let delivery = that.data.delivery;
        let id = e.detail.value;
        for (let i = 0; i < delivery.length; i++) {
              delivery[i].check = false
        }
        delivery[id].check = true;
        if (id == 1) {
              that.setData({
                    delivery: delivery,
                    chooseDelivery: 1
              })
        } else {
              that.setData({
                    delivery: delivery,
                    chooseDelivery: 0
              })
          }
        },
      //地址输入
      selectAddress(e) {
            wx.setStorageSync('urlNow','publish')
            wx.navigateTo({
              url: '../address/address',
            })
      },
      //物品输入
      goodInput(e) {
            this.data.good = e.detail.value
      },
      //快递大小
      kindChange(e) {
            let that = this;
            let kind = that.data.kind;
            let id = e.detail.value;
            for (let i = 0; i < kind.length; i++) {
                  kind[i].check = false
            }
            kind[id].check = true;
            if (id == 1) {
                  that.setData({
                        kind: kind,
                        chooseCollege: true,
                        kindid: id
                  })
            } else {
                  that.setData({
                        kind: kind,
                        cids: '-1',
                        chooseCollege: false,
                        kindid: id
                  })
            }
      },
      //选择类别
      choCollege(e) {
            let that = this;
            let cids = e.detail.value
            let baseMoney = this.data.typeList[cids].money
            let price
            let tip = this.data.typeList[cids].tips
            price = baseMoney + this.data.addMoney
            that.setData({
                  cids,
                  baseMoney,
                  price,
            })
            wx.showToast({
                icon: 'none',
                title: tip,
              })
      },
      // 选择快递商家
      choColleges(e) {
            let that = this;
            that.setData({
                  cidds: e.detail.value
            })
      },
      //输入备注
      noteInput(e) {
            let that = this;
            that.setData({
                  note_counts: e.detail.cursor,
                  notes: e.detail.value,
            })
      },
      //输入描述
      describeInput(e) {
            let that = this;
            that.setData({
                  desc_counts: e.detail.cursor,
                  describe: e.detail.value,
            })
      },
      getPower(){
        wx.request({
          url: `${http}/user/getPower`,
          data:{
            _id:wx.getStorageSync('openid')
          },
          success: (res) => {
            this.setData({
              power:res.data
            })
            if (res.data=="特权用户") {
            //   this.initialPower()
            }else{
              this.initUpdate()
            }
       
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
      //正式发布
      publish() {   //再次检验一次
            let that = this;
            // 鉴权
            if (that.data.good == '') {
                  wx.showToast({
                        title: '请输入商品名称',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.address == '') {
              wx.showToast({
                    title: '请输入地址名称',
                    icon: 'none',
              });
              return false;
           }
            if (that.data.cidds == '-1') {
                  wx.showToast({
                        title: '请选择快递商家',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.cids == '-1') {
                  wx.showToast({
                        title: '请选择快递大小',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.describe == '') {
                  wx.showToast({
                        title: '请输入商品的详细描述',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.userImgarr.length == 0) {
                  wx.showToast({
                        title: '请选择图片',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.notes == '') {
                  wx.showToast({
                        title: '请输入相关的备注信息（如取货注意事项）',
                        icon: 'none',
                  });
                  return false;
            }
            if(!wx.getStorageSync('userInfo')){
              wx.showModal({
                title: '您还未登录，请先登录',
                content: '是否跳转到我的页面',
                success: function (res) {
                  if (res.confirm) {//这里是点击了确定以后
                    wx.switchTab({
                      url: '/pages/my/my',
                     })
                  } else {//这里是点击了取消以后
                    wx.switchTab({
                      url: '/pages/idnex/index',
                     })
                  }
                }
              })
               return false; 
            }
            wx.showModal({
                  title: '温馨提示',
                  content: '经检测您填写的信息无误，是否马上发布？',
                  success(res) {

                   let  auctionInfo = {
                        deliveryType:that.data.businessArray[Number(that.data.cidds)],
                        deliveryWeight:that.data.typeList[Number(that.data.cids)].name,
                       addMoney:that.data.addMoney,
                       deliveryWeightId:Number(that.data.cids),
                       code:that.data.code     
                    }
                    console.log(that.data);
                    console.log(auctionInfo);
                        if (res.confirm) {
                          if (that.data.type =="add") {
                            wx.request({
                              url: `${http}/addOrder`,
                              data: {
                                // 模块的名字
                                name: '发布任务',
                                // 当前时间
                                time: new Date().getTime(),
                                // 订单金额
                                money: that.data.price,
                                // 订单状态
                                state: 0,
                                // 收件地址
                                address: that.data.address,
                                // 用户手机号
                                pulishPhone: that.data.phone,
                                publishID:wx.getStorageSync('openid'),
                                deliveryid: that.data.chooseDelivery, //0帮1自
                                // 订单信息
                               info: {
                                  //  标题
                                  title: that.data.good,
                                  collegeid: that.data.cids,
                                  thingsid: that.data.cidds,
                                  // 备注
                                  notes: that.data.notes,
                                  detailInfo:{
                                      // 商品的描述图片
                                      pic:that.data.userImgarr,
                                      // 商品的详细描述
                                      good:that.data.good,
                                      describe: that.data.describe                                    
                                  },
                          
                                  status: 0, //0在售；1买家已付款，但卖家未发货；2买家确认收获，交易完成；3、交易作废，退还买家钱款
                                },
                                auctionInfo:auctionInfo,
                                // 用户信息
                                userInfo:wx.getStorageSync('userInfo'),
                                modelUrl:that.data.modelUrl,
                                goodsType:"快递代拿",
                                
                              },
                              method:"post",
                              success: (res) => {
                                  console.log(res);
                                if(res.data === 'success'){
                                  wx.switchTab({
                                    url: '../index/index',
                                  })
                                  wx.showToast({
                                    title: '发布成功',
                                  })
                                }else{
                                  wx.showToast({
                                    title: '发布失败',
                                  })
                                }
                        
                              }
                            })
                          }else{
                            wx.request({
                              url: `${http}/updateOrder`,
                              data: {
                                // 模块的名字
                                id:that.data.goodId,
                                name: '发布任务',
                                // 当前时间
                                time: new Date().getTime(),
                                // 订单金额
                                money: that.data.price,
                                // 订单状态
                                state: 0,
                                // 收件地址
                                address: that.data.address,
                                // 用户手机号
                                pulishPhone: that.data.phone,
                                publishID:wx.getStorageSync('openid'),
                                deliveryid: that.data.chooseDelivery, //0帮1自
                                // 订单信息
                               info: {
                                  //  标题
                                  title: that.data.good,
                                  collegeid: that.data.cids,
                                  thingsid: that.data.cidds,
                                  // 备注
                                  notes: that.data.notes,
                                  detailInfo:{
                                      // 商品的描述图片
                                      pic:that.data.userImgarr,
                                      // 商品的详细描述
                                      good:that.data.good,
                                      describe: that.data.describe                                    
                                  },
                                  status: 0, //0在售；1买家已付款，但卖家未发货；2买家确认收获，交易完成；3、交易作废，退还买家钱款
                                },
                                // 用户信息
                                auctionInfo:auctionInfo,
                                userInfo:wx.getStorageSync('userInfo'),
                                modelUrl:that.data.modelUrl,
                                goodsType:"快递代拿",
                              },
                              method:"post",
                              success: (res) => {
                                  console.log(res);
                                if(res.data === 'success'){
                                  wx.switchTab({
                                    url: '../index/index',
                                  })
                                  wx.showToast({
                                    title: '修改成功',
                                  })
                                }else{
                                  wx.showToast({
                                    title: '发布失败',
                                  })
                                }
                        
                              }
                            })
                        }
                           
                        }
                  }
            })
      },
      chooseImage: function () {
            const that = this;
            // 还能再选几张图片,初始值设置最大的数量-当前的图片的长度
            let max = MAX_IMG_NUM - this.data.tempFilePaths.length;
            // 选择图片
            wx.chooseImage({
                  count: max, // count表示最多可以选择的图片张数
                  sizeType: ['compressed'],
                  sourceType: ['album', 'camera'],
                  success: (res) => {
                        const tempFiles = res.tempFiles;
                        const filePath = res.tempFilePaths;
                        //将选择的图片上传
                        const random = Math.floor(Math.random() * 1000);
                        const {userImgarr} = this.data 
                        filePath.forEach((path) => {
                            setTimeout(() =>  wx.uploadFile({
                                url: `${http}/uploadImg`, 
                                filePath: path,
                                name: 'file',
                                success (res){
                                  let  {path} = JSON.parse(res.data)[0]
                                  path = path.replace(/\\/g,"/")
                                  let  filePath= `${http}/${path}`
                                  userImgarr.push(filePath)
                                  console.log(userImgarr);
                                  that.setData({
                                    userImgarr: userImgarr
                                }, () => {
                                      console.log(that.data.tempFilePaths)
                                })
                                  wx.hideLoading()
                                }
                              }), random); //加不同的延迟，避免多图上传时文件名相同
                      });
                        // const {
                        //       tempFilePaths
                        // } = that.data;
 
                        // 还能再选几张图片
                        max = MAX_IMG_NUM - this.data.tempFilePaths.length
                        this.setData({
                              selectPhoto: max <= 0 ? false : true // 当超过8张时,加号隐藏
                        })
                  },
                  fail: e => {
                        console.error(e)
                  }
            })
      },
      // 删除当前图片
      deletePic(e) {
            let index = e.currentTarget.dataset.index
            let imgUrl = this.data.params.imgUrl
            const {
                userImgarr
            } = this.data;
            userImgarr.splice(index, 1);
            imgUrl.splice(index, 1)
            this.setData({
                  ['params.imgUrl']: imgUrl,
                  userImgarr,
            })
            // 当添加的图片达到设置最大的数量时,添加按钮隐藏,不让新添加图片
            if (this.data.tempFilePaths.length == MAX_IMG_NUM - 1) {
                  this.setData({
                        selectPhoto: true,
                  })
            }
      },
      detail() {
            let that = this;
            wx.navigateTo({
                  url: '/pages/detail/detail?scene=' + that.data.detail_id,
            })
      },
//  授权事件
onChange() {
  wx.requestSubscribeMessage({
    tmplIds: ['h3PjfUYf-wE6tSvgTBRUc7w6gCEo4JU4RsbyjvhWKV0'], //这里填入我们生成的模板id
    success(res) {
      console.log('授权成功', res)
    },
    fail(res) {
      console.log('授权失败', res)
    }
  })
},
onChange(event) {
  if (event.detail == true) {
        wx.requestSubscribeMessage({
              tmplIds: ['h3PjfUYf-wE6tSvgTBRUc7w6gCEo4JU4RsbyjvhWKV0'],
              success(res) {
                    console.log('授权成功', res)
              },
              fail(res) {
                    console.log('授权失败', res)
              }
        })
  }
  this.setData({
        checked: event.detail,
  });
},
      // onChange(event) {
      //       if (event.detail == true) {
      //             wx.requestSubscribeMessage({
      //                   tmplIds: ['uyP7eP6BF3n_pP4ZUU7PLkm7AQ22seeqdaUPSA4nSFg', 'NtMxfprcAtf_YlTKIixSzMR1b1vn-iLjABKKCkDXuXE'], //这里填入我们生成的模板id
      //                   success(res) {
      //                         console.log('授权成功', res)
      //                   },
      //                   fail(res) {
      //                         console.log('授权失败', res)
      //                   }
      //             })
      //       }
      //       this.setData({
      //             checked: event.detail,
      //       });
      // },
      // //获取授权的点击事件
      // shouquan() {
      //       wx.requestSubscribeMessage({
      //             tmplIds: ['uyP7eP6BF3n_pP4ZUU7PLkm7AQ22seeqdaUPSA4nSFg', 'NtMxfprcAtf_YlTKIixSzMR1b1vn-iLjABKKCkDXuXE'], //这里填入我们生成的模板id
      //             success(res) {
      //                   console.log('授权成功', res)
      //             },
      //             fail(res) {
      //                   console.log('授权失败', res)
      //             }
      //       })
      // },
})