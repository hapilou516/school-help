// pages/seller/seller.js
const app = getApp()
const config = require("../../config.js");
const http = app.http
Page({

    /**
     * 页面的初始数据
     */
    data: {
      inputValue:"",
      pageName:'',
      collection: [
            {
                text:"筛选商品",
                value: -1
            },
            {
                  text: '学习',
                  value: 0
            },
            {
                  text: '数码',
                  value: 1
            },
            {
                  text: '装饰品',
                  value: 2
            },
            {
                  text: '衣物',
                  value: 3
            },
            {
                  text: '运动器材',
                  value: 4
            },
            {
                  text: '化妆品',
                  value: 5
            },
            {
                  text: '交通工具',
                  value: 6
            },
            {
              text: '其他',
              value: 7
            },
      ],
      collectionDeliverValue:-1,
      collectionDeliverW: [
        {
            text:"筛选大小",
            value: -1
        },
        {
              text: '小件',
              value: 0
        },
        {
              text: '中件',
              value: 1
        },
        {
              text: '大件',
              value: 2
        },
    ],
    collectionDeliverTValue:-1,
    collectionDeliverT: [
        {
            text:"筛选快递",
            value: -1
        },
        {
              text: '韵达快递',
              value: 0
        },
        {
              text: '圆通快递',
              value: 1
        },
        {
              text: '中通快递',
              value: 2
        },
        {
              text: '申通快递',
              value: 3
        },
        {
              text: '百世快递',
              value: 4
        },
        {
              text: '顺丰快递',
              value: 5
        },
  ],
      businessArray: [{name:'韵达快递'}, {name:'圆通快递'}, {name:'中通快递'}, {name:'申通快递'},{name:'百世快递'}, {name:'顺丰快递'}],
      typeList: [{
        name: '小件',
        tips: '小件: 手机巴掌大小的快件, 价格3元',
        money: 3,
      },
      {
        name: '中件',
        tips: '中件: 鞋服盒子大小的快件, 价格5元',
        money: 5,
      },
      {
        name: '大件',
        tips: '大件: 重量超过5公斤的快件, 价格8元',
        money: 8,
      }
    ],
      collections: [
        {
            text:"筛选新旧",
            value:-1
        },
        {
              text: '全新',
              value: 0
        },
        {
              text: '9成新',
              value: 1
        },
        {
              text: '8成新',
              value: 2
        },
        {
              text: '7成新',
              value: 3
        },
        {
              text: '6成新',
              value: 4
        },

  ],
    collectionValue: -1,
    collectionsValue: -1,
    collectionId:-1,
    collectionsId:-1,
    pageNameTitle:"闲置服务",
    scrollTop: -1,
    minscreenHeight: 0,
    auctionButtons: [
      {
            label: '订单',
            icon: '../../img/fabButtom/order.png',
            hideShadow: true,
            className:"fabColor"
      },
      {
            label: '拍卖',
            icon: '../../img/fabButtom/rent.png',
            hideShadow: true
      },
     ],
    sellerButtons: [
      {
            label: '订单',
            icon: '../../img/fabButtom/order.png',
            hideShadow: true,
            className:"fabColor"
      },
      {
            label: '闲置',
            icon: '../../img/fabButtom/rent.png',
            hideShadow: true
      },
    ],
    deliverButtons: [
      {
        label: '我的任务',
        icon: '../../img/fabButtom/order.png',
        hideShadow: true,
    },
        {
          label: '发代拿',
          icon: '../../img/fabButtom/sendTask.png',
          hideShadow: true,
    }
    ],
    taskButtons: [
        {
          label: '我的任务',
          icon: '../../img/fabButtom/order.png',
          hideShadow: true,
      },
          {
            label: '发任务',
            icon: '../../img/fabButtom/sendTask.png',
            hideShadow: true,
      }
      ],
    },
    onClickDeliver(e) {
      switch (e.detail.index) {
            case 0:
                  wx.navigateTo({
                        url: '../myTask/myTask',
                  })
                  break;
            case 1:
              this.getPower()         
                  break;
              case 2:
                  wx.showToast({
                      title: '后续完善',
                      icon:"none"
                  })
                  break;
      }
},
    onClickAuction(e) {
          switch (e.detail.index) {
                case 0:
                      wx.navigateTo({
                            url: '../myBuy/myBuy',
                      })
                      break;
                case 1:
                  this.getPower()         
                      break;
                  case 2:
                      wx.showToast({
                          title: '后续完善',
                          icon:"none"
                      })
                      break;
          }
    },
    onClickSeller(e) {
          switch (e.detail.index) {
            case 0:
              wx.navigateTo({
                    url: '../myBuy/myBuy',
              })
              break;
        case 1:
          this.getPower()        
          }
    },
    getPower(){
        let that = this
        wx.request({
          url: `${http}/user/getPower`,
          data:{
            _id:wx.getStorageSync('openid')
          },
          success: (res) => {
            console.log(that.data.pageName);
            console.log(res.data);
            if (res.data =="封禁用户") {
              wx.showToast({
                icon: 'none',
                title: '你的账号已被封禁，不能发布商品',
              })
            }
            else{
              if (that.data.pageName == "auction") {
                wx.navigateTo({
                  url: '../autionPublish/autionPublish',
                })
              }
              else if(that.data.pageName == "seller") {
                wx.navigateTo({
                  url: '../publish/publish',
                 })
              }
              else if(that.data.pageName== "deliver") {
                wx.navigateTo({
                  url: '../sendTask/sendTask',
                 })
              }
              else if(that.data.pageName== "task") {
                wx.navigateTo({
                  url: '../sendTotalTask/sendTotalTask',
                 })
              }
            }
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
      },
    // 当分类改变时
    changeSelectcollection(value){
       this.setData({
           collectionId:value.detail
       })
       this.updateColleageAndOld(this.data.collectionId,this.data.collectionsId)
    },
    // 当新旧程度改变时
    changeSelectcollectionsValue(value){
        this.setData({
            collectionsId:value.detail
        })
        this.updateColleageAndOld(this.data.collectionId,this.data.collectionsId)
    },
    toTop() {
      wx.pageScrollTo({
            scrollTop: -1,
            duration: 300
      })
    },
    onPageScroll(e) { // 获取滚动条当前位置
      this.setData({
            scrollTop: e.scrollTop
      })
},
onLaunch() {
      this.getHeight(1)
},

    // 根据商品分类查询商品信息
    updateColleageAndOld(collectionId,collectionsId){
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/getSellerAllOrder/collectionAndOld`,
        data:{
            collectionId,
            collectionsId,
        },
        success: (res) => {
          console.log(res);
          const {
            data
          } = res;
          // 商品卡片进行解构
          this.setData({
            orderList: data,
            openid: wx.getStorageSync('openid')
          })
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
    },
    goback(){
        wx.navigateBack({
          delta: 1,
        })
    },
    getAlllist(){
        wx.showLoading({
            title: '加载中',
          })
          wx.request({
            url: `${http}/getSellerAllOrder`,
            success: (res) => {
              console.log(res);
              const {
                data
              } = res;
              // 商品卡片进行解构
              this.setData({
                orderList: this.shuffle(data),
              })
              wx.hideLoading();
            },
            fail: (res) => {
              wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
              })
              wx.hideLoading();
            }
          })
    },
   // 实时监控搜索内容
    bindKeyInput (e) {
      this.setData({
        inputValue: e.detail.value
      })
    },
    // 模糊搜索相关商品
    confirmSearch(e){
      console.log(e.detail.value);
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/getSellerAllOrder/search`,
        data:{
          keyword:e.detail.value
        },
        success: (res) => {
          console.log(res);
          const {
            data
          } = res;
          // 商品卡片进行解构
          this.setData({
            orderList: data,
          })
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
    },
    detail(e){
      wx.navigateTo({
        url: '/pages/details/details?id=' + e.currentTarget.dataset.id,
      })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    // 打乱数组
    shuffle(arr) {
        let i = arr.length;
        while (i) {
            let j = Math.floor(Math.random() * i--);
            [arr[j], arr[i]] = [arr[i], arr[j]];
        }
        return arr;
    },
    onLoad(options) {
        if (options) {
          console.log(options.name);
          let pageNameTitle = ""
          let color = ""
          if (options.name=="auction") {
              pageNameTitle= "竞价拍卖"
              color = "#528ef3"
          }
           else if (options.name=="seller") {

            pageNameTitle= "闲置服务"
            color = "#528ef3"
          }
           else  if (options.name=="task") {

              pageNameTitle= "任务中心"
              color = "#a1e8ff"
          }
          else  if (options.name=="deliver") {

            pageNameTitle= "快递代拿"
            color = "#528ef3"
        }
        this.setData({
          pageNameTitle,
          pageName:options.name,
          fubColor:color
        })
        }
        // document.documentElement.style.setProperty('--themeColor', 'yellow')
        this.getAlllist()
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
      this.getAlllist()
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
      this.getAlllist()
      wx.stopPullDownRefresh({
        success: (res) => {},
      })
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})