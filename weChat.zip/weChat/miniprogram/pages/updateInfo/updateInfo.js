
// pages/updateInfo/updateInfo.js
const app = getApp()
const http = app.http
console.log(http);
Page({

    /**
     * 页面的初始数据
     */
    data: {
        userInfo: {},
        phone: '',
    },
  
    saveChange() {
        wx.setStorageSync('userInfo', this.data.userInfo);
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: `${http}/user/update`,
          method:"post",
          data:{
           openid:wx.getStorageSync('openid'),
           userInfo:this.data.userInfo,
           name:this.data.userInfo.nickName,
           userIDImg:this.data.userInfo.avatarUrl,
           time:new Date().getTime(),
           userID:wx.getStorageSync('openid')
          },
          success: (res) => {
            console.log(res);
            
            wx.hideLoading();
          },
          fail: (res) => {
            wx.showToast({
              icon: 'none',
              title: '服务器异常~~~',
            })
            wx.hideLoading();
          }
        })
        wx.showToast({
          title: '修改成功',
        })
        wx.switchTab({
          url: '../my/my',
        })
    },
  
    updateAddress() {
        wx.setStorageSync('urlNow', "updateInfo")
        wx.navigateTo({
          url: '../address/address',
        })
    },
  
    logout(e) {
        wx.removeStorageSync('userInfo')
        // this.onLoad()
   
          wx.request({
            url: `${http}/user/getPower`,
            data:{
              _id:wx.getStorageSync('openid')
            },
            success: (res) => {
              if (res.data =="特权用户") {
                wx.request({
                  url: `${http}/collection/delete`,
                  method:"post",
                  data:{
                    userID:wx.getStorageSync('openid'),
                  },
                  success: (res) => {
                  
                    console.log(res);
                    wx.hideLoading();
                  },
                  fail: (res) => {
                    wx.showToast({
                      icon: 'none',
                      title: '服务器异常~~~',
                    })
                    wx.hideLoading();
                  }
                })
              }
            },
            fail: (res) => {
              wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
              })
              wx.hideLoading();
            }
          })
          wx.navigateBack({
            delta: 1,
          })
        // wx.showLoading({
        //   title: '加载中',
        // })
        // wx.request({
        //   url: `${http}/user/remove`,
        //   data:{
        //     openid:wx.getStorageSync('openid')
        //   },
        //   success: (res) => {
        //     console.log(res);
            
        //     wx.hideLoading();
        //   },
        //   fail: (res) => {
        //     wx.showToast({
        //       icon: 'none',
        //       title: '服务器异常~~~',
        //     })
        //     wx.hideLoading();
        //   }
        // })
    },
  
    updateNickName(e) {
       let userInfo = this.data.userInfo;
       userInfo.nickName = e.detail.value;
       this.setData({
           userInfo,
       })
    },
    updateAvatar() {
        let that = this
        let userInfo = this.data.userInfo;
        wx.chooseImage({
          count: 1,
          sizeType: ['original', 'compressed'],
          sourceType: ['album', 'camera'],
          success: (res) => {
            wx.showLoading({
              title: '加载中',
            })
            console.log(res);
            const random = Math.floor(Math.random() * 1000);
            wx.uploadFile({
                url: `${http}/uploadImg`, 
                filePath:  res.tempFilePaths[0],
                name: `file`,
                formData:{
                    name:`${this.data.userInfo.nickName}-${random}`
                },
                success (res){
                  let  {path} = JSON.parse(res.data)[0]
                  path = path.replace(/\\/g,"/")
                  console.log(path);
                  userInfo.avatarUrl = `${http}/${path}`;
                  that.setData({
                        userInfo,
                    })
                  wx.setStorageSync('userInfo', userInfo)
                  wx.hideLoading()
                }
              })
          }
        })
    },
  
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const userInfo = wx.getStorageSync('userInfo');
        const phone = wx.getStorageSync('phone');
        this.setData({
            userInfo,
            phone,
        })
    },
  
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
  
    }
  })
  