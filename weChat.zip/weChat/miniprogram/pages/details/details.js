// pages/details/details.js
const app = getApp()
const {http} = app
Page({

  /**
   * 页面的初始数据
   */
  data: {
    colorArray:["black","#07c160","orange","pink","#ee0a24"],
    oldAndNew:["全新","9成新","8成新","7成新","6成新"],
    deliverTypeArray:["小计","中件","大件"],
    deliverColor:["pink","#07c160","orange"],
    typeId:0,
    thingsid:0,
    currentPicId:0,
    NoteShow:false,
    commitShow:false,
    isCollection:0,
    inputValue: null,
    timeArrange:false,
    openid:"",
    showModel:false,
    modelUrl:'',
    deliver:"帮送",
    auctionShow:false,
    inputAuctionValue:null,
    inter:null,
    firstLoad:true
  },
//   跳转ar界面

    toAr(){
        wx.navigateTo({
            url: './ar/ar?id=' + this.data.modelUrl,
    })
    },
  getUserInfo(){
    this.setData({
      userInfo:wx.getStorageSync('userInfo')
    })
  },
  swiperchange(e){
    console.log();
    this.setData({
      currentPicId:e.detail.current
    })
  },
  // 查看图片预览
  img() {
      console.log("hidadf");
      let arr = [];
      arr.push(this.data.GoodsInfo.info.detailInfo.pic);
      // var imgList = that.data.result.images_fileID;
      const {currentPicId} = this.data
      wx.previewImage({
            current: arr[0][currentPicId], // 当前显示图片的http链接
            urls: arr[0] // 需要预览的图片http链接列表
      })
  },
  talkInput: function (e) {
    var that= this;
   that.setData({
      talk: e.detail.value
    });
  }, 
  // 屏蔽手机号
   hide_tel(str,res) {
    const regex1 = /\d/
    const regex2 = /\d|[\u4e00-\u9fa5]|\w/
    const regex_tel = /13[0-9]|14[5|7]|15[0-9]|18[0-9]/
    const regex_sj = /[(?)wx]|[(?)weixin]|[(?)qq]|[\u5fae\u4fe1]/
    let str_all = [];
    let str_addr = [];
    let str_num = "";
    for (let i = 0; i < str.length; i++) {
      str_all.push(str.charAt(i))
      if (str.charAt(i).match(regex1)) {
        str_addr.push(i)
        str_num += str.charAt(i)
      }
    }
    // 判别电话号码
    if (str_num.match(regex_tel)) {
      if (str_addr.length > 7) {
        for (let i = 0; i < Math.ceil(str_addr.length / 2); i++) {
          let num = str_addr[Math.ceil(str_addr.length / 4) + i]
          str_all[num] = "*";
        }
      }
    } else {//判别社交帐号
      str_addr = [];
      str_num = "";
      for (let n = 0; n < str.length; n++) {
        if (str.charAt(n).match(regex2)) {
          str_addr.push(n)
          str_num += str.charAt(n)
        }
      }
      console.log(str_num);
      if (str_num.match(regex_sj)) {
        for (let i = 0; i < str_all.length; i++) {
          if (str_all[i].match(regex1)) {
            str_all[i] = "*"
          }
        }
        str = str_all.join('');
      } else {
        console.log("no get");
      }
    }
    str = str_all.join('')
    return str
  },
  upDateGoods(){
    wx.navigateTo({
      url: '/pages/publish/publish?id=' + this.data.id,
  })
  
},
upDateGoodsDeliver(){
    wx.navigateTo({
      url: '/pages/sendTask/sendTask?id=' + this.data.id,
  })
  
},
upDateGoodsTask(){
    wx.navigateTo({
      url: '/pages/sendTotalTask/sendTotalTask?id=' + this.data.id,
  })
  
},
// 竞价提交
submitAuctionValue: function (e) {
  const talk = Number(this.data.inputAuctionValue)
  const startPrice = this.data.GoodsInfo.auctionInfo.startPrice
  const stepPrice = this.data.GoodsInfo.auctionInfo.stepPrice
  const totalPrice = Number(startPrice)  + Number(stepPrice) 
  console.log(totalPrice);
  var that = this
  if (talk && talk >totalPrice) {  //talk不为空的时候
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/auction/add`,
      method:"POST",
      data:{
        _id:this.data.id,
        openid:wx.getStorageSync('openid'),
        name: this.data.userInfo.nickName,//获得用户名
        price:talk,//获得评论
        time:new Date().getTime(),//获得评论时间
        photo: this.data.userInfo.avatarUrl,//获得用户头像
        
      },
      success: (res) => {
        this.getdetails(this.data.id,this.data.timeArrange)
        this.setData({
          inputAuctionValue:this.data.price
        })
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          GoodsInfo: data,
          thingsid:data.info.thingsid,
          auctionShow:false
        })
        // this.reverse()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })

  }
  else {// talk为0，输入框未输入数据
    wx.showModal({
      title: '提示',
      content: '低于目前出价',
      showCancel: false,
      confirmText: '我知道了',
    })
  }
},

// 提交
  submit: function (e) {
    const row = this.data.talk
   const talk =  this.hide_tel(row)
    var that = this
    if (talk) {  //talk不为空的时候
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/comments/add`,
        method:"POST",
        data:{
          _id:this.data.id,
          openid:wx.getStorageSync('openid'),
          name: this.data.userInfo.nickName,//获得用户名
          content:talk,//获得评论
          time:new Date().getTime(),//获得评论时间
          photo: this.data.userInfo.avatarUrl,//获得用户头像

        },
        success: (res) => {
          this.setData({
            inputValue:""
          })
          this.getdetails(this.data.id,this.data.timeArrange)
      
          const {
            data
          } = res;
          // 商品卡片进行解构
          this.setData({
            GoodsInfo: data,
            thingsid:data.info.thingsid
          })
          // this.reverse()
          wx.hideLoading();
        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })
    }
    else {// talk为0，输入框未输入数据
      wx.showModal({
        title: '提示',
        content: '评论不能为空',
        showCancel: false,
        confirmText: '我知道了',
      })
    }
  },

  reverse(){
    let array = this.data.talks
    var temp;
    for(let i=0; i<array.length/2; i++){
      temp=array[i];
      array[i]=array[array.length-1-i];
      array[array.length-1-i]=temp;
    }
    this.setData({
      talks:array,
      timeArrange:!this.data.timeArrange
    })
  },
  checkCollection(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/collection/check`,
      data:{
        userID:wx.getStorageSync('openid'),
        GoodsID:this.data.id
      },
      success: (res) => {
        const {data} = res
        let state = false
        console.log(data);
        console.log("asdfs");
        if(data == "yes"){
          state = true
        }
        this.setData({
          isCollection:state
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  joinCollection(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/collection/join`,
      method:"post",
      data:{
        userID:wx.getStorageSync('openid'),
        GoodsInfo:this.data.GoodsInfo
      },
      success: (res) => {
        const {data} =res
        if(data== "success"){
          this.setData({
            isCollection:true
          })
        }
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  dropColection(){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/collection/drop`,
      method:"post",
      data:{
        userID:wx.getStorageSync('openid'),
        GoodsInfo:this.data.GoodsInfo
      },
      success: (res) => {
        const {data} =res
        if(data== "success"){
          this.setData({
            isCollection:false
          })
        }
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  gocart(){
    console.log("hi");
  },
  showNote(){
    this.setData({
      NoteShow:true
    })
  },
  onClose(){
    this.setData({
      NoteShow:false
    })
  },
  talkAuctionInput: function (e) {
    var that= this;
   that.setData({
       inputAuctionValue: e.detail.value
    });
  },
  showAuction(){
    if (this.data.GoodsInfo.publishID ==this.data.openid){
        wx.showToast({
          title: "无法对自己的商品出价",
          icon: 'none',
          duration: 2000,
        });
      }
      else{
        this.setData({
            auctionShow:true,
            inputAuctionValue:this.data.GoodsInfo.auctionInfo.startPrice,
          })
      }
  },
  onCloseAuction(){
    this.setData({
      auctionShow:false
    })
  },
  
  showCommit(){
    this.setData({
      commitShow:true
    })
  },
  onCloseCommitShow(){
    this.setData({
      commitShow:false
    })
  },
      // test
      // 聊天跳转
      goMessage(e) {
        
        if (!this.data.openid) {
              // this.selectComponent('#message').show()
        } else {
              var buyId = this.data.openid;
              var sallerId = this.data.GoodsInfo.publishID;
              if (sallerId!=this.data.openid) {
                wx.showLoading({
                  title: '加载中',
                })
                wx.request({
                  url: `${http}/room/check`,
                  data:{
                    buyId, sallerId 
                  },
                  success: (res) => {
                    console.log(res);
                    if (res.data.length > 0) {
                      this.setData({
                            roomID: res.data[0]._id
                      })
                      wx.request({
                        url: `${http}/room/updateDeleted`,
                        data:{
                          _id: res.data[0]._id
                        },
                        success:(response)=>{
                          wx.navigateTo({
                            url: 'room/room?id=' + this.data.roomID,
                      })
                        }
                      })
                      // db.collection("rooms").doc(res.data[0]._id).update({
                      //       data: {
                      //             deleted: 0
                      //       },
                      // }), //如没有记录，则新增聊天室，0代表买家，1代表卖家
                      //       wx.navigateTo({
                      //             url: 'room/room?id=' + this.data.roomID,
                      //       })
                } else {
                      wx.request({
                        url: `${http}/room/add`,
                        method:"post",
                        data:{
                          buyId,
                          sallerId,
                          deleted: 0
                        },
                        
                        success:(res)=>{
                          const {data} =res
                          this.setData({
                            roomID: res._id
                      })
                          wx.navigateTo({
                            url: 'room/room?id=' + data._id,
                      })
                      }                        
                    })
                    
                }
                    wx.hideLoading();
                  },
                  fail: (res) => {
                    wx.showToast({
                      icon: 'none',
                      title: '服务器异常~~~',
                    })
                    wx.hideLoading();
                  }
                })
              } else {
                    wx.showToast({
                          title: '无法和自己建立聊天',
                          icon: 'none',
                          duration: 1500
                    })
              }
        }
  },
  confirm(){
    let openId = wx.getStorageSync('openid')
    if(this.data.GoodsInfo.state != 0){
            wx.showToast({
              title: "抱歉,商品已被人抢先一步了",
              icon: 'none',
              duration: 3000,
              success(){
                setTimeout(function () {
                    //要延时执行的代码
                    wx.navigateBack({
                        delta: 1,
                      })  
                }, 2000) //延迟时间 
            }
            });
    }
    else if (this.data.GoodsInfo.publishID ==openId){
      wx.showToast({
        title: "无法购买自己的商品",
        icon: 'none',
        duration: 2000,
      });
    }
    else{
        wx.navigateTo({
            url: "./confirmOrder/confirmOrder?id=" + this.data.GoodsInfo._id
          })
    }
  },
  confirmDeliver(){
    let openId = wx.getStorageSync('openid')
    if(this.data.GoodsInfo.state != 0){
            wx.showToast({
              title: "抱歉,商品已被人抢先一步了",
              icon: 'none',
              duration: 3000,
              success(){
                setTimeout(function () {
                    //要延时执行的代码
                    wx.navigateBack({
                        delta: 1,
                      })  
                }, 2000) //延迟时间 
            }
            });
    }
    else if (this.data.GoodsInfo.publishID ==openId){
      wx.showToast({
        title: "无法购买自己的商品",
        icon: 'none',
        duration: 2000,
      });
    }
    else{
        wx.navigateTo({
            url: "./confirmOrder/confirmOrder?id=" + this.data.GoodsInfo._id
          })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  startInter : function(){
    var that = this;
   if(that.data.inter){
    that.clearInterval(that.data.inter)
   }
    that.data.inter= setInterval(
        function () {
            that.getdetails(that.data.id,that.data.timeArrang)
            console.log('setInterval 每过500毫秒执行一次任务')
        }, 1000);    
  },
  endInter: function(){
    var that = this;
    clearInterval(that.data.inter)
    that.setData({
      inter:null
    })
  },
  onLoad(options) {
    this.setData({
      id:options.id,
      openid:wx.getStorageSync('openid')
    })
    this.getdetails(options.id,this.data.timeArrange)
    this.getUserInfo()
    this.checkCollection()
    app.checkUserInfo()
    this.startInter()
  },
  getdetails(id,timeArrage){
    let that = this
    wx.request({
      url: `${http}/getDetailGood/IdSelect`,
      data:{
        id
      },
      success: (res) => {
        console.log(res);
        let timeArrage = that.data.timeArrange
        const {
          data
        } = res;
        console.log(timeArrage);
        if (timeArrage) {
          this.setData({
            talks:data.comments,
          })
        }
        else{
          this.setData({
            talks:data.comments.reverse(),
          })
        }
        // 商品卡片进行解构
        
        this.setData({
          GoodsInfo: data,
          thingsid:data.info.thingsid,
          typeId:data.info.collegeid,
          showModel:!!data.modelUrl,
          modelUrl:`${http}/file/model/` + data.modelUrl + '.glb',
          
        })
        if (this.data.GoodsInfo.goodsType=='竞价拍卖') {
          this.setData({
            AuctionTime:this.countTime(this.data.GoodsInfo.auctionInfo.endDate +" " +this.data.GoodsInfo.auctionInfo.endTime),
            actionList:data.auctionInfo.priceList.reverse()
          })
        //   if (wx.getStorageSync('openid') == 'oF8HP5bxDJQO8l3D8H_ip46S4QZg') {
        //     this.setData({
        //       AuctionTime:"2天3小时15分"
        //     })
        //   }
        }
        if (this.data.GoodsInfo.goodsType=='任务中心') {
            this.setData({
              AuctionTime:this.countTime(this.data.GoodsInfo.auctionInfo.endDate +" " +this.data.GoodsInfo.auctionInfo.endTime),
            //   actionList:data.auctionInfo.priceList.reverse()
            })
          //   if (wx.getStorageSync('openid') == 'oF8HP5bxDJQO8l3D8H_ip46S4QZg') {
          //     this.setData({
          //       AuctionTime:"2天3小时15分"
          //     })
          //   }
          }
        let deliver = "帮送"
        if (data.deliveryid == 1) {
            deliver = "自提"
        }
        this.setData({
            deliver
        })
        // this.reverse()
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  countTime(str){
    var date = new Date();

            var now = date.getTime();

            //设置截止时间

            var endDate = new Date(str);

            var end = endDate.getTime();

            //获取截止时间和当前时间的时间差

            var leftTime = end-now;

            //定义变量 d,h,m,s分别保存天数，小时，分钟，秒

            var d,h,m,s;

            //判断剩余天数，时，分，秒

            if (leftTime>=0) {

                d = Math.floor(leftTime/1000/60/60/24);

                h = Math.floor(leftTime/1000/60/60%24);

                m = Math.floor(leftTime/1000/60%60);

                s = Math.floor(leftTime/1000%60);                   

            }
            return d+"天"+h+"时"+m+"分"
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
    this.endInter()
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    this.endInter()
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})