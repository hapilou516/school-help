// pages/details/confirmOrder/confirmOrder.js
const {http} = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    GoodsInfo:{},
    cids:-1,
    ciddds:0,
    address:"",
    payAarry:["微信支付","支付宝支付","银联支付"],
    pay:[{name:"微信支付",id:0},{name:"支付宝支付",id:1},{name:"银联支付",id:2}]
  },
  chopay(e) {
    let that = this;
    console.log(e.detail.value);
    that.setData({
          cids: e.detail.value
    })
  },
  getUserInfo(){
    this.setData({
      userInfo:wx.getStorageSync('userInfo')
    })
  },
  selectAddress() {
    console.log("ad");
    wx.setStorageSync('urlNow','comfirmOrder')
    wx.navigateTo({
      url: '../../address/address',
    })
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      id:options.id
    })

    this.getdetails(options.id)
    this.getUserInfo()
    const address = wx.getStorageSync("addressNow")
    if(address){
      const {building,houseNumber,phone}  = address
      this.setData({address:`${building}-${houseNumber}`,phone})
      if (this.data.GoodsInfo.deliveryid == 1) {
        //   需要自提
        this.setData({address:this.data.address})
    }
  }
  },
  getdetails(id){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/getDetailGood/IdSelect`,
      data:{
        id
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        this.setData({
          GoodsInfo: data,
          thingsid:data.info.thingsid
        })
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
 comfimOrder(){
  const {id} = this.data
    this.checkOrder(id)

    // this.publishOrder(id,receivePerson)
  },
  
  checkOrder(id){
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/checkGood`,
      data:{
        id,
      },
      success: (res) => {
        console.log(res);
        const {data} =res
        const state = data.state
        wx.hideLoading();
        if(state != 0){
          wx.showToast({
            title: "抱歉,商品已被人抢先一步了",
            icon: 'none',
            duration: 3000
          });
          setTimeout(function(){
            wx.navigateTo({
                url: '../../seller/seller'
              })  
          },2000)
          // wx.hideLoading();
        } 
        else{
          const {id,address,phone} = this.data
          const receiveOpenId = wx.getStorageSync("openid")
          const receiveInfo  = wx.getStorageSync("userInfo")      
          const  buyTime = new Date().getTime()
          this.publishOrder(id,receiveOpenId,address,phone,receiveInfo,buyTime)
        }
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  publishOrder(id,receiveOpenId,address,phone,receiveInfo,buyTime){
    let that  =this
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: `${http}/buyGood`,
      method:"post",
      data:{
        id,
        receiveOpenId,
        address,
        phone,
        receiveInfo,
        buyTime
      },
      success: (res) => {
        console.log(res);
        that.getToken()
        wx.hideLoading();
        wx.showToast({
          title: "订购成功,即将跳转到我的页面",
          icon: 'none',
          duration: 1000
        });
        let url = ""
        if(that.data.GoodsInfo.goodsType== '快递代拿' ||that.data.GoodsInfo.goodsType == '任务中心')
          url= '../../myTask/myTask'       
        else{
          url=  '../../myBuy/myBuy'
              
        }
        setTimeout(function(){
          wx.setStorageSync('urlNow', "confirmOrder")
          wx.redirectTo({
            url: url
          })  
        },1500)
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  getToken(){
    wx.request({
      url: `${http}/token`,
      data:{
        openid:"",
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        let token  =data.access_token
        // 商品卡片进行解构
        this.setData({
          token:data.access_token
        })
        this.sendTemplateMsg(token)
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  sendTemplateMsg(token){
    let that = this
    console.log(token);
    wx.request({
      url: `${http}/token/sendTemplate`,
      data:{
        openid:that.data.GoodsInfo.publishID,
        name:that.data.userInfo.nickName,
        address:that.data.address,
        title:that.data.GoodsInfo.info.title,
        note:"亲,你上架的商品已被人预定,请及时发货",
        token:token
      },
      success: (res) => {
        console.log(res);
        const {
          data
        } = res;
        // 商品卡片进行解构
        wx.hideLoading();
      },
      fail: (res) => {
        wx.showToast({
          icon: 'none',
          title: '服务器异常~~~',
        })
        wx.hideLoading();
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    console.log("g");
    const address = wx.getStorageSync("addressNow")
    if(address){
      const {building,houseNumber,phone}  = address
      this.setData({address:`${building}-${houseNumber}`,phone})
   }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})