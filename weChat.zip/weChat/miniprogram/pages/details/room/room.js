const app = getApp()
const {http} = app
const db = wx.cloud.database();
Page({
  data: {
    avatarUrl: './user-unlogin.png',
    userInfo: null,
    logged: false,
    takeSession: false,
    requestResult: '',
    //chatRoomEnvId: 'release-f8415a',
    chatRoomCollection: 'chatroom',
    chatRoomGroupId: '',
    chatRoomGroupName: '聊天室',
    // functions for used in chatroom components
    onGetUserInfo: null,
    getOpenID: null,
    user: null,
  },
  onBack(){
    wx.navigateBack({
      delta: 0,
    })
},

  onLoad: function (opentions) {  //此处不建议修改，容易出错，下面类容都不建议修改，容易出错
    // 获取用户信息
   const  openid = wx.getStorageSync("openid")
   console.log(openid);
    wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: `${http}/user/find`,
        method:"get",
        data:{
            openid:openid
        },
        success: (res) => {
          console.log(res.data[0]);
          // 商品卡片进行解构
          this.setData({
            avatarUrl: res.data[0].userInfo.avatarUrl,
            userInfo: res.data[0].userInfo
          })
          wx.hideLoading();

        },
        fail: (res) => {
          wx.showToast({
            icon: 'none',
            title: '服务器异常~~~',
          })
          wx.hideLoading();
        }
      })

    this.setData({
      openid,
    //   onGetUserInfo: this.onGetUserInfo,
      getOpenID: this.getOpenID,
      chatRoomGroupId: opentions.id,
    })

    wx.getSystemInfo({
      success: res => {
        console.log('system info', res)
        if (res.safeArea) {
          const {
            top,
            bottom
          } = res.safeArea
          this.setData({
            containerStyle: `padding-top: ${(/ios/i.test(res.system) ? 10 : 20) + top}px; padding-bottom: ${20 + res.windowHeight - bottom}px`,
          })
        }
      },
    })
  },

  getOpenID: async function () {
    const openid = wx.getStorageSync('openid')
    console.log(openid);
    const that = this
    if(!openid){
        wx.login({
            success (res) {
              if (res.code) {
                //发起网络请求
                wx.request({
                  url: `${http}/login`,
                  data: {
                    code: res.code
                  },
                  success:(res)=>{
                    const {openid} =res.data
                    wx.setStorageSync('openid', openid)
                    that.setData({
                      openid
                    })
                  }
                })
              } else {
                console.log('登录失败！' + res.errMsg)
              }
              
            }
          })
    }
    return openid
  },

  onGetUserInfo(e) {
    if (!this.logged && e.detail.userInfo) {
        wx.showLoading({
            title: '加载中',
          })
          wx.request({
            url: `${http}/user/find`,
            method:"get",
            data:{
                openid:openid
            },
            success: (res) => {
              console.log(res.data[0]);
              // 商品卡片进行解构
              this.setData({
                logged: true,
                avatarUrl: res.data[0].userInfo.avatarUrl,
                userInfo: res.data[0].userInfo
              })
              wx.hideLoading();
    
            },
            fail: (res) => {
              wx.showToast({
                icon: 'none',
                title: '服务器异常~~~',
              })
              wx.hideLoading();
            }
          })
    }
  },

  onShareAppMessage() {
    return {
      title: '聊天室',
      path: '/pages/detail/room/room',
    }

  },



  go() {
    wx.navigateTo({
      url: '/pages/message/message',
    })
  }

})