Page({
    data: {
      width: 300,
      height: 300,
      renderWidth: 300,
      renderHeight: 300,
    },
    onLoad(opentions) {
      const info = wx.getSystemInfoSync();
      const width = info.windowWidth;
      const height = info.windowHeight;
      const dpi = info.pixelRatio;
  
    //   console.log(this.opentions.id);
      let url = opentions.id
      if(url =="https://taoan.top/file/model/robot.glb"){
        url = "https://mmbizwxaminiprogram-1258344707.cos.ap-guangzhou.myqcloud.com/xr-frame/demo/miku.glb"
    } 
      this.setData({
        width, height,
        renderWidth: width * dpi,
        renderHeight: height * dpi,
        modelUrl:url
      });
    },
  })