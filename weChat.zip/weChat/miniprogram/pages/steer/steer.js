// pages/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiperList: [{
      url: 'http://taoan.top/file/steer/deliver.png',
      title: "快递代拿",
      firstLine: "需要有人帮忙拿快递",
      sencondLine: "雇佣人员帮你取"
    },
    {
      url: 'http://taoan.top/file/steer/seller.png',
      title: "闲置服务",
      firstLine: "有闲置物品需要出售",
      sencondLine: "发布商品供人买"
    },
    {
      url: 'http://taoan.top/file/steer/task.png',
      title: "任务中心",
      firstLine: "遇到困难需要解决",
      sencondLine: "发布任务等解决"
    },
    {
        url: 'http://taoan.top/file/steer/auction.png',
        title: "竞价拍卖",
        firstLine: "有物品需要拍卖",
        sencondLine: "发布商品来拍卖"
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: '栗米——乡村振兴解决方案',
      imageUrl: 'cloud://cloud1-3gp8ynahdb4ea1a5.636c-cloud1-3gp8ynahdb4ea1a5-1310409999/推广图片.png',
      path: '/pages/index/index'
    }

  },

  
  onShareTimeline: function () {
    return {
      title: '栗米——乡村振兴解决方案',
      imageUrl: 'cloud://cloud1-3gp8ynahdb4ea1a5.636c-cloud1-3gp8ynahdb4ea1a5-1310409999/推广图片.png',
    }
  },


  /**
   * 获取用户信息
   */
  getUserProfile(e) {
    var that = this
    wx.getUserProfile({
      desc: '用于在个人页展示头像、昵称', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res.iv)
        wx.setStorageSync('userInfo', res.userInfo)

        wx.switchTab({
          url: '../index/index',
        })
      },
      fail(err) {
        wx.switchTab({
          url: '../homepage/homepage',
        })
      }
    })
  },
})